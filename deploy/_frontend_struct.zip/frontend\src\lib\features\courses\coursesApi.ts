import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import type { RootState } from "../../store";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";

// ── Types ─────────────────────────────────────────────────────────────────────

export interface PublicCourseListItem {
  id: string;
  title: string;
  description: string | null;
  shortDescription: string | null;
  level: number;
  thumbnailUrl: string | null;
  slug: string | null;
  moduleCount: number;
  lessonCount: number;
  isEnrolled: boolean;
  isFree: boolean;
  price: number;
  discountPrice: number | null;
}

export interface PublicCoursesResult {
  items: PublicCourseListItem[];
  total: number;
  page: number;
  pageSize: number;
}

export interface PublicLessonItem {
  id: string;
  title: string;
  description: string | null;
  orderIndex: number;
  isFreeTrial: boolean;
  isLocked: boolean;
  videoStatus: string | null;
  durationSeconds: number;
  isCompleted: boolean;
}

export interface PublicModuleItem {
  id: string;
  title: string;
  description: string | null;
  orderIndex: number;
  lessons: PublicLessonItem[];
}

export interface PublicCourseDetail {
  id: string;
  title: string;
  description: string | null;
  shortDescription: string | null;
  level: number;
  thumbnailUrl: string | null;
  bannerUrl: string | null;
  slug: string | null;
  teacherName: string | null;
  publishedAt: string | null;
  isEnrolled: boolean;
  isFree: boolean;
  certificateEnabled: boolean;
  modules: PublicModuleItem[];
  price: number;
  discountPrice: number | null;
  discountEndsAt: string | null;
}

export interface LessonDocumentPublic {
  id: string;
  title: string;
  type: string;
  sizeBytes: number;
}

export interface LessonProgressInfo {
  status: string;
  score: number | null;
  completedAt: string | null;
}

export interface LessonView {
  id: string;
  title: string;
  description: string | null;
  isFreeTrial: boolean;
  passScore: number;
  isLocked: boolean;
  videoHlsPath: string | null;
  videoStatus: string | null;
  videoDurationSeconds: number;
  videoThumbnailUrl: string | null;
  documents: LessonDocumentPublic[];
  progress: LessonProgressInfo | null;
  prevLessonId: string | null;
  nextLessonId: string | null;
  courseId: string;
}

// ── API Slice ─────────────────────────────────────────────────────────────────

export interface PublicBannerSlide {
  id: string;
  title: string;
  subtitle: string | null;
  description: string | null;
  imageUrl: string | null;
  linkUrl: string | null;
  badgeText: string | null;
  ctaText: string | null;
  bgColor: string | null;
  textColor: string | null;
  orderIndex: number;
  isActive: boolean;
}

export interface PublicLearningLevel {
  id: string;
  name: string;
  description: string | null;
  orderIndex: number;
  isActive: boolean;
}

export const coursesApi = createApi({
  reducerPath: "coursesApi",
  baseQuery: fetchBaseQuery({
    baseUrl: `${API_BASE}/api/v1/courses`,
    prepareHeaders(headers, { getState }) {
      const state = getState() as RootState;
      const token = state.auth.accessToken;
      const tenant = state.auth.tenantSlug;
      if (token) headers.set("Authorization", `Bearer ${token}`);
      if (tenant) headers.set("X-Tenant-Slug", tenant);
      return headers;
    },
  }),
  tagTypes: ["Course", "Lesson", "Progress"],
  endpoints: (builder) => ({
    getPublicCourses: builder.query<
      PublicCoursesResult,
      { page?: number; pageSize?: number; level?: number; search?: string }
    >({
      query: ({ page = 1, pageSize = 12, level, search } = {}) => {
        const params = new URLSearchParams();
        params.set("page", String(page));
        params.set("pageSize", String(pageSize));
        if (level) params.set("level", String(level));
        if (search) params.set("search", search);
        return `?${params}`;
      },
      providesTags: ["Course"],
    }),

    getPublicCourse: builder.query<PublicCourseDetail, string>({
      query: (id) => `/${id}`,
      providesTags: (_r, _e, id) => [{ type: "Course", id }],
    }),

    enrollCourse: builder.mutation<{ message: string }, string>({
      query: (id) => ({ url: `/${id}/enroll`, method: "POST" }),
      invalidatesTags: (_r, _e, id) => [{ type: "Course", id }, "Course"],
    }),

    getLesson: builder.query<LessonView, string>({
      query: (id) => `/lessons/${id}`,
      providesTags: (_r, _e, id) => [{ type: "Lesson", id }],
    }),

    startLesson: builder.mutation<void, string>({
      query: (id) => ({ url: `/lessons/${id}/start`, method: "POST" }),
      invalidatesTags: (_r, _e, id) => [{ type: "Lesson", id }],
    }),

    completeLesson: builder.mutation<void, { id: string; score?: number }>({
      query: ({ id, score }) => ({
        url: `/lessons/${id}/complete`,
        method: "POST",
        body: { score: score ?? null },
      }),
      invalidatesTags: (_r, _e, { id }) => [{ type: "Lesson", id }, "Progress"],
    }),

    getActiveBanners: builder.query<PublicBannerSlide[], void>({
      query: () => `${API_BASE}/api/v1/admin/system/banners/public`,
    }),

    getPublicLearningLevels: builder.query<PublicLearningLevel[], void>({
      query: () => `${API_BASE}/api/v1/courses/learning-levels`,
    }),
  }),
});

export const {
  useGetPublicCoursesQuery,
  useGetPublicCourseQuery,
  useEnrollCourseMutation,
  useGetLessonQuery,
  useStartLessonMutation,
  useCompleteLessonMutation,
  useGetActiveBannersQuery,
  useGetPublicLearningLevelsQuery,
} = coursesApi;
