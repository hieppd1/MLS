import type { NextConfig } from "next";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";

const nextConfig: NextConfig = {
  output: 'standalone',
  async rewrites() {
    return [
      {
        source: "/media/:path*",
        destination: `${API_URL}/media/:path*`,
      },
    ];
  },
};

export default nextConfig;
