﻿"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";
import {
  useGetPublicCourseQuery,
  useEnrollCourseMutation,
} from "@/lib/features/courses/coursesApi";

const LEVEL_LABELS: Record<number, string> = {
  1: "Level 1 — Nhập môn", 2: "Level 2 — Cơ bản",
  3: "Level 3 — Sơ trung",  4: "Level 4 — Trung cấp",
  5: "Level 5 — Trung cao",  6: "Level 6 — Nâng cao",
};

const LEVEL_BADGE_COLORS: Record<number, string> = {
  1: "bg-gray-400", 2: "bg-green-500", 3: "bg-blue-500",
  4: "bg-purple-500", 5: "bg-orange-500", 6: "bg-red-600",
};

function formatDuration(seconds: number) {
  if (!seconds) return "";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}g ${m}p`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

type TabKey = "intro" | "content" | "reviews";

export default function CourseDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [openModules, setOpenModules] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<TabKey>("intro");

  const { data: course, isLoading } = useGetPublicCourseQuery(id, { skip: !id });
  const [enroll, { isLoading: enrolling }] = useEnrollCourseMutation();

  function toggleModule(moduleId: string) {
    setOpenModules((prev) => {
      const next = new Set(prev);
      if (next.has(moduleId)) next.delete(moduleId); else next.add(moduleId);
      return next;
    });
  }

  async function handleEnroll() {
    await enroll(id);
    router.refresh();
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="h-72 animate-pulse bg-gray-800" />
        <div className="mx-auto max-w-6xl px-4 py-8 space-y-4">
          <div className="h-6 w-1/2 animate-pulse rounded bg-gray-200" />
          <div className="h-4 w-3/4 animate-pulse rounded bg-gray-100" />
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-gray-400">Không tìm thấy khóa học.</p>
      </div>
    );
  }

  const totalLessons = course.modules.reduce((s, m) => s + m.lessons.length, 0);
  const totalDuration = course.modules.flatMap((m) => m.lessons).reduce((s, l) => s + (l.durationSeconds ?? 0), 0);
  const badgeColor = LEVEL_BADGE_COLORS[course.level] ?? "bg-gray-400";
  const firstLessonId = course.modules[0]?.lessons[0]?.id ?? "";

  return (
    <div className="min-h-screen bg-gray-50">

      {/* ── Hero (dark bg) ────────────────────────────────────── */}
      <div className="relative bg-gray-900 text-white">
        {safeImgUrl(course.thumbnailUrl) && (
          <img
            src={safeImgUrl(course.thumbnailUrl)!}
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-10"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/95 to-gray-900/60" />

        <div className="relative mx-auto max-w-6xl px-4 py-12 lg:px-8">
          {/* Inner layout: text left 60%, enrollment card right 40% */}
          <div className="flex gap-8">
            {/* Left column */}
            <div className="flex-1 min-w-0">
              {/* Breadcrumb */}
              <nav className="mb-4 flex items-center gap-2 text-sm text-gray-400">
                <Link href="/" className="hover:text-white transition">Trang chủ</Link>
                <span>/</span>
                <Link href="/courses" className="hover:text-white transition">Khoá học</Link>
                <span>/</span>
                <span className="text-gray-200 truncate">{course.title}</span>
              </nav>

              {/* Level badge */}
              <span className={`mb-3 inline-block rounded-full px-3 py-1 text-xs font-semibold text-white ${badgeColor}`}>
                {LEVEL_LABELS[course.level] ?? `Level ${course.level}`}
              </span>

              <h1 className="text-2xl font-bold sm:text-3xl">{course.title}</h1>
              {course.description && (
                <p className="mt-3 max-w-2xl text-sm leading-relaxed text-gray-300">
                  {course.description}
                </p>
              )}

              {/* Stats */}
              <div className="mt-5 flex flex-wrap gap-5 text-sm text-gray-400">
                {course.teacherName && (
                  <span className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">
                      {course.teacherName[0]}
                    </span>
                    {course.teacherName}
                  </span>
                )}
                <span className="flex items-center gap-1.5">
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  {course.modules.length} chương
                </span>
                <span className="flex items-center gap-1.5">
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13" />
                  </svg>
                  {totalLessons} bài học
                </span>
                {totalDuration > 0 && (
                  <span className="flex items-center gap-1.5">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {formatDuration(totalDuration)}
                  </span>
                )}
              </div>
            </div>

            {/* Enrollment card — hidden on mobile (shown below) */}
            <div className="hidden lg:block w-80 shrink-0">
              <EnrollmentCard
                course={course}
                firstLessonId={firstLessonId}
                enrolling={enrolling}
                onEnroll={handleEnroll}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ── Mobile enrollment card ─────────────────────────────── */}
      <div className="mx-auto max-w-6xl px-4 py-4 lg:hidden">
        <EnrollmentCard
          course={course}
          firstLessonId={firstLessonId}
          enrolling={enrolling}
          onEnroll={handleEnroll}
        />
      </div>

      {/* ── Tab navigation ────────────────────────────────────── */}
      <div className="sticky border-b border-gray-200 bg-white shadow-sm" style={{ top: "56px", zIndex: 20 }}>
        <div className="mx-auto max-w-6xl px-4">
          <nav className="flex gap-0">
            {(["intro", "content", "reviews"] as TabKey[]).map((tab) => {
              const labels: Record<TabKey, string> = { intro: "Giới thiệu", content: "Nội dung khoá học", reviews: "Đánh giá" };
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`border-b-2 px-5 py-3.5 text-sm font-medium transition ${activeTab === tab ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"}`}
                  style={activeTab === tab ? { borderColor: "#1565C0", color: "#1565C0" } : {}}
                >
                  {labels[tab]}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* ── Tab content ───────────────────────────────────────── */}
      <div className="mx-auto max-w-6xl px-4 py-8 lg:px-8">

        {/* Tab: Giới thiệu */}
        {activeTab === "intro" && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="mb-3 text-lg font-bold text-gray-900">Mô tả khoá học</h2>
              <p className="text-sm leading-relaxed text-gray-600">
                {course.description ?? "Chưa có mô tả chi tiết cho khoá học này."}
              </p>
            </div>
            <div>
              <h2 className="mb-3 text-lg font-bold text-gray-900">Kết quả đạt được</h2>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <svg className="mt-0.5 h-4 w-4 shrink-0 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Giao tiếp tự tin trong các tình huống thực tế
                </li>
                <li className="flex items-start gap-2">
                  <svg className="mt-0.5 h-4 w-4 shrink-0 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Nắm vững ngữ pháp và từ vựng cơ bản theo cấp độ
                </li>
                <li className="flex items-start gap-2">
                  <svg className="mt-0.5 h-4 w-4 shrink-0 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Nhận chứng chỉ được công nhận sau khi hoàn thành
                </li>
              </ul>
            </div>
          </div>
        )}

        {/* Tab: Nội dung khoá học */}
        {activeTab === "content" && (
          <div>
            {/* Overview bar */}
            <div className="mb-6 flex flex-wrap gap-6 rounded-xl bg-blue-50 px-5 py-4 text-sm text-gray-700">
              <span><strong>{course.modules.length}</strong> chương</span>
              <span><strong>{totalLessons}</strong> bài học</span>
              {totalDuration > 0 && <span>Tổng <strong>{formatDuration(totalDuration)}</strong></span>}
            </div>

            {course.modules.length === 0 ? (
              <p className="text-gray-400">Chưa có nội dung.</p>
            ) : (
              <div className="space-y-3">
                {course.modules.map((mod, mIdx) => {
                  const isOpen = openModules.has(mod.id);
                  const modDuration = mod.lessons.reduce((s, l) => s + (l.durationSeconds ?? 0), 0);
                  return (
                    <div key={mod.id} className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                      <button
                        onClick={() => toggleModule(mod.id)}
                        className="flex w-full items-center gap-3 bg-gray-50 px-5 py-4 text-left hover:bg-gray-100 transition"
                      >
                        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white" style={{ backgroundColor: "#1565C0" }}>
                          {mIdx + 1}
                        </span>
                        <span className="flex-1 font-semibold text-gray-800">{mod.title}</span>
                        <span className="text-xs text-gray-400">
                          {mod.lessons.length} bài{modDuration > 0 ? ` · ${formatDuration(modDuration)}` : ""}
                        </span>
                        <svg className={`h-4 w-4 text-gray-400 transition-transform ${isOpen ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>

                      {isOpen && (
                        <ol className="divide-y divide-gray-100">
                          {mod.lessons.map((lesson, lIdx) => {
                            const accessible = course.isEnrolled || lesson.isFreeTrial;
                            return (
                              <li key={lesson.id}>
                                {accessible ? (
                                  <Link
                                    href={`/courses/lessons/${lesson.id}`}
                                    className="flex items-center gap-3 px-5 py-3 text-sm hover:bg-blue-50 transition"
                                  >
                                    {/* Status icon */}
                                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gray-200 text-xs text-gray-500">
                                      {lIdx + 1}
                                    </span>
                                    <svg className="h-4 w-4 shrink-0 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                                      <path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                                    </svg>
                                    <span className="flex-1 text-gray-700">{lesson.title}</span>
                                    {lesson.isFreeTrial && !course.isEnrolled && (
                                      <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">
                                        Học thử
                                      </span>
                                    )}
                                    {lesson.durationSeconds > 0 && (
                                      <span className="text-xs text-gray-400">{formatDuration(lesson.durationSeconds)}</span>
                                    )}
                                  </Link>
                                ) : (
                                  <div className="flex items-center gap-3 px-5 py-3 text-sm">
                                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gray-100 text-xs text-gray-400">
                                      {lIdx + 1}
                                    </span>
                                    <svg className="h-4 w-4 shrink-0 text-gray-300" fill="currentColor" viewBox="0 0 20 20">
                                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                                    </svg>
                                    <span className="flex-1 text-gray-400">{lesson.title}</span>
                                    {lesson.durationSeconds > 0 && (
                                      <span className="text-xs text-gray-300">{formatDuration(lesson.durationSeconds)}</span>
                                    )}
                                  </div>
                                )}
                              </li>
                            );
                          })}
                        </ol>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab: Đánh giá */}
        {activeTab === "reviews" && (
          <div className="max-w-2xl">
            <div className="flex items-center gap-6 rounded-xl bg-blue-50 p-6">
              <div className="text-center">
                <p className="text-5xl font-bold text-gray-900">4.8</p>
                <div className="mt-1 flex justify-center text-yellow-400">
                  {"★★★★★".split("").map((star, i) => <span key={i}>{star}</span>)}
                </div>
                <p className="mt-1 text-xs text-gray-500">Xếp hạng khoá học</p>
              </div>
              <div className="flex-1 space-y-1.5">
                {[5, 4, 3, 2, 1].map((star) => (
                  <div key={star} className="flex items-center gap-2 text-xs text-gray-500">
                    <span className="w-3">{star}</span>
                    <svg className="h-3 w-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <div className="flex-1 rounded-full bg-gray-200 h-1.5">
                      <div className="h-full rounded-full bg-yellow-400" style={{ width: star === 5 ? "78%" : star === 4 ? "15%" : "4%" }} />
                    </div>
                    <span className="w-8 text-right">{star === 5 ? "78%" : star === 4 ? "15%" : "4%"}</span>
                  </div>
                ))}
              </div>
            </div>
            <p className="mt-8 text-sm text-gray-400 text-center">Chưa có đánh giá nào.</p>
          </div>
        )}
      </div>

      {/* Upsell sticky bar (when not enrolled) */}
      {!course.isEnrolled && (
        <div className="fixed bottom-0 left-0 right-0 z-30 border-t border-blue-700 py-3 px-4 lg:hidden" style={{ backgroundColor: "#1565C0" }}>
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-4">
            <p className="text-sm font-medium text-white truncate">
              Mở khoá toàn bộ {totalLessons} bài học
            </p>
            <button
              onClick={handleEnroll}
              disabled={enrolling}
              className="shrink-0 rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:bg-orange-600 disabled:opacity-60"
            >
              {enrolling ? "Đang đăng ký..." : "Đăng ký ngay"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Enrollment card component ───────────────────────────────── */
function EnrollmentCard({
  course,
  firstLessonId,
  enrolling,
  onEnroll,
}: {
  course: { isEnrolled: boolean; modules: { lessons: { id: string }[] }[] };
  firstLessonId: string;
  enrolling: boolean;
  onEnroll: () => void;
}) {
  return (
    <div className="rounded-xl bg-white shadow-xl ring-1 ring-gray-100 overflow-hidden" style={{ position: "sticky", top: "80px" }}>
      {/* Thumbnail placeholder */}
      <div className="flex h-44 items-center justify-center bg-gradient-to-br from-blue-100 to-blue-200">
        <svg className="h-12 w-12 text-blue-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>

      <div className="p-5">
        {course.isEnrolled ? (
          <Link
            href={`/courses/lessons/${firstLessonId}`}
            className="flex w-full items-center justify-center gap-2 rounded-lg py-3 font-bold text-white transition hover:opacity-90"
            style={{ backgroundColor: "#1565C0" }}
          >
            <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
              <path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
            </svg>
            Tiếp tục học
          </Link>
        ) : (
          <>
            <button
              onClick={onEnroll}
              disabled={enrolling}
              className="w-full rounded-lg bg-orange-500 py-3 font-bold text-white transition hover:bg-orange-600 disabled:opacity-60"
            >
              {enrolling ? "Đang đăng ký..." : "Đăng ký ngay"}
            </button>
            <p className="mt-3 text-center text-xs text-gray-400">Học thử miễn phí một số bài</p>
          </>
        )}

        {/* Perks */}
        <ul className="mt-5 space-y-2.5 border-t border-gray-100 pt-5">
          {["Học mọi lúc, mọi nơi", "Video chất lượng HD", "Chứng chỉ sau hoàn thành", "Hỗ trợ 24/7"].map((perk) => (
            <li key={perk} className="flex items-center gap-2 text-sm text-gray-600">
              <svg className="h-4 w-4 shrink-0 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              {perk}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
