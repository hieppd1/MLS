"use client";

import { useState } from "react";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";
import {
  useGetAdminTeachersQuery,
  useSetTeacherVerifiedMutation,
  type AdminTeacherDto,
} from "@/lib/features/admin/adminApi";

export default function AdminTeachersPage() {
  const [page] = useState(1);
  const { data: teachers = [], isLoading } = useGetAdminTeachersQuery({ page, pageSize: 50 });
  const [setVerified] = useSetTeacherVerifiedMutation();
  const [msg, setMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  async function handleToggleVerified(t: AdminTeacherDto) {
    try {
      await setVerified({ userId: t.userId, isVerified: !t.isVerified }).unwrap();
      setMsg({ type: "success", text: `Đã ${!t.isVerified ? "xác minh" : "bỏ xác minh"} ${t.fullName}` });
    } catch {
      setMsg({ type: "error", text: "Có lỗi xảy ra." });
    }
    setTimeout(() => setMsg(null), 3000);
  }

  return (
    <div style={{ padding: "32px 32px 48px" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: "#111827", margin: 0 }}>Giáo viên</h1>
          <p style={{ fontSize: 13, color: "#6B7280", marginTop: 4 }}>
            {teachers.length} giáo viên • Quản lý profile, xác minh, thông tin công khai
          </p>
        </div>
      </div>

      {/* Alert */}
      {msg && (
        <div style={{
          marginBottom: 16, padding: "10px 16px", borderRadius: 8,
          background: msg.type === "success" ? "#F0FDF4" : "#FEF2F2",
          border: `1px solid ${msg.type === "success" ? "#BBF7D0" : "#FECACA"}`,
          color: msg.type === "success" ? "#16A34A" : "#DC2626",
          fontSize: 13,
        }}>
          {msg.text}
          <button onClick={() => setMsg(null)} style={{ marginLeft: 12, background: "none", border: "none", cursor: "pointer", color: "inherit", fontWeight: 700 }}>×</button>
        </div>
      )}

      {/* Table */}
      <div style={{ background: "white", borderRadius: 12, border: "1px solid #E5E7EB", overflow: "hidden" }}>
        {/* Table header */}
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 200px 100px 100px 120px",
          padding: "12px 20px", borderBottom: "1px solid #F3F4F6",
          fontSize: 11, fontWeight: 600, color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.05em",
        }}>
          <div>Giáo viên</div>
          <div>Slug / Profile</div>
          <div>Followers</div>
          <div>Khoá học</div>
          <div style={{ textAlign: "right" }}>Thao tác</div>
        </div>

        {isLoading && (
          <div style={{ padding: "48px", textAlign: "center", color: "#9CA3AF" }}>Đang tải...</div>
        )}

        {teachers.map((t) => (
          <div key={t.userId} style={{
            display: "grid", gridTemplateColumns: "1fr 200px 100px 100px 120px",
            padding: "14px 20px", borderBottom: "1px solid #F9FAFB",
            alignItems: "center",
          }}>
            {/* Teacher info */}
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              {t.avatarUrl ? (
                <img src={safeImgUrl(t.avatarUrl)!} alt={t.fullName}
                  style={{ width: 40, height: 40, borderRadius: "50%", objectFit: "cover" }} />
              ) : (
                <div style={{
                  width: 40, height: 40, borderRadius: "50%",
                  background: "linear-gradient(135deg, #6366F1, #4F46E5)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "#fff", fontWeight: 700, fontSize: 14,
                }}>
                  {t.fullName[0]?.toUpperCase()}
                </div>
              )}
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ fontSize: 14, fontWeight: 600, color: "#111827" }}>{t.fullName}</span>
                  {t.isVerified && (
                    <span style={{
                      display: "inline-flex", alignItems: "center", justifyContent: "center",
                      width: 16, height: 16, borderRadius: "50%",
                      background: "#16A34A", color: "#fff", fontSize: 9, fontWeight: 800,
                    }}>✓</span>
                  )}
                </div>
                <div style={{ fontSize: 12, color: "#6B7280" }}>{t.email}</div>
              </div>
            </div>

            {/* Slug */}
            <div style={{ fontSize: 12 }}>
              {t.hasProfile ? (
                <span style={{ color: "#374151", fontFamily: "monospace" }}>{t.slug}</span>
              ) : (
                <span style={{ color: "#EF4444", fontSize: 11 }}>Chưa có profile</span>
              )}
            </div>

            {/* Followers */}
            <div style={{ fontSize: 13, color: "#374151", fontWeight: 600 }}>
              {t.followerCount.toLocaleString()}
            </div>

            {/* Courses */}
            <div style={{ fontSize: 13, color: "#374151", fontWeight: 600 }}>
              {t.courseCount}
            </div>

            {/* Actions */}
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button
                onClick={() => handleToggleVerified(t)}
                style={{
                  padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                  cursor: "pointer", border: "1px solid",
                  background: t.isVerified ? "#F0FDF4" : "white",
                  borderColor: t.isVerified ? "#BBF7D0" : "#E5E7EB",
                  color: t.isVerified ? "#16A34A" : "#6B7280",
                }}
                title={t.isVerified ? "Bỏ xác minh" : "Xác minh"}
              >
                {t.isVerified ? "✓ Đã xác minh" : "Xác minh"}
              </button>
              <Link href={`/admin/teachers/${t.userId}`}
                style={{
                  padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                  textDecoration: "none", border: "1px solid #E5E7EB",
                  background: "white", color: "#6366F1",
                }}>
                Sửa
              </Link>
            </div>
          </div>
        ))}

        {!isLoading && teachers.length === 0 && (
          <div style={{ padding: "48px", textAlign: "center", color: "#9CA3AF", fontSize: 14 }}>
            Chưa có giáo viên nào. Tạo user với role Teacher trong{" "}
            <Link href="/admin/users" style={{ color: "#6366F1" }}>Người dùng</Link>.
          </div>
        )}
      </div>
    </div>
  );
}
