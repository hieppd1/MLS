"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";
import {
  useGetPublicCoursesQuery,
  useGetActiveBannersQuery,
  useGetPublicLearningLevelsQuery,
  type PublicBannerSlide,
} from "@/lib/features/courses/coursesApi";

function formatPrice(price: number | null | undefined) {
  if (price == null || price === 0) return "Miễn phí";
  return price.toLocaleString("vi-VN") + "đ";
}

function discountPercent(price: number, discountPrice: number) {
  if (!price || !discountPrice) return 0;
  return Math.round((1 - discountPrice / price) * 100);
}

function shade(hex: string): string {
  try {
    const n = parseInt(hex.replace("#", ""), 16);
    const r = Math.max(0, ((n >> 16) & 0xff) - 30);
    const g = Math.max(0, ((n >> 8) & 0xff) - 20);
    const b = Math.max(0, (n & 0xff) - 10);
    return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
  } catch {
    return hex;
  }
}

function FilterTab({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        whiteSpace: "nowrap", padding: "8px 20px", borderRadius: 999,
        fontSize: 13, fontWeight: active ? 700 : 500,
        border: active ? "none" : "1px solid #D1D5DB",
        cursor: "pointer", transition: "all 0.15s",
        background: active ? "#1565C0" : "#fff",
        color: active ? "#fff" : "#374151",
        boxShadow: active ? "0 2px 8px rgba(21,101,192,0.3)" : "none",
      }}
    >
      {label}
    </button>
  );
}

function PagBtn({
  children, onClick, disabled, active,
}: { children: React.ReactNode; onClick: () => void; disabled?: boolean; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        minWidth: 36, height: 36, borderRadius: 8, cursor: disabled ? "not-allowed" : "pointer",
        border: "1px solid #E5E7EB", background: active ? "#1565C0" : "#fff",
        color: active ? "#fff" : "#374151", fontSize: 13, fontWeight: active ? 700 : 400,
        padding: "0 12px", opacity: disabled ? 0.4 : 1,
        boxShadow: active ? "0 2px 8px rgba(21,101,192,0.3)" : "none",
      }}
    >
      {children}
    </button>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TEACHERS SECTION
═══════════════════════════════════════════════════════════════ */
const MOCK_TEACHERS = [
  { id: "t1", name: "Thầy Lê Văn Tuấn",    role: "Giáo viên", init: "LT", bg: "#1565C0", courses: 12, students: 340 },
  { id: "t2", name: "Cô Trang Anh",         role: "Giáo viên", init: "TA", bg: "#7C3AED", courses: 8,  students: 210 },
  { id: "t3", name: "Thầy Chu Đình Mong",   role: "Giáo viên", init: "CM", bg: "#DC2626", courses: 15, students: 520 },
  { id: "t4", name: "Thầy Phan Khắc Nghệ", role: "Giáo viên", init: "PN", bg: "#0891B2", courses: 10, students: 280 },
  { id: "t5", name: "Cô Vũ Dung",           role: "Giáo viên", init: "VD", bg: "#16A34A", courses: 6,  students: 190 },
  { id: "t6", name: "Cô Hà Linh",           role: "Giáo viên", init: "HL", bg: "#DB2777", courses: 9,  students: 310 },
  { id: "t7", name: "Thầy Trần Công Minh",  role: "Giáo viên", init: "TM", bg: "#EA580C", courses: 7,  students: 240 },
  { id: "t8", name: "Thầy Phạm Hùng Vương", role: "Giáo viên", init: "HV", bg: "#0D9488", courses: 11, students: 390 },
];

const VISIBLE = 5; // number of cards visible at once

function TeacherSection() {
  const [startIdx, setStartIdx] = useState(0);
  const total = MOCK_TEACHERS.length;
  const canPrev = startIdx > 0;
  const canNext = startIdx + VISIBLE < total;

  return (
    <div style={{ background: "linear-gradient(135deg, #4C1D95 0%, #1E40AF 60%, #0D47A1 100%)", padding: "48px 0" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 40px" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <h2 style={{ fontSize: 28, fontWeight: 900, color: "#fff", margin: "0 0 10px" }}>Đội ngũ giáo viên</h2>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.75)", maxWidth: 560, margin: "0 auto", lineHeight: 1.6 }}>
            Đội ngũ giáo viên với nhiều năm kinh nghiệm, tác giả của hàng loạt khoá học chất lượng cao
          </p>
        </div>

        {/* Slider */}
        <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 16 }}>

          {/* Prev */}
          <button
            onClick={() => setStartIdx(i => Math.max(0, i - 1))}
            disabled={!canPrev}
            style={{
              flexShrink: 0, width: 44, height: 44, borderRadius: "50%",
              background: canPrev ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.07)",
              border: "2px solid rgba(255,255,255,0.3)",
              cursor: canPrev ? "pointer" : "not-allowed",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "background 0.2s",
            }}
          >
            <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="white" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          {/* Cards */}
          <div style={{ flex: 1, display: "grid", gridTemplateColumns: `repeat(${VISIBLE}, 1fr)`, gap: 16, overflow: "hidden" }}>
            {MOCK_TEACHERS.slice(startIdx, startIdx + VISIBLE).map((t) => (
              <div key={t.id} style={{
                background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)",
                borderRadius: 16, padding: "24px 16px 20px", textAlign: "center",
                cursor: "pointer", transition: "background 0.2s, transform 0.2s",
                backdropFilter: "blur(6px)",
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.18)"; (e.currentTarget as HTMLElement).style.transform = "translateY(-4px)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; }}
              >
                {/* Avatar */}
                <div style={{
                  width: 84, height: 84, borderRadius: "50%", margin: "0 auto 14px",
                  background: t.bg, display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 28, fontWeight: 900, color: "#fff",
                  border: "3px solid rgba(255,255,255,0.35)",
                  boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
                }}>
                  {t.init}
                </div>

                <p style={{ fontSize: 10, color: "rgba(255,255,255,0.6)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em", margin: "0 0 4px" }}>{t.role}</p>
                <h3 style={{ fontSize: 14, fontWeight: 800, color: "#fff", margin: "0 0 12px", lineHeight: 1.3 }}>{t.name}</h3>

                <div style={{ display: "flex", justifyContent: "center", gap: 14 }}>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 15, fontWeight: 800, color: "#FBBF24" }}>{t.courses}</div>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>Khoá học</div>
                  </div>
                  <div style={{ width: 1, background: "rgba(255,255,255,0.2)" }} />
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 15, fontWeight: 800, color: "#FBBF24" }}>{t.students}+</div>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>Học viên</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Next */}
          <button
            onClick={() => setStartIdx(i => Math.min(total - VISIBLE, i + 1))}
            disabled={!canNext}
            style={{
              flexShrink: 0, width: 44, height: 44, borderRadius: "50%",
              background: canNext ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.07)",
              border: "2px solid rgba(255,255,255,0.3)",
              cursor: canNext ? "pointer" : "not-allowed",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "background 0.2s",
            }}
          >
            <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="white" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Dots */}
        <div style={{ display: "flex", justifyContent: "center", gap: 6, marginTop: 24 }}>
          {Array.from({ length: total - VISIBLE + 1 }).map((_, i) => (
            <button key={i} onClick={() => setStartIdx(i)} style={{
              width: i === startIdx ? 24 : 8, height: 8, borderRadius: 999,
              border: "none", cursor: "pointer", padding: 0, transition: "all 0.25s",
              background: i === startIdx ? "#FBBF24" : "rgba(255,255,255,0.3)",
            }} />
          ))}
        </div>

      </div>
    </div>
  );
}

export default function KhoaHocPage() {
  const [levelFilter, setLevelFilter] = useState<number | undefined>();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 12;

  const { data, isLoading } = useGetPublicCoursesQuery({
    page, pageSize, level: levelFilter, search: debouncedSearch || undefined,
  });
  const { data: learningLevels = [] } = useGetPublicLearningLevelsQuery();

  function handleSearch(value: string) {
    setSearch(value);
    clearTimeout((window as Window & { __kh?: ReturnType<typeof setTimeout> }).__kh);
    (window as Window & { __kh?: ReturnType<typeof setTimeout> }).__kh = setTimeout(() => {
      setDebouncedSearch(value); setPage(1);
    }, 400);
  }

  const totalPages = data ? Math.ceil(data.total / pageSize) : 1;

  // ── Banner Carousel ──────────────────────────────────────────────────────
  const { data: apiBanners } = useGetActiveBannersQuery();
  const [bannerIdx, setBannerIdx] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Level tabs scroll ────────────────────────────────────────────────────
  const tabsRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  function checkTabsScroll() {
    const el = tabsRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 4);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  }

  useEffect(() => {
    checkTabsScroll();
    const el = tabsRef.current;
    if (!el) return;
    el.addEventListener("scroll", checkTabsScroll, { passive: true });
    const ro = new ResizeObserver(checkTabsScroll);
    ro.observe(el);
    return () => { el.removeEventListener("scroll", checkTabsScroll); ro.disconnect(); };
  }, [learningLevels]);

  function scrollTabs(dir: "left" | "right") {
    const el = tabsRef.current;
    if (!el) return;
    el.scrollBy({ left: dir === "left" ? -220 : 220, behavior: "smooth" });
  }

  const fallbackSlides: PublicBannerSlide[] = [
    {
      id: "f1", isActive: true, orderIndex: 0,
      title: "Học Tiếng Việt Mọi Trình Độ",
      subtitle: "Hệ thống 6 cấp độ – từ nhập môn đến nâng cao. Lộ trình rõ ràng, bài bản.",
      description: null, imageUrl: null, linkUrl: null,
      badgeText: "HOT", ctaText: "Đăng ký ngay",
      bgColor: "#1565C0", textColor: "#FFFFFF",
    },
    {
      id: "f2", isActive: true, orderIndex: 1,
      title: "Khoá Học Có Chứng Chỉ Quốc Gia",
      subtitle: "Hoàn thành khoá học và nhận chứng chỉ được công nhận toàn quốc.",
      description: null, imageUrl: null, linkUrl: null,
      badgeText: "MỚI", ctaText: "Xem khoá học",
      bgColor: "#0D47A1", textColor: "#FFFFFF",
    },
  ];
  const bannerSlides = (apiBanners && apiBanners.length > 0) ? apiBanners : fallbackSlides;

  function startTimer() {
    if (timerRef.current) clearInterval(timerRef.current);
    if (bannerSlides.length <= 1) return;
    timerRef.current = setInterval(() => {
      setBannerIdx((i) => (i + 1) % bannerSlides.length);
    }, 5000);
  }

  useEffect(() => {
    startTimer();
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bannerSlides.length]);

  function goToBanner(i: number) {
    setBannerIdx(i);
    startTimer();
  }

  const slide = bannerSlides[Math.min(bannerIdx, bannerSlides.length - 1)];
  const solutionCount = learningLevels.length > 0 ? learningLevels.length : 6;
  const DOT_COLORS = ["#E53935", "#FB8C00", "#FDD835", "#43A047", "#1E88E5", "#8E24AA", "#00ACC1", "#6D4C41"];

  return (
    <div style={{ minHeight: "100vh", background: "#F0F4F8" }}>

      {/* ── HERO BANNER ──────────────────────────────────────────────────────── */}
      <div style={{ position: "relative", overflow: "hidden" }}>
        {/* Background layer */}
        <div style={{
          position: "absolute", inset: 0,
          background: slide.imageUrl
            ? `linear-gradient(90deg, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.25) 70%), url(${slide.imageUrl}) center/cover no-repeat`
            : `linear-gradient(135deg, ${slide.bgColor ?? "#1565C0"} 0%, ${shade(slide.bgColor ?? "#1565C0")} 100%)`,
          transition: "background 0.6s ease",
        }} />
        <div style={{ position: "absolute", top: -80, right: -80, width: 360, height: 360, borderRadius: "50%", background: "rgba(255,255,255,0.05)", pointerEvents: "none" }} />
        <div style={{ position: "absolute", bottom: -100, left: "25%", width: 280, height: 280, borderRadius: "50%", background: "rgba(255,255,255,0.04)", pointerEvents: "none" }} />

        {/* Prev / Next arrows */}
        {bannerSlides.length > 1 && (
          <>
            <button
              onClick={() => goToBanner((bannerIdx - 1 + bannerSlides.length) % bannerSlides.length)}
              aria-label="Trước"
              style={{
                position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)",
                width: 40, height: 40, borderRadius: "50%", border: "2px solid rgba(255,255,255,0.4)",
                background: "rgba(0,0,0,0.25)", color: "#fff", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", zIndex: 5,
              }}
            >
              <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              onClick={() => goToBanner((bannerIdx + 1) % bannerSlides.length)}
              aria-label="Tiếp"
              style={{
                position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)",
                width: 40, height: 40, borderRadius: "50%", border: "2px solid rgba(255,255,255,0.4)",
                background: "rgba(0,0,0,0.25)", color: "#fff", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", zIndex: 5,
              }}
            >
              <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </>
        )}

        {/* Content */}
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "40px 24px 32px", position: "relative", zIndex: 2 }}>
          <div style={{ display: "flex", gap: 32, alignItems: "center", flexWrap: "wrap" }}>

            {/* Left: text */}
            <div style={{ flex: "1 1 380px", minWidth: 0 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginBottom: 16 }}>
                <Link href="/" style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Trang chủ</Link>
                <span style={{ margin: "0 6px" }}>/</span>
                <span style={{ color: "rgba(255,255,255,0.9)" }}>Khoá học</span>
              </div>

              {slide.badgeText && (
                <span style={{
                  display: "inline-block", background: "#FF6B35", color: "#fff",
                  fontSize: 11, fontWeight: 900, padding: "4px 14px", borderRadius: 999,
                  letterSpacing: "0.08em", marginBottom: 14, textTransform: "uppercase",
                }}>
                  {slide.badgeText}
                </span>
              )}

              <h1 style={{
                fontSize: "clamp(22px, 3vw, 36px)", fontWeight: 900,
                color: slide.textColor ?? "#fff", margin: "0 0 12px", lineHeight: 1.2,
              }}>
                {slide.title}
              </h1>
              {slide.subtitle && (
                <p style={{ fontSize: 15, color: "rgba(255,255,255,0.85)", margin: "0 0 8px", lineHeight: 1.6 }}>
                  {slide.subtitle}
                </p>
              )}
              {slide.description && (
                <p style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", margin: "0 0 8px", lineHeight: 1.6 }}>
                  {slide.description}
                </p>
              )}

              {slide.ctaText && (
                <Link
                  href={slide.linkUrl ?? "#"}
                  style={{
                    display: "inline-flex", alignItems: "center", gap: 6,
                    marginTop: 20, background: "#FF6B35", color: "#fff", textDecoration: "none",
                    padding: "11px 28px", borderRadius: 999, fontWeight: 800, fontSize: 14,
                    boxShadow: "0 4px 16px rgba(255,107,53,0.45)", letterSpacing: "0.02em",
                  }}
                >
                  {slide.ctaText}
                  <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              )}

              {bannerSlides.length > 1 && (
                <div style={{ display: "flex", gap: 6, marginTop: 24 }}>
                  {bannerSlides.map((_, i) => (
                    <button key={i} onClick={() => goToBanner(i)} style={{
                      width: i === bannerIdx ? 28 : 8, height: 8, borderRadius: 999,
                      border: "none", cursor: "pointer", padding: 0,
                      background: i === bannerIdx ? "#FF6B35" : "rgba(255,255,255,0.35)",
                      transition: "all 0.25s",
                    }} />
                  ))}
                </div>
              )}
            </div>

            {/* Right: stats + search */}
            <div style={{ flex: "0 0 auto", display: "flex", flexDirection: "column", gap: 12, minWidth: 220 }}>
              <div style={{ display: "flex", gap: 10 }}>
                {[
                  { icon: "📚", value: String(data?.total ?? "–"), label: "Khoá học" },
                  { icon: "🎓", value: String(solutionCount), label: "Cấp độ" },
                  { icon: "👥", value: "1000+", label: "Học viên" },
                ].map((s) => (
                  <div key={s.label} style={{
                    background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.25)",
                    borderRadius: 12, padding: "10px 12px", textAlign: "center", flex: 1,
                  }}>
                    <div style={{ fontSize: 18 }}>{s.icon}</div>
                    <div style={{ fontSize: 18, fontWeight: 900, color: "#fff", lineHeight: 1.1 }}>{s.value}</div>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)" }}>{s.label}</div>
                  </div>
                ))}
              </div>
              <div style={{ position: "relative" }}>
                <svg style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.55)", width: 15, height: 15 }}
                  fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text" value={search} onChange={(e) => handleSearch(e.target.value)}
                  placeholder="Tìm kiếm khoá học..."
                  style={{
                    width: "100%", boxSizing: "border-box",
                    background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)",
                    borderRadius: 999, paddingLeft: 38, paddingRight: 14, paddingTop: 10, paddingBottom: 10,
                    fontSize: 13, color: "#fff", outline: "none",
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{
          background: "rgba(0,0,0,0.35)", borderTop: "1px solid rgba(255,255,255,0.1)",
          padding: "10px 24px", position: "relative", zIndex: 2,
        }}>
          <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
            <span style={{ fontSize: 13, fontWeight: 800, color: "#fff", letterSpacing: "0.04em", textTransform: "uppercase" }}>
              {String(solutionCount).padStart(2, "0")} Giải pháp học tập toàn diện
            </span>
            <div style={{ display: "flex", gap: 6 }}>
              {DOT_COLORS.slice(0, Math.max(solutionCount, 6)).map((c, i) => (
                <div key={i} style={{ width: 14, height: 14, borderRadius: "50%", background: c, border: "2px solid rgba(255,255,255,0.3)" }} />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── FILTER TABS ──────────────────────────────────────────────────────── */}
      <div style={{
        position: "sticky", top: 56, zIndex: 20,
        background: "#fff", borderBottom: "2px solid #E5E7EB",
        boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
      }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 16px", position: "relative", display: "flex", alignItems: "center" }}>

          {/* Prev arrow */}
          <button
            onClick={() => scrollTabs("left")}
            aria-label="Trước"
            style={{
              flexShrink: 0, width: 30, height: 30, borderRadius: "50%",
              border: "1.5px solid #D1D5DB", background: "#fff",
              cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 1px 4px rgba(0,0,0,0.1)", marginRight: 6, zIndex: 1,
              opacity: canScrollLeft ? 1 : 0, pointerEvents: canScrollLeft ? "auto" : "none",
              transition: "opacity 0.2s",
            }}
          >
            <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#374151">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          {/* Scrollable tabs */}
          <div
            ref={tabsRef}
            style={{
              flex: 1, display: "flex", gap: 6, overflowX: "auto", padding: "10px 0",
              alignItems: "center", scrollbarWidth: "none",
            }}
          >
            <FilterTab label="Tất cả" active={levelFilter === undefined} onClick={() => { setLevelFilter(undefined); setPage(1); }} />
            {learningLevels.map((ll) => (
              <FilterTab key={ll.id} label={ll.name} active={levelFilter === ll.orderIndex}
                onClick={() => { setLevelFilter(ll.orderIndex); setPage(1); }} />
            ))}
            {learningLevels.length === 0 && [1, 2, 3, 4, 5, 6].map((n) => (
              <FilterTab key={n} label={`Cấp ${n}`} active={levelFilter === n}
                onClick={() => { setLevelFilter(n); setPage(1); }} />
            ))}
          </div>

          {/* Next arrow */}
          <button
            onClick={() => scrollTabs("right")}
            aria-label="Tiếp"
            style={{
              flexShrink: 0, width: 30, height: 30, borderRadius: "50%",
              border: "1.5px solid #D1D5DB", background: "#fff",
              cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 1px 4px rgba(0,0,0,0.1)", marginLeft: 6, zIndex: 1,
              opacity: canScrollRight ? 1 : 0, pointerEvents: canScrollRight ? "auto" : "none",
              transition: "opacity 0.2s",
            }}
          >
            <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#374151">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
            </svg>
          </button>

        </div>
      </div>

      {/* ── COURSE GRID ──────────────────────────────────────────────────────── */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "28px 16px 48px" }}>

        {!isLoading && data && (
          <p style={{ fontSize: 13, color: "#6B7280", marginBottom: 20 }}>
            {data.total === 0 ? "Không tìm thấy kết quả" : `Hiển thị ${data.items.length} / ${data.total} khoá học`}
          </p>
        )}

        {isLoading && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} style={{ borderRadius: 12, overflow: "hidden", background: "#fff", boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
                <div style={{ paddingTop: "56.25%", background: "#E5E7EB" }} />
                <div style={{ padding: "14px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
                  <div style={{ height: 12, width: "40%", background: "#EFF6FF", borderRadius: 6 }} />
                  <div style={{ height: 14, width: "85%", background: "#F3F4F6", borderRadius: 6 }} />
                  <div style={{ height: 12, width: "60%", background: "#F3F4F6", borderRadius: 6 }} />
                  <div style={{ height: 16, width: "50%", background: "#FEE2E2", borderRadius: 6 }} />
                </div>
              </div>
            ))}
          </div>
        )}

        {!isLoading && !data?.items.length && (
          <div style={{ textAlign: "center", padding: "80px 0" }}>
            <div style={{ fontSize: 52, marginBottom: 16 }}>🔍</div>
            <p style={{ color: "#9CA3AF", fontSize: 15 }}>Không tìm thấy khoá học nào.</p>
          </div>
        )}

        {!isLoading && !!data?.items.length && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
            {data.items.map((course) => {
              const price = course.price ?? 0;
              const hasDiscount = course.discountPrice != null && course.discountPrice < price;
              const pct = hasDiscount ? discountPercent(price, course.discountPrice!) : 0;
              const levelLabel = learningLevels.find(l => l.orderIndex === course.level)?.name ?? `Cấp ${course.level}`;

              return (
                <Link key={course.id} href={`/khoa-hoc/${course.id}`} style={{ textDecoration: "none" }}>
                  <div
                    style={{
                      background: "#fff", borderRadius: 12, overflow: "hidden",
                      boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
                      transition: "transform 0.15s, box-shadow 0.15s",
                      cursor: "pointer", display: "flex", flexDirection: "column", height: "100%",
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLElement).style.transform = "translateY(-4px)";
                      (e.currentTarget as HTMLElement).style.boxShadow = "0 10px 28px rgba(0,0,0,0.13)";
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                      (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 8px rgba(0,0,0,0.07)";
                    }}
                  >
                    {/* Thumbnail – 16:9 landscape */}
                    <div style={{ position: "relative", paddingTop: "56.25%", overflow: "hidden", background: "#E8EEF8" }}>
                      <div style={{ position: "absolute", inset: 0 }}>
                        {safeImgUrl(course.thumbnailUrl) ? (
                          <img src={safeImgUrl(course.thumbnailUrl)!} alt={course.title}
                            style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                        ) : (
                          <div style={{
                            width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center",
                            background: "linear-gradient(135deg, #1565C0 0%, #0D47A1 100%)",
                          }}>
                            <span style={{ fontSize: 38, fontWeight: 900, color: "rgba(255,255,255,0.15)", userSelect: "none" }}>
                              {course.title.substring(0, 2).toUpperCase()}
                            </span>
                          </div>
                        )}
                      </div>

                      {hasDiscount && pct > 0 && (
                        <div style={{
                          position: "absolute", top: 0, right: 0,
                          background: "#FF6B35", color: "#fff",
                          fontSize: 11, fontWeight: 900, padding: "5px 10px",
                          borderBottomLeftRadius: 10,
                        }}>
                          -{pct}%
                        </div>
                      )}

                      {price === 0 && (
                        <div style={{
                          position: "absolute", top: 0, right: 0,
                          background: "#16A34A", color: "#fff",
                          fontSize: 11, fontWeight: 900, padding: "5px 10px",
                          borderBottomLeftRadius: 10,
                        }}>
                          FREE
                        </div>
                      )}

                      {course.isEnrolled && (
                        <div style={{
                          position: "absolute", bottom: 8, left: 8,
                          background: "rgba(22,163,74,0.9)", color: "#fff",
                          fontSize: 10, fontWeight: 700, padding: "3px 8px", borderRadius: 999,
                        }}>
                          ✓ Đã đăng ký
                        </div>
                      )}
                    </div>

                    {/* Card body */}
                    <div style={{ padding: "12px 14px 14px", display: "flex", flexDirection: "column", flex: 1, gap: 6 }}>
                      <span style={{
                        display: "inline-block", alignSelf: "flex-start",
                        background: "#EFF6FF", color: "#1565C0",
                        fontSize: 10, fontWeight: 700, padding: "2px 10px", borderRadius: 999,
                        textTransform: "uppercase", maxWidth: "100%",
                        overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                      }}>
                        {levelLabel}
                      </span>

                      <h3 style={{
                        fontSize: 14, fontWeight: 700, color: "#111827", margin: 0,
                        lineHeight: 1.45, display: "-webkit-box",
                        WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden",
                      }}>
                        {course.title}
                      </h3>

                      <div style={{ fontSize: 12, color: "#9CA3AF", display: "flex", gap: 10 }}>
                        <span>📦 {course.moduleCount} chương</span>
                        <span>📝 {course.lessonCount} bài học</span>
                      </div>

                      <div style={{ borderTop: "1px solid #F3F4F6", marginTop: 2 }} />

                      <div>
                        {price === 0 ? (
                          <span style={{ fontSize: 15, fontWeight: 800, color: "#16A34A" }}>Miễn phí</span>
                        ) : hasDiscount ? (
                          <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}>
                            <span style={{ fontSize: 17, fontWeight: 900, color: "#DC2626" }}>
                              {formatPrice(course.discountPrice!)}
                            </span>
                            <span style={{ fontSize: 12, color: "#9CA3AF", textDecoration: "line-through" }}>
                              {formatPrice(price)}
                            </span>
                          </div>
                        ) : (
                          <span style={{ fontSize: 17, fontWeight: 900, color: "#DC2626" }}>
                            {formatPrice(price)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}

        {totalPages > 1 && (
          <div style={{ marginTop: 40, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <PagBtn disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>← Trước</PagBtn>
            {Array.from({ length: Math.min(totalPages, 7) }).map((_, i) => (
              <PagBtn key={i} active={page === i + 1} onClick={() => setPage(i + 1)}>{i + 1}</PagBtn>
            ))}
            <PagBtn disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Tiếp →</PagBtn>
          </div>
        )}
      </div>

      {/* ── TEACHER SECTION ──────────────────────────────────────────────────── */}
      <TeacherSection />

      {/* ── STATS BAR ────────────────────────────────────────────────────────── */}
      <div style={{ background: "#fff", borderBottom: "1px solid #E5E7EB" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 24px", display: "flex", gap: 0, justifyContent: "space-around", flexWrap: "wrap" }}>
          {[
            { icon: "🎓", value: "1,200+", label: "Học viên đang học" },
            { icon: "📚", value: String(data?.total ?? "50+"), label: "Khoá học" },
            { icon: "👨‍🏫", value: "20+", label: "Giáo viên" },
            { icon: "⭐", value: "4.8/5", label: "Đánh giá trung bình" },
            { icon: "🏆", value: "98%", label: "Học viên hài lòng" },
          ].map((s) => (
            <div key={s.label} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "8px 20px", textAlign: "center" }}>
              <span style={{ fontSize: 26 }}>{s.icon}</span>
              <span style={{ fontSize: 22, fontWeight: 900, color: "#1565C0" }}>{s.value}</span>
              <span style={{ fontSize: 12, color: "#6B7280" }}>{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
