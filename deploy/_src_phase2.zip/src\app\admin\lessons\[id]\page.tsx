﻿"use client";

import { useState, useRef, useEffect } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import type { RootState } from "@/lib/store";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";
import dynamic from "next/dynamic";
import {
  useGetLessonQuery,
  useUpdateLessonMutation,
  useUploadLessonDocumentMutation,
  useDeleteLessonDocumentMutation,
  cmsApi,
} from "@/lib/features/cms/cmsApi";

const RichTextEditor = dynamic(() => import("@/components/RichTextEditor"), { ssr: false });

const VIDEO_STATUS: Record<string, { label: string; className: string }> = {
  Pending:    { label: "Chờ xử lý",   className: "bg-yellow-100 text-yellow-700" },
  Processing: { label: "Đang xử lý",  className: "bg-blue-100 text-blue-700" },
  Ready:      { label: "Sẵn sàng",    className: "bg-green-100 text-green-700" },
  Failed:     { label: "Lỗi",         className: "bg-red-100 text-red-700" },
};

const DOC_TYPES: Record<string, string> = {
  PDF:   "📄 PDF",
  Audio: "🎵 Audio",
  Ebook: "📖 Ebook",
};

const LESSON_TYPE_LABELS: Record<string, string> = {
  Video:      "🎬 Video",
  Reading:    "📖 Reading",
  Audio:      "🎧 Audio",
  Pdf:        "📄 PDF",
  Quiz:       "❓ Quiz",
  Assignment: "📝 Assignment",
  Live:       "📡 Live",
};

const PUBLISH_STATUS_LABELS: Record<string, { label: string; className: string }> = {
  Draft:     { label: "Bản nháp",    className: "bg-gray-100 text-gray-600" },
  Published: { label: "Đã xuất bản", className: "bg-green-100 text-green-700" },
  Hidden:    { label: "Đã ẩn",       className: "bg-orange-100 text-orange-700" },
};

const CONTENT_TYPES = ["Reading", "Assignment"];
const AUDIO_TYPES   = ["Audio"];
const PDF_TYPES     = ["Pdf"];
const TRANSCRIPT_TYPES = ["Video", "Audio", "Live"];

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function LessonDetailPage() {
  const { id } = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const dispatch = useDispatch();

  const isTranscoding = (status?: string) => status === "Pending" || status === "Processing";
  const { data: lesson, isLoading } = useGetLessonQuery(id);
  const videoStatus = lesson?.video?.status;
  // Re-fetch every 5s while video is transcoding
  useGetLessonQuery(id, { pollingInterval: isTranscoding(videoStatus) ? 5000 : 0 });
  const [updateLesson, { isLoading: updating }] = useUpdateLessonMutation();
  const [uploadDoc, { isLoading: uploadingDoc }] = useUploadLessonDocumentMutation();
  const [deleteDoc] = useDeleteLessonDocumentMutation();
  const docInputRef = useRef<HTMLInputElement>(null);

  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    orderIndex: 0,
    isFreeTrial: false,
    passScore: 70,
    lessonType: "Video",
    publishStatus: "Draft",
    content: "",
    thumbnailUrl: "",
    audioUrl: "",
    documentUrl: "",
    transcript: "",
    durationMinutes: 0,
  });
  const [uploading, setUploading] = useState(false);
  const token = useSelector((s: RootState) => s.auth.accessToken);
  const tenantSlug = useSelector((s: RootState) => s.auth.tenantSlug);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const [thumbPreview, setThumbPreview] = useState<string>("");
  const [thumbUploading, setThumbUploading] = useState(false);

  const uploadThumbnail = async (file: File): Promise<string | null> => {
    const fd = new FormData();
    fd.append("file", file);
    try {
      const res = await fetch(`${API_BASE}/api/v1/admin/cms/upload-thumbnail`, {
        method: "POST",
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          ...(tenantSlug ? { "X-Tenant-Slug": tenantSlug } : {}),
        },
        body: fd,
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.url as string;
    } catch {
      return null;
    }
  };
  const [msg, setMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    if (lesson && searchParams.get("edit") === "true") {
      startEdit();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lesson]);

  const showMsg = (type: "success" | "error", text: string) => {
    setMsg({ type, text });
    setTimeout(() => setMsg(null), 4000);
  };

  const startEdit = () => {
    if (!lesson) return;
    setForm({
      title: lesson.title,
      description: lesson.description ?? "",
      orderIndex: lesson.orderIndex,
      isFreeTrial: lesson.isFreeTrial,
      passScore: lesson.passScore,
      lessonType: lesson.lessonType ?? "Video",
      publishStatus: lesson.publishStatus ?? "Draft",
      content: lesson.content ?? "",
      thumbnailUrl: (lesson.thumbnailUrl?.startsWith("blob:") ? "" : lesson.thumbnailUrl) ?? "",
      audioUrl: lesson.audioUrl ?? "",
      documentUrl: lesson.documentUrl ?? "",
      transcript: lesson.transcript ?? "",
      durationMinutes: lesson.durationMinutes ?? 0,
    });
    setEditMode(true);
    setThumbPreview("");
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateLesson({ id, ...form }).unwrap();
      setEditMode(false);
      showMsg("success", "Đã cập nhật bài học");
    } catch {
      showMsg("error", "Cập nhật thất bại");
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const apiBase = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";
    const token = typeof window !== "undefined" ? localStorage.getItem("accessToken") : null;
    const tenant = typeof window !== "undefined" ? localStorage.getItem("tenantSlug") ?? "demo" : "demo";

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch(`${apiBase}/api/v1/admin/cms/lessons/${id}/video`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "X-Tenant-Slug": tenant,
        },
        body: formData,
      });
      if (!res.ok) throw new Error("Upload failed");
      showMsg("success", "Video đã được tải lên thành công!");
      dispatch(cmsApi.util.invalidateTags([{ type: "Lesson", id }]));
    } catch {
      showMsg("error", "Tải video thất bại");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  if (isLoading) return <div className="p-6 text-gray-500">Đang tải...</div>;
  if (!lesson)   return <div className="p-6 text-red-500">Không tìm thấy bài học</div>;

  const videoStatusLabel = lesson.video ? VIDEO_STATUS[lesson.video.status] : null;
  const publishBadge = PUBLISH_STATUS_LABELS[lesson.publishStatus] ?? PUBLISH_STATUS_LABELS.Draft;
  const inputCls = "w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";
  const labelCls = "mb-1 block text-sm font-medium text-gray-700";

  return (
    <div className="p-6">
      {/* Breadcrumb */}
      <nav className="mb-4 text-sm text-gray-500">
        <Link href="/admin/courses" className="hover:text-blue-600">Khóa học</Link>
        <span className="mx-2">/</span>
        <Link href={`/admin/modules/${lesson.moduleId}`} className="hover:text-blue-600">Module</Link>
        <span className="mx-2">/</span>
        <span className="text-gray-800">{lesson.title}</span>
      </nav>

      {msg && (
        <div className={`mb-4 rounded-lg px-4 py-3 text-sm ${msg.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
          {msg.text}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {/* ── Lesson Info ── */}
        <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <div className="mb-4 flex items-start justify-between">
            <h2 className="font-semibold text-gray-700">Thông tin bài học</h2>
            {!editMode && (
              <button onClick={startEdit} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">
                Chỉnh sửa
              </button>
            )}
          </div>

          {editMode ? (
            <form onSubmit={handleUpdate} className="space-y-4">
              {/* Title */}
              <div>
                <label className={labelCls}>Tên bài học *</label>
                <input required value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  className={inputCls} />
              </div>

              {/* Short description */}
              <div>
                <label className={labelCls}>Mô tả ngắn</label>
                <textarea value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={2} className={inputCls} />
              </div>

              {/* LessonType + PublishStatus */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Loại bài học</label>
                  <select value={form.lessonType}
                    onChange={(e) => setForm({ ...form, lessonType: e.target.value })}
                    className={inputCls}>
                    {Object.entries(LESSON_TYPE_LABELS).map(([v, l]) => (
                      <option key={v} value={v}>{l}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>Trạng thái</label>
                  <select value={form.publishStatus}
                    onChange={(e) => setForm({ ...form, publishStatus: e.target.value })}
                    className={inputCls}>
                    <option value="Draft">Bản nháp</option>
                    <option value="Published">Đã xuất bản</option>
                    <option value="Hidden">Ẩn</option>
                  </select>
                </div>
              </div>

              {/* OrderIndex + DurationMinutes */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Thứ tự</label>
                  <input type="number" min={0} value={form.orderIndex}
                    onChange={(e) => setForm({ ...form, orderIndex: Number(e.target.value) })}
                    className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Thời lượng (phút)</label>
                  <input type="number" min={0} value={form.durationMinutes}
                    onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })}
                    className={inputCls} />
                </div>
              </div>

              {/* PassScore */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Điểm qua (%)</label>
                  <input type="number" min={0} max={100} value={form.passScore}
                    onChange={(e) => setForm({ ...form, passScore: Number(e.target.value) })}
                    className={inputCls} />
                </div>
              </div>

              {/* IsFreeTrial */}
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.isFreeTrial}
                  onChange={(e) => setForm({ ...form, isFreeTrial: e.target.checked })} />
                <span className="font-medium">Học thử miễn phí</span>
              </label>

              {/* Thumbnail */}
              <div>
                <label className={labelCls}>Thumbnail</label>
                <input
                  ref={thumbInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    setThumbPreview(URL.createObjectURL(file));
                    setThumbUploading(true);
                    uploadThumbnail(file).then((serverUrl) => {
                      setThumbUploading(false);
                      if (serverUrl) {
                        setForm((prev) => ({ ...prev, thumbnailUrl: serverUrl }));
                      } else {
                        setThumbPreview("");
                      }
                    });
                  }}
                />
                <div
                  onClick={() => thumbInputRef.current?.click()}
                  className="relative cursor-pointer overflow-hidden rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 transition-colors hover:border-blue-400 hover:bg-blue-50/30"
                  style={{ width: 220, height: 130 }}
                >
                  {(thumbPreview || form.thumbnailUrl) ? (
                    <>
                      <img src={thumbPreview || form.thumbnailUrl} alt="thumbnail" className="h-full w-full object-cover" />
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 opacity-0 transition-opacity hover:opacity-100 rounded-xl">
                        <span className="text-xl">📷</span>
                        <span className="mt-1 text-xs font-medium text-white">Đổi ảnh</span>
                      </div>
                    </>
                  ) : (
                    <div className="flex h-full flex-col items-center justify-center gap-2 text-gray-400">
                      <span className="text-3xl">🖼️</span>
                      <span className="text-xs font-medium">Nhấn để chọn ảnh</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Audio URL — Audio type only */}
              {AUDIO_TYPES.includes(form.lessonType) && (
                <div>
                  <label className={labelCls}>Link Audio</label>
                  <input type="url" value={form.audioUrl}
                    onChange={(e) => setForm({ ...form, audioUrl: e.target.value })}
                    placeholder="https://..."
                    className={inputCls} />
                </div>
              )}

              {/* Document URL — Pdf type only */}
              {PDF_TYPES.includes(form.lessonType) && (
                <div>
                  <label className={labelCls}>Link tài liệu PDF</label>
                  <input type="url" value={form.documentUrl}
                    onChange={(e) => setForm({ ...form, documentUrl: e.target.value })}
                    placeholder="https://..."
                    className={inputCls} />
                </div>
              )}

              {/* Content — Reading / Assignment */}
              {CONTENT_TYPES.includes(form.lessonType) && (
                <div>
                  <label className={labelCls}>Nội dung bài học</label>
                  <RichTextEditor
                    value={form.content}
                    onChange={(val) => setForm({ ...form, content: val })}
                    placeholder="Nhập nội dung bài học..."
                    height={300}
                  />
                </div>
              )}

              {/* Transcript — Video / Audio / Live */}
              {TRANSCRIPT_TYPES.includes(form.lessonType) && (
                <div>
                  <label className={labelCls}>Transcript / Phụ đề</label>
                  <textarea value={form.transcript}
                    onChange={(e) => setForm({ ...form, transcript: e.target.value })}
                    rows={4}
                    placeholder="Nội dung phụ đề hoặc transcript..."
                    className={inputCls} />
                </div>
              )}

              <div className="flex gap-3">
                <button type="submit" disabled={updating}
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                  {updating ? "Đang lưu..." : "Lưu"}
                </button>
                <button type="button" onClick={() => setEditMode(false)}
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">
                  Hủy
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              {/* Thumbnail preview */}
              {safeImgUrl(lesson.thumbnailUrl) && (
                <img src={safeImgUrl(lesson.thumbnailUrl)!} alt={lesson.title}
                  className="mb-3 h-36 w-full rounded-lg object-cover border border-gray-200" />
              )}

              <div>
                <p className="text-xs text-gray-400">Tên bài học</p>
                <p className="font-medium text-gray-900">{lesson.title}</p>
              </div>
              {lesson.description && (
                <div>
                  <p className="text-xs text-gray-400">Mô tả</p>
                  <p className="text-gray-600">{lesson.description}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-4">
                <div>
                  <p className="text-xs text-gray-400">Loại bài học</p>
                  <p className="font-medium text-gray-700">{LESSON_TYPE_LABELS[lesson.lessonType] ?? lesson.lessonType}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Trạng thái</p>
                  <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium ${publishBadge.className}`}>
                    {publishBadge.label}
                  </span>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Thứ tự</p>
                  <p className="text-gray-700">{lesson.orderIndex + 1}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Thời lượng</p>
                  <p className="text-gray-700">{lesson.durationMinutes > 0 ? `${lesson.durationMinutes} phút` : "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Điểm qua</p>
                  <p className="text-gray-700">{lesson.passScore}%</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Học thử</p>
                  <p className="text-gray-700">{lesson.isFreeTrial ? "✅ Có" : "❌ Không"}</p>
                </div>
              </div>

              {/* Audio URL */}
              {lesson.audioUrl && (
                <div>
                  <p className="text-xs text-gray-400">Link Audio</p>
                  <a href={lesson.audioUrl} target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline">{lesson.audioUrl}</a>
                </div>
              )}

              {/* Document URL */}
              {lesson.documentUrl && (
                <div>
                  <p className="text-xs text-gray-400">Link tài liệu</p>
                  <a href={lesson.documentUrl} target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline">{lesson.documentUrl}</a>
                </div>
              )}

              {/* HTML Content */}
              {lesson.content && CONTENT_TYPES.includes(lesson.lessonType) && (
                <div className="border-t border-gray-100 pt-4">
                  <p className="mb-2 text-xs text-gray-400">Nội dung</p>
                  <div
                    className="prose prose-sm max-w-none text-gray-700"
                    dangerouslySetInnerHTML={{ __html: lesson.content }}
                  />
                </div>
              )}

              {/* Transcript */}
              {lesson.transcript && TRANSCRIPT_TYPES.includes(lesson.lessonType) && (
                <div className="border-t border-gray-100 pt-4">
                  <p className="mb-2 text-xs text-gray-400">Transcript / Phụ đề</p>
                  <pre className="max-h-40 overflow-auto rounded-lg bg-gray-50 p-3 text-xs text-gray-600 whitespace-pre-wrap">{lesson.transcript}</pre>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ── Video ── */}
        <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-4 font-semibold text-gray-700">Video bài học</h2>
          {lesson.video ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isTranscoding(lesson.video.status) && (
                    <svg className="animate-spin h-4 w-4 text-blue-500" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                    </svg>
                  )}
                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${videoStatusLabel?.className}`}>
                    {videoStatusLabel?.label}
                  </span>
                  {isTranscoding(lesson.video.status) && (
                    <span className="text-xs text-blue-500">Tự động cập nhật sau 5s...</span>
                  )}
                </div>
                {lesson.video.durationSeconds > 0 && (
                  <span className="text-sm text-gray-500">{formatDuration(lesson.video.durationSeconds)}</span>
                )}
              </div>
              {isTranscoding(lesson.video.status) && (
                <div className="w-full rounded-full bg-gray-200 h-1.5 overflow-hidden">
                  <div
                    className="h-1.5 rounded-full bg-blue-500 animate-pulse"
                    style={{ width: lesson.video.status === "Processing" ? "65%" : "20%" }}
                  />
                </div>
              )}
              {lesson.video.originalFileName && (
                <p className="text-sm text-gray-600">📎 {lesson.video.originalFileName}</p>
              )}
              <p className="text-xs text-gray-400">{formatBytes(lesson.video.sizeBytes)}</p>
              {lesson.video.status === "Ready" && lesson.video.hlsPath && (
                <a href={lesson.video.hlsPath} target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline">
                  Xem video ↗
                </a>
              )}
              {lesson.video.status === "Failed" && (
                <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-xs text-red-600">
                  ❌ Xử lý video thất bại. Hãy thử tải lên lại.
                </div>
              )}
              <label className="mt-4 block">
                <span className="rounded-lg border border-gray-300 px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-50">
                  {uploading ? "Đang tải lên..." : "🔄 Thay thế video"}
                </span>
                <input type="file" accept="video/*" className="hidden" onChange={handleVideoUpload} disabled={uploading} />
              </label>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-300 py-10">
              <p className="mb-3 text-4xl">🎬</p>
              <p className="mb-4 text-sm text-gray-500">Chưa có video. Tải lên để bắt đầu.</p>
              <label>
                <span className="cursor-pointer rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                  {uploading ? "Đang tải lên..." : "Tải video lên"}
                </span>
                <input type="file" accept="video/*" className="hidden" onChange={handleVideoUpload} disabled={uploading} />
              </label>
            </div>
          )}
        </div>
      </div>

      {/* ── Documents ── */}
      <div className="mt-6 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-semibold text-gray-700">Tài liệu đính kèm ({lesson.documents.length})</h2>
          <label className="cursor-pointer">
            <span className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700">
              {uploadingDoc ? "Đang tải..." : "+ Thêm tài liệu"}
            </span>
            <input
              ref={docInputRef}
              type="file"
              accept=".pdf,.mp3,.wav,.epub,.docx"
              className="hidden"
              disabled={uploadingDoc}
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
                const docType = ["mp3", "wav", "ogg"].includes(ext) ? "Audio" : ext === "epub" ? "Ebook" : "PDF";
                try {
                  await uploadDoc({ lessonId: id, file, documentType: docType }).unwrap();
                  showMsg("success", "Đã tải lên tài liệu");
                } catch {
                  showMsg("error", "Tải lên thất bại");
                } finally {
                  if (docInputRef.current) docInputRef.current.value = "";
                }
              }}
            />
          </label>
        </div>
        {lesson.documents.length === 0 ? (
          <p className="text-sm text-gray-400">Chưa có tài liệu nào.</p>
        ) : (
          <div className="space-y-2">
            {lesson.documents.map((doc) => (
              <div key={doc.id} className="flex items-center justify-between rounded-lg border border-gray-100 bg-gray-50 px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="text-sm">{DOC_TYPES[doc.type] ?? doc.type}</span>
                  <div>
                    <p className="text-sm font-medium text-gray-800">{doc.title}</p>
                    <p className="text-xs text-gray-400">{formatBytes(doc.sizeBytes)} · {doc.isProtected ? "🔒 Bảo vệ" : "🔓 Công khai"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <a href={doc.fileUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-600 hover:underline">
                    Tải xuống
                  </a>
                  <button
                    onClick={async () => {
                      if (!confirm(`Xóa tài liệu "${doc.title}"?`)) return;
                      try {
                        await deleteDoc({ lessonId: id, docId: doc.id }).unwrap();
                        showMsg("success", "Đã xóa tài liệu");
                      } catch {
                        showMsg("error", "Xóa thất bại");
                      }
                    }}
                    className="text-xs text-red-500 hover:text-red-700"
                  >
                    Xóa
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}