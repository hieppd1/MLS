"use client";

import { useEffect, useCallback, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  useGetLessonQuery,
  useGetPublicCourseQuery,
  useStartLessonMutation,
  useCompleteLessonMutation,
} from "@/lib/features/courses/coursesApi";
import HlsPlayer from "@/components/video/HlsPlayer";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";

function formatBytes(bytes: number): string {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

const DOC_TYPE_ICON: Record<string, string> = {
  PDF: "📄", Audio: "🎵", Ebook: "📗", Subtitle: "💬",
};

type LessonTab = "notes" | "qa" | "docs";

export default function LessonPlayerPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<LessonTab>("docs");

  const { data: lesson, isLoading } = useGetLessonQuery(id, { skip: !id });
  const { data: course } = useGetPublicCourseQuery(lesson?.courseId ?? "", {
    skip: !lesson?.courseId,
  });

  const [startLesson]                               = useStartLessonMutation();
  const [completeLesson, { isLoading: completing }] = useCompleteLessonMutation();

  useEffect(() => {
    if (lesson && !lesson.progress) startLesson(id);
  }, [lesson, id, startLesson]);

  const handleEnded = useCallback(async () => {
    await completeLesson({ id });
  }, [id, completeLesson]);

  const handleComplete = async () => { await completeLesson({ id }); };
  const handleNext = () => { if (lesson?.nextLessonId) router.push(`/lesson/${lesson.nextLessonId}`); };
  const handlePrev = () => { if (lesson?.prevLessonId) router.push(`/lesson/${lesson.prevLessonId}`); };

  /* ── Loading ─────────────────────────────────────────────── */
  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-56px)] items-center justify-center bg-gray-950">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-t-transparent" style={{ borderColor: "#1565C0", borderTopColor: "transparent" }} />
      </div>
    );
  }
  if (!lesson) {
    return (
      <div className="flex h-[calc(100vh-56px)] items-center justify-center bg-gray-950 text-white">
        <p className="text-gray-400">Không tìm thấy bài học.</p>
      </div>
    );
  }

  const isCompleted = lesson.progress?.status === "Completed";
  const allLessons = course?.modules.flatMap((m) => m.lessons) ?? [];
  const completedCount = allLessons.filter((l) => l.isCompleted).length;
  const progressPct = allLessons.length > 0 ? Math.round((completedCount / allLessons.length) * 100) : 0;

  return (
    <div className="flex h-[calc(100vh-56px)] overflow-hidden bg-gray-950 text-white">

      {/* ════════════════════════════════════════════════════
          LEFT — Video + Content
      ════════════════════════════════════════════════════ */}
      <div className="flex min-w-0 flex-1 flex-col overflow-y-auto">

        {/* Sub-header */}
        <div className="flex shrink-0 items-center gap-2 border-b border-gray-800 bg-gray-900 px-4 py-2 text-sm">
          {course ? (
            <Link href={`/khoa-hoc/${course.id}`} className="max-w-xs truncate text-gray-300 transition hover:text-white font-medium">
              ← {course.title}
            </Link>
          ) : (
            <span className="text-gray-400">Khoá học</span>
          )}

          <div className="ml-auto flex items-center gap-1">
            <button
              onClick={handlePrev}
              disabled={!lesson.prevLessonId}
              className="flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs text-gray-400 transition hover:bg-gray-800 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Bài trước
            </button>
            <button
              onClick={handleNext}
              disabled={!lesson.nextLessonId}
              className="flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs text-gray-400 transition hover:bg-gray-800 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
            >
              Bài tiếp
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
            <button
              onClick={() => setSidebarOpen((o) => !o)}
              className="ml-1 flex items-center gap-1.5 rounded-lg border border-gray-700 px-3 py-1.5 text-xs text-gray-400 transition hover:text-white lg:hidden"
            >
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              Nội dung
            </button>
          </div>
        </div>

        {/* Video player */}
        <div className="shrink-0 bg-black relative">
          {lesson.isLocked ? (
            <div
              className="flex w-full flex-col items-center justify-center gap-4 bg-gray-900"
              style={{ aspectRatio: "16/9" }}
            >
              <div className="absolute inset-0 overflow-hidden">
                <div className="absolute inset-0 bg-gray-950/80 backdrop-blur-sm z-10" />
              </div>
              <div className="relative z-20 flex flex-col items-center gap-4 px-6 text-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gray-800 ring-4 ring-gray-700">
                  <svg className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Bài học bị khóa</h3>
                  <p className="mt-1 text-sm text-gray-400">Đăng ký khóa học để xem toàn bộ nội dung</p>
                </div>
                {lesson.courseId && (
                  <Link
                    href={`/khoa-hoc/${lesson.courseId}`}
                    className="inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-bold text-white transition hover:opacity-90"
                    style={{ background: "#FF6B35" }}
                  >
                    Xem chi tiết &amp; Đăng ký
                  </Link>
                )}
              </div>
            </div>
          ) : lesson.videoHlsPath ? (
            <HlsPlayer
              src={`${API_BASE}/media/${lesson.videoHlsPath}`}
              lessonId={id}
              onEnded={handleEnded}
            />
          ) : (
            <div
              className="flex w-full flex-col items-center justify-center gap-3 bg-gray-900 text-gray-500"
              style={{ aspectRatio: "16/9" }}
            >
              <svg className="h-14 w-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.723v6.554a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              <p className="text-sm">Chưa có video cho bài học này</p>
            </div>
          )}
        </div>

        {/* Lesson title + complete button */}
        <div className="flex shrink-0 flex-wrap items-start justify-between gap-3 border-b border-gray-800 px-6 py-4">
          <div>
            <h1 className="text-lg font-bold text-white">{lesson.title}</h1>
            {lesson.description && (
              <p className="mt-1 text-sm text-gray-400 leading-relaxed">{lesson.description}</p>
            )}
          </div>
          {!isCompleted ? (
            <button
              onClick={handleComplete}
              disabled={completing}
              className="flex shrink-0 items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-green-500 disabled:opacity-60"
            >
              {completing ? (
                <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
              )}
              Đánh dấu hoàn thành
            </button>
          ) : (
            <span className="flex shrink-0 items-center gap-2 rounded-lg bg-green-900/40 px-4 py-2 text-sm font-semibold text-green-400">
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
              </svg>
              Đã hoàn thành
            </span>
          )}
        </div>

        {/* Tabs */}
        <div className="flex shrink-0 border-b border-gray-800">
          {(["docs", "notes", "qa"] as LessonTab[]).map((tab) => {
            const labels: Record<LessonTab, string> = { notes: "Ghi chú", qa: "Hỏi đáp", docs: "Tài liệu" };
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`border-b-2 px-5 py-3 text-sm font-medium transition ${activeTab === tab ? "border-blue-500 text-blue-400" : "border-transparent text-gray-500 hover:text-gray-300"}`}
              >
                {labels[tab]}
                {tab === "docs" && lesson.documents.length > 0 && (
                  <span className="ml-1.5 rounded-full bg-gray-700 px-1.5 py-0.5 text-xs">{lesson.documents.length}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab content */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {activeTab === "docs" && (
            <div>
              {lesson.documents.length === 0 ? (
                <p className="text-sm text-gray-500">Không có tài liệu đính kèm.</p>
              ) : (
                <div className="space-y-2">
                  {lesson.documents.map((doc) => (
                    <a
                      key={doc.id}
                      href={`${API_BASE}/media/documents/${doc.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-3 rounded-xl bg-gray-800/70 px-4 py-3 text-sm transition hover:bg-gray-800"
                    >
                      <span className="text-lg">{DOC_TYPE_ICON[doc.type] ?? "📎"}</span>
                      <span className="flex-1 text-gray-200">{doc.title}</span>
                      <span className="text-xs text-gray-500">{formatBytes(doc.sizeBytes)}</span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "notes" && (
            <div className="text-sm text-gray-500">
              <p>Ghi chú của bạn sẽ xuất hiện ở đây.</p>
            </div>
          )}

          {activeTab === "qa" && (
            <div className="text-sm text-gray-500">
              <p>Tính năng hỏi đáp sẽ được bổ sung trong phiên bản tới.</p>
            </div>
          )}
        </div>
      </div>

      {/* ════════════════════════════════════════════════════
          SIDEBAR — Course Outline
      ════════════════════════════════════════════════════ */}

      {sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside
        className={[
          "fixed right-0 z-30 flex flex-col",
          "top-[56px] h-[calc(100vh-56px)] w-80 shrink-0",
          "border-l border-gray-800 bg-gray-900",
          "transition-transform duration-300 ease-in-out",
          "lg:relative lg:top-auto lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "translate-x-full",
        ].join(" ")}
      >
        <div className="flex shrink-0 items-center justify-between border-b border-gray-800 px-4 py-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Nội dung khoá học</span>
          <button
            onClick={() => setSidebarOpen(false)}
            className="rounded p-1 text-gray-500 transition hover:bg-gray-800 hover:text-white lg:hidden"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {course && (
          <div className="shrink-0 border-b border-gray-800 px-4 py-3">
            <div className="mb-1.5 flex items-center justify-between text-xs text-gray-500">
              <span>Tiến độ</span>
              <span>{progressPct}% hoàn thành</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-gray-700">
              <div className="h-full rounded-full transition-all" style={{ width: `${progressPct}%`, backgroundColor: "#1565C0" }} />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto">
          {!course ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-12 animate-pulse rounded-lg bg-gray-800" />
              ))}
            </div>
          ) : (
            course.modules.map((mod) => (
              <div key={mod.id} className="border-b border-gray-800/40">
                <div className="bg-gray-800/30 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-gray-500">
                  {mod.title}
                </div>
                {mod.lessons.map((l) => {
                  const active = l.id === id;
                  return (
                    <Link
                      key={l.id}
                      href={`/lesson/${l.id}`}
                      onClick={() => setSidebarOpen(false)}
                      className={[
                        "flex items-center gap-3 px-4 py-3 text-sm transition",
                        active
                          ? "border-l-2 bg-blue-950/50 text-white"
                          : "border-l-2 border-transparent text-gray-400 hover:bg-gray-800/60 hover:text-gray-200",
                      ].join(" ")}
                      style={active ? { borderLeftColor: "#1565C0" } : {}}
                    >
                      <span className="shrink-0">
                        {active ? (
                          <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20" style={{ color: "#1976D2" }}>
                            <path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                          </svg>
                        ) : l.isLocked ? (
                          <svg className="h-4 w-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                          </svg>
                        ) : l.isCompleted ? (
                          <svg className="h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                          </svg>
                        ) : (
                          <svg className="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        )}
                      </span>
                      <span className={["flex-1 text-sm leading-snug", active ? "font-medium text-white" : l.isLocked ? "text-gray-600" : ""].join(" ")}>
                        {l.title}
                      </span>
                      {l.isFreeTrial && !active && (
                        <span className="rounded-full bg-blue-900/60 px-1.5 py-0.5 text-xs text-blue-400">Thử</span>
                      )}
                      {l.durationSeconds > 0 && (
                        <span className="text-xs text-gray-600">{Math.ceil(l.durationSeconds / 60)}p</span>
                      )}
                    </Link>
                  );
                })}
                {mod.sessions.map((s) => {
                  return (
                    <Link
                      key={s.id}
                      href={`/session/${s.id}`}
                      onClick={() => setSidebarOpen(false)}
                      className="flex items-center gap-3 border-l-2 border-transparent px-4 py-3 text-sm text-gray-400 transition hover:bg-gray-800/60 hover:text-gray-200"
                    >
                      <span className="shrink-0">
                        {s.isLocked ? (
                          <svg className="h-4 w-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                          </svg>
                        ) : (
                          <svg className="h-4 w-4 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                          </svg>
                        )}
                      </span>
                      <span className="flex-1 text-sm leading-snug">{s.title}</span>
                      {s.isFreeTrial && (
                        <span className="rounded-full bg-purple-900/60 px-1.5 py-0.5 text-xs text-purple-400">Thử</span>
                      )}
                      {s.segmentCount > 0 && (
                        <span className="text-xs text-gray-600">{s.segmentCount} phần</span>
                      )}
                    </Link>
                  );
                })}
              </div>
            ))
          )}
        </div>
      </aside>
    </div>
  );
}
