﻿"use client";

import { useState, useRef } from "react";
import { useParams } from "next/navigation";
import { useSelector } from "react-redux";
import type { RootState } from "@/lib/store";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";
import dynamic from "next/dynamic";
import {
  useGetModuleQuery,
  useUpdateModuleMutation,
  useCreateLessonMutation,
  useDeleteLessonMutation,
  useUpdateLessonMutation,
  useGetSessionsByModuleQuery,
  useCreateSessionMutation,
  useDeleteSessionMutation,
} from "@/lib/features/cms/cmsApi";

const RichTextEditor = dynamic(() => import("@/components/RichTextEditor"), { ssr: false });

const VIDEO_STATUS: Record<string, string> = {
  Pending: "⏳ Chờ xử lý",
  Processing: "⚙️ Đang xử lý",
  Ready: "✅ Sẵn sàng",
  Failed: "❌ Lỗi",
};

export default function ModuleDetailPage() {
  const { id } = useParams<{ id: string }>();

  const { data: module, isLoading } = useGetModuleQuery(id);
  const [updateModule, { isLoading: updating }] = useUpdateModuleMutation();
  const [createLesson, { isLoading: creatingLesson }] = useCreateLessonMutation();
  const [deleteLesson] = useDeleteLessonMutation();
  const [updateLesson] = useUpdateLessonMutation();

  // Sessions
  const { data: sessions } = useGetSessionsByModuleQuery(id);
  const [createSession, { isLoading: creatingSession }] = useCreateSessionMutation();
  const [deleteSession] = useDeleteSessionMutation();
  const [activeTab, setActiveTab] = useState<"lessons" | "sessions">("lessons");
  const [showAddSession, setShowAddSession] = useState(false);
  const [sessionForm, setSessionForm] = useState({ title: "", description: "", isFreeTrial: false });

  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    thumbnailUrl: "",
    estimatedDuration: 0,
    orderIndex: 0,
    isLocked: false,
  });
  const token = useSelector((s: RootState) => s.auth.accessToken);
  const tenantSlug = useSelector((s: RootState) => s.auth.tenantSlug);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const [thumbPreview, setThumbPreview] = useState<string>("");
  const [thumbUploading, setThumbUploading] = useState(false);

  const uploadThumbnail = async (file: File): Promise<string | null> => {
    const fd = new FormData();
    fd.append("file", file);
    try {
      const res = await fetch(`${API_BASE}/api/v1/admin/cms/upload-thumbnail`, {
        method: "POST",
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          ...(tenantSlug ? { "X-Tenant-Slug": tenantSlug } : {}),
        },
        body: fd,
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.url as string;
    } catch {
      return null;
    }
  };
  const [showAddLesson, setShowAddLesson] = useState(false);
  const [lessonForm, setLessonForm] = useState({ title: "", description: "", isFreeTrial: false, lessonType: "Video", content: "", durationMinutes: "", passScore: 70 });

  // Drag-drop reorder lessons
  const [dragLessonId, setDragLessonId] = useState<string | null>(null);
  const [dragOverLessonId, setDragOverLessonId] = useState<string | null>(null);
  const [localLessons, setLocalLessons] = useState<import("@/lib/features/cms/cmsApi").LessonSummary[] | null>(null);

  async function handleLessonDrop(targetLessonId: string) {
    if (!dragLessonId || dragLessonId === targetLessonId || !module) return;
    const sorted = [...module.lessons].sort((a, b) => a.orderIndex - b.orderIndex);
    const fromIdx = sorted.findIndex((l) => l.id === dragLessonId);
    const toIdx = sorted.findIndex((l) => l.id === targetLessonId);
    if (fromIdx === -1 || toIdx === -1) return;
    const reordered = [...sorted];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    // Optimistic update — show new order immediately
    setLocalLessons(reordered);
    setDragLessonId(null);
    setDragOverLessonId(null);
    await Promise.all(reordered.map((l, i) =>
      updateLesson({ id: l.id, title: l.title, description: l.description ?? undefined, orderIndex: i, isFreeTrial: l.isFreeTrial, passScore: l.passScore ?? 0 })
    ));
    setLocalLessons(null); // revert to server state after refetch
  }
  const [msg, setMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const showMsg = (type: "success" | "error", text: string) => {
    setMsg({ type, text });
    setTimeout(() => setMsg(null), 4000);
  };

  const safeUrl = (url: string | null | undefined) =>
    url?.startsWith("blob:") ? "" : (url ?? "");

  const startEdit = () => {
    if (!module) return;
    setForm({
      title: module.title,
      description: module.description ?? "",
      thumbnailUrl: safeUrl(module.thumbnailUrl),
      estimatedDuration: module.estimatedDuration ?? 0,
      orderIndex: module.orderIndex,
      isLocked: module.isLocked,
    });
    setThumbPreview("");
    setEditMode(true);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateModule({ id, ...form }).unwrap();
      setEditMode(false);
      showMsg("success", "Đã cập nhật module");
    } catch {
      showMsg("error", "Cập nhật thất bại");
    }
  };

  const handleAddLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createLesson({
        moduleId: id,
        title: lessonForm.title,
        description: lessonForm.description || undefined,
        isFreeTrial: lessonForm.isFreeTrial,
        lessonType: lessonForm.lessonType,
        content: lessonForm.content || undefined,
        durationMinutes: lessonForm.durationMinutes !== "" ? Number(lessonForm.durationMinutes) : undefined,
        passScore: lessonForm.passScore,
      }).unwrap();
      setShowAddLesson(false);
      setLessonForm({ title: "", description: "", isFreeTrial: false, lessonType: "Video", content: "", durationMinutes: "", passScore: 70 });
      showMsg("success", "Đã thêm bài học");
    } catch {
      showMsg("error", "Thêm bài học thất bại");
    }
  };

  const handleDeleteLesson = async (lessonId: string, title: string) => {
    if (!confirm(`Xóa bài học "${title}"?`)) return;
    try {
      await deleteLesson({ id: lessonId, moduleId: id }).unwrap();
      showMsg("success", "Đã xóa bài học");
    } catch {
      showMsg("error", "Xóa thất bại");
    }
  };

  const handleAddSession = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createSession({ moduleId: id, ...sessionForm }).unwrap();
      setShowAddSession(false);
      setSessionForm({ title: "", description: "", isFreeTrial: false });
      showMsg("success", "Đã thêm session");
    } catch {
      showMsg("error", "Thêm session thất bại");
    }
  };

  const handleDeleteSession = async (sessionId: string, title: string) => {
    if (!confirm(`Xóa session "${title}"?`)) return;
    try {
      await deleteSession({ id: sessionId, moduleId: id }).unwrap();
      showMsg("success", "Đã xóa session");
    } catch {
      showMsg("error", "Xóa thất bại");
    }
  };

  if (isLoading) return <div className="p-6 text-gray-500">Đang tải...</div>;
  if (!module) return <div className="p-6 text-red-500">Không tìm thấy module</div>;

  const inputCls = "w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";
  const labelCls = "mb-1 block text-sm font-medium text-gray-700";

  return (
    <div className="p-6">
      {/* Breadcrumb */}
      <nav className="mb-4 text-sm text-gray-500">
        <Link href="/admin/courses" className="hover:text-blue-600">Khóa học</Link>
        <span className="mx-2">/</span>
        <Link href={`/admin/courses/${module.courseId}`} className="hover:text-blue-600">Khóa học</Link>
        <span className="mx-2">/</span>
        <span className="text-gray-800">{module.title}</span>
      </nav>

      {msg && (
        <div className={`mb-4 rounded-lg px-4 py-3 text-sm ${msg.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
          {msg.text}
        </div>
      )}

      {/* Module Info */}
      <div className="mb-6 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-start justify-between">
          <span className="text-sm text-gray-500">Thứ tự: {module.orderIndex + 1}</span>
          {!editMode && (
            <button onClick={startEdit} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">
              Chỉnh sửa
            </button>
          )}
        </div>

        {editMode ? (
          <form onSubmit={handleUpdate} className="space-y-4">
            {/* Tên module */}
            <div>
              <label className={labelCls}>Tên module *</label>
              <input
                required
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className={inputCls}
              />
            </div>

            {/* Mô tả (rich text) */}
            <div>
              <label className={labelCls}>Mô tả</label>
              <RichTextEditor
                value={form.description}
                onChange={(val) => setForm({ ...form, description: val })}
                placeholder="Nhập mô tả module..."
                height={200}
              />
            </div>

            {/* Thumbnail + Duration */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className={labelCls}>Ảnh thumbnail</label>
                <input
                  ref={thumbInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    setThumbPreview(URL.createObjectURL(file));
                    setThumbUploading(true);
                    uploadThumbnail(file).then((serverUrl) => {
                      setThumbUploading(false);
                      if (serverUrl) {
                        setForm((prev) => ({ ...prev, thumbnailUrl: serverUrl }));
                      } else {
                        setThumbPreview("");
                      }
                    });
                  }}
                />
                <div
                  onClick={() => thumbInputRef.current?.click()}
                  className="relative cursor-pointer overflow-hidden rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 transition-colors hover:border-blue-400 hover:bg-blue-50/30"
                  style={{ width: 200, height: 120 }}
                >
                  {(thumbPreview || form.thumbnailUrl) ? (
                    <>
                      <img src={thumbPreview || form.thumbnailUrl} alt="thumbnail" className="h-full w-full object-cover" />
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 opacity-0 transition-opacity hover:opacity-100 rounded-xl">
                        <span className="text-xl">📷</span>
                        <span className="mt-1 text-xs font-medium text-white">Đổi ảnh</span>
                      </div>
                    </>
                  ) : (
                    <div className="flex h-full flex-col items-center justify-center gap-2 text-gray-400">
                      <span className="text-3xl">🖼️</span>
                      <span className="text-xs font-medium">Nhấn để chọn ảnh</span>
                    </div>
                  )}
                </div>
              </div>
              <div>
                <label className={labelCls}>Thời lượng ước tính (phút)</label>
                <input
                  type="number"
                  min={0}
                  value={form.estimatedDuration}
                  onChange={(e) => setForm({ ...form, estimatedDuration: Number(e.target.value) })}
                  className={inputCls}
                />
              </div>
            </div>

            {/* Thứ tự */}
            <div className="w-32">
              <label className={labelCls}>Thứ tự</label>
              <input
                type="number"
                min={0}
                value={form.orderIndex}
                onChange={(e) => setForm({ ...form, orderIndex: Number(e.target.value) })}
                className={inputCls}
              />
            </div>

            {/* IsLocked */}
            <label className="flex items-center gap-2 text-sm mt-2">
              <input
                type="checkbox"
                checked={form.isLocked}
                onChange={(e) => setForm({ ...form, isLocked: e.target.checked })}
                className="rounded"
              />
              <span className="font-medium text-gray-700">🔒 Khóa module (học viên phải hoàn thành module trước mới mở khóa)</span>
            </label>

            <div className="flex gap-3">
              <button type="submit" disabled={updating} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                {updating ? "Đang lưu..." : "Lưu"}
              </button>
              <button type="button" onClick={() => setEditMode(false)} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">Hủy</button>
            </div>
          </form>
        ) : (
          <div className="flex gap-6">
            {safeImgUrl(module.thumbnailUrl) && (
              <img
                src={safeImgUrl(module.thumbnailUrl)!}
                alt={module.title}
                className="h-28 w-44 flex-shrink-0 rounded-lg object-cover border border-gray-200"
              />
            )}
            <div className="flex-1 space-y-2">
              <h1 className="text-xl font-bold text-gray-900">{module.title}</h1>
              {module.isLocked && (
                <span className="inline-block rounded-full bg-yellow-50 px-2.5 py-0.5 text-xs font-medium text-yellow-700">🔒 Module đang khóa</span>
              )}
              {module.estimatedDuration > 0 && (
                <p className="text-sm text-gray-500">⏱ Thời lượng ước tính: <strong>{module.estimatedDuration} phút</strong></p>
              )}
              {module.description && (
                <div
                  className="prose prose-sm max-w-none text-gray-600"
                  dangerouslySetInnerHTML={{ __html: module.description }}
                />
              )}
            </div>
          </div>
        )}
      </div>

      {/* Tabs: Lessons / Sessions */}
      <div className="mb-4 flex gap-0 border-b border-gray-200">
        {(["lessons", "sessions"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={[
              "px-5 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px",
              activeTab === tab
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-500 hover:text-gray-800",
            ].join(" ")}
          >
            {tab === "lessons"
              ? `📖 Bài học (${module.lessons.length})`
              : `🎬 Session tương tác (${sessions?.length ?? 0})`}
          </button>
        ))}
      </div>

      {/* Lessons tab */}
      {activeTab === "lessons" && (
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Bài học ({module.lessons.length})</h2>
          <button
            onClick={() => setShowAddLesson(true)}
            className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700"
          >
            + Thêm bài học
          </button>
        </div>

        {module.lessons.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 py-12 text-center text-gray-400">
            Chưa có bài học nào.
          </div>
        ) : (
          <div className="space-y-2">
            {(localLessons ?? module.lessons).map((lesson, idx) => (
              <div key={lesson.id}
                draggable
                onDragStart={() => setDragLessonId(lesson.id)}
                onDragOver={(e) => { e.preventDefault(); setDragOverLessonId(lesson.id); }}
                onDragLeave={() => setDragOverLessonId(null)}
                onDrop={() => handleLessonDrop(lesson.id)}
                onDragEnd={() => { setDragLessonId(null); setDragOverLessonId(null); }}
                className={[
                  "flex items-center justify-between rounded-xl border bg-white px-5 py-3 shadow-sm transition-all cursor-grab active:cursor-grabbing",
                  dragOverLessonId === lesson.id && dragLessonId !== lesson.id ? "border-blue-400 bg-blue-50 scale-[1.01]" : "border-gray-200",
                  dragLessonId === lesson.id ? "opacity-50" : "",
                ].join(" ")}>
                <div className="flex items-center gap-4">
                  {/* Drag handle */}
                  <svg className="h-4 w-4 text-gray-300 flex-shrink-0" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8.5 6a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm7 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm-7 7a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm7 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm-7 7a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm7 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
                  </svg>
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gray-100 text-xs font-semibold text-gray-600">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <Link href={`/admin/lessons/${lesson.id}`} className="font-medium text-gray-900 hover:text-blue-600">
                        {lesson.title}
                      </Link>
                      {lesson.isFreeTrial && (
                        <span className="rounded bg-blue-50 px-1.5 py-0.5 text-xs font-medium text-blue-600">Free</span>
                      )}
                      <span className="rounded bg-gray-100 px-1.5 py-0.5 text-xs text-gray-500">{lesson.lessonType}</span>
                    </div>
                    <div className="mt-0.5 flex items-center gap-3 text-xs text-gray-400">
                      {lesson.videoStatus && <span>{VIDEO_STATUS[lesson.videoStatus] ?? lesson.videoStatus}</span>}
                      <span>{lesson.documentCount} tài liệu</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Link href={`/admin/lessons/${lesson.id}`} className="rounded bg-gray-100 px-2 py-1 text-xs text-gray-700 hover:bg-gray-200">
                    Xem
                  </Link>
                  <Link href={`/admin/lessons/${lesson.id}?edit=true`} className="rounded bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-200">
                    Sửa
                  </Link>
                  <button
                    onClick={() => handleDeleteLesson(lesson.id, lesson.title)}
                    className="rounded bg-red-50 px-2 py-1 text-xs text-red-600 hover:bg-red-100"
                  >
                    Xóa
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      )} {/* end lessons tab */}

      {/* Sessions tab */}
      {activeTab === "sessions" && (
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Session tương tác ({sessions?.length ?? 0})</h2>
          <button
            onClick={() => setShowAddSession(true)}
            className="rounded-lg bg-purple-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-purple-700"
          >
            + Thêm session
          </button>
        </div>

        {(!sessions || sessions.length === 0) ? (
          <div className="rounded-xl border border-dashed border-gray-300 py-12 text-center text-gray-400">
            Chưa có session tương tác nào.
          </div>
        ) : (
          <div className="space-y-2">
            {[...sessions].sort((a, b) => a.orderIndex - b.orderIndex).map((session, idx) => (
              <div key={session.id} className="flex items-center justify-between rounded-xl border border-gray-200 bg-white px-5 py-3 shadow-sm">
                <div className="flex items-center gap-4">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-purple-50 text-xs font-semibold text-purple-700">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <Link href={`/admin/sessions/${session.id}`} className="font-medium text-gray-900 hover:text-purple-600">
                        {session.title}
                      </Link>
                      {session.isFreeTrial && (
                        <span className="rounded bg-blue-50 px-1.5 py-0.5 text-xs font-medium text-blue-600">Free</span>
                      )}
                      <span className={[
                        "rounded px-1.5 py-0.5 text-xs font-medium",
                        session.publishStatus === "Published" ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-500",
                      ].join(" ")}>
                        {session.publishStatus}
                      </span>
                    </div>
                    <div className="mt-0.5 flex items-center gap-3 text-xs text-gray-400">
                      <span>🎬 {session.segmentCount} segment</span>
                      {session.durationSeconds > 0 && (
                        <span>⏱ {Math.round(session.durationSeconds / 60)} phút</span>
                      )}
                      {session.videoStatus && (
                        <span className={session.videoStatus === "Ready" ? "text-green-600" : "text-orange-500"}>
                          {session.videoStatus === "Ready" ? "✅ Video sẵn sàng" : `⚙️ ${session.videoStatus}`}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Link href={`/admin/sessions/${session.id}`} className="rounded bg-purple-100 px-2 py-1 text-xs font-medium text-purple-700 hover:bg-purple-200">
                    Chỉnh sửa
                  </Link>
                  <button
                    onClick={() => handleDeleteSession(session.id, session.title)}
                    className="rounded bg-red-50 px-2 py-1 text-xs text-red-600 hover:bg-red-100"
                  >
                    Xóa
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      )} {/* end sessions tab */}

      {/* Add Session Modal */}
      {showAddSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
            <h2 className="mb-4 text-lg font-semibold">Thêm session tương tác</h2>
            <form onSubmit={handleAddSession} className="space-y-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">Tên session *</label>
                <input
                  required
                  value={sessionForm.title}
                  onChange={(e) => setSessionForm({ ...sessionForm, title: e.target.value })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="VD: Buổi học 1: Present Simple"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">Mô tả ngắn</label>
                <textarea
                  value={sessionForm.description}
                  onChange={(e) => setSessionForm({ ...sessionForm, description: e.target.value })}
                  rows={2}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={sessionForm.isFreeTrial}
                  onChange={(e) => setSessionForm({ ...sessionForm, isFreeTrial: e.target.checked })}
                  className="rounded"
                />
                <span className="font-medium text-gray-700">Học thử miễn phí</span>
              </label>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowAddSession(false)} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">Hủy</button>
                <button type="submit" disabled={creatingSession} className="rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700 disabled:opacity-60">
                  {creatingSession ? "Đang thêm..." : "Thêm"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAddLesson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
            <h2 className="mb-4 text-lg font-semibold">Thêm bài học</h2>
            <form onSubmit={handleAddLesson} className="space-y-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">Loại bài học</label>
                <select
                  value={lessonForm.lessonType}
                  onChange={(e) => setLessonForm({ ...lessonForm, lessonType: e.target.value })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Video">🎬 Video</option>
                  <option value="Reading">📖 Reading (văn bản)</option>
                  <option value="Audio">🎧 Audio</option>
                  <option value="Pdf">📄 PDF</option>
                  <option value="Quiz">❓ Quiz</option>
                  <option value="Assignment">📝 Assignment</option>
                  <option value="Live">📡 Live</option>
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">Tên bài học *</label>
                <input
                  required
                  value={lessonForm.title}
                  onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">Mô tả ngắn</label>
                <textarea
                  value={lessonForm.description}
                  onChange={(e) => setLessonForm({ ...lessonForm, description: e.target.value })}
                  rows={2}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={lessonForm.isFreeTrial}
                  onChange={(e) => setLessonForm({ ...lessonForm, isFreeTrial: e.target.checked })}
                  className="rounded"
                />
                <span className="font-medium text-gray-700">Học thử miễn phí</span>
              </label>
              {(lessonForm.lessonType === "Reading" || lessonForm.lessonType === "Assignment") && (
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">Nội dung bài học</label>
                  <RichTextEditor
                    value={lessonForm.content}
                    onChange={(val) => setLessonForm({ ...lessonForm, content: val })}
                    placeholder="Nhập nội dung bài học..."
                    height={200}
                  />
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">Thời lượng (phút)</label>
                  <input
                    type="number" min={0}
                    value={lessonForm.durationMinutes}
                    onChange={(e) => setLessonForm({ ...lessonForm, durationMinutes: e.target.value })}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="VD: 15"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">Điểm qua (Quiz)</label>
                  <input
                    type="number" min={0} max={100}
                    value={lessonForm.passScore}
                    onChange={(e) => setLessonForm({ ...lessonForm, passScore: Number(e.target.value) })}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowAddLesson(false)} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">Hủy</button>
                <button type="submit" disabled={creatingLesson} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                  {creatingLesson ? "Đang thêm..." : "Thêm"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}