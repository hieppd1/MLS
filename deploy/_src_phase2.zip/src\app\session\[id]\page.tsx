"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  useGetSessionQuery,
  useStartSessionMutation,
  useSaveSessionVideoPositionMutation,
  useCompleteSessionMutation,
  useMarkSegmentViewedMutation,
  useCompleteSegmentMutation,
  useRecordAssetInteractionMutation,
  type SegmentLearningDto,
  type SegmentAssetDto,
} from "@/lib/features/learning/learningApi";
import HlsPlayer from "@/components/video/HlsPlayer";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtTime(seconds: number): string {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function parseMetadata(raw: string): Record<string, unknown> {
  try { return JSON.parse(raw); } catch { return {}; }
}

// ── Asset Panel Components ────────────────────────────────────────────────────

interface AssetPanelProps {
  asset: SegmentAssetDto;
  onInteract?: (interactionType: string) => void;
}

function NoteBlockPanel({ asset, onInteract }: AssetPanelProps) {
  const meta = parseMetadata(asset.metadata) as { content?: string; highlights?: string[] };
  useEffect(() => { onInteract?.("view"); }, []);

  return (
    <div className="rounded-xl border border-yellow-700/40 bg-yellow-900/20 p-4">
      <div className="mb-2 flex items-center gap-2">
        <span className="text-yellow-400">📝</span>
        <h4 className="font-semibold text-yellow-300 text-sm">{asset.title}</h4>
      </div>
      <p className="text-sm text-gray-300 leading-relaxed">{meta.content}</p>
      {meta.highlights && meta.highlights.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {meta.highlights.map((h, i) => (
            <span key={i} className="rounded-full bg-yellow-800/50 px-2 py-0.5 text-xs text-yellow-200">{h}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function GrammarBlockPanel({ asset, onInteract }: AssetPanelProps) {
  const meta = parseMetadata(asset.metadata) as { pattern?: string; examples?: { vi: string; en: string }[]; keywords?: string[] };
  useEffect(() => { onInteract?.("view"); }, []);

  return (
    <div className="rounded-xl border border-blue-700/40 bg-blue-900/20 p-4">
      <div className="mb-2 flex items-center gap-2">
        <span className="text-blue-400">📐</span>
        <h4 className="font-semibold text-blue-300 text-sm">{asset.title}</h4>
      </div>
      {meta.pattern && (
        <div className="mb-3 rounded-lg bg-blue-950/60 px-3 py-2 font-mono text-sm text-blue-200">
          {meta.pattern}
        </div>
      )}
      {meta.examples && meta.examples.length > 0 && (
        <div className="space-y-2">
          {meta.examples.map((ex, i) => (
            <div key={i} className="rounded-lg bg-gray-800/60 px-3 py-2 text-sm">
              <div className="font-medium text-white">{ex.vi}</div>
              <div className="text-gray-400">{ex.en}</div>
            </div>
          ))}
        </div>
      )}
      {meta.keywords && meta.keywords.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {meta.keywords.map((k, i) => (
            <span key={i} className="rounded-full bg-blue-800/50 px-2 py-0.5 text-xs text-blue-200">{k}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function VocabularyBlockPanel({ asset, onInteract }: AssetPanelProps) {
  const meta = parseMetadata(asset.metadata) as { words?: { word: string; ipa?: string; meaning: string; example?: string; exampleTranslation?: string }[] };
  const [expanded, setExpanded] = useState<number | null>(null);
  useEffect(() => { onInteract?.("view"); }, []);

  return (
    <div className="rounded-xl border border-green-700/40 bg-green-900/20 p-4">
      <div className="mb-3 flex items-center gap-2">
        <span className="text-green-400">📚</span>
        <h4 className="font-semibold text-green-300 text-sm">{asset.title}</h4>
        {meta.words && <span className="ml-auto text-xs text-gray-500">{meta.words.length} từ</span>}
      </div>
      <div className="space-y-1.5">
        {meta.words?.map((w, i) => (
          <div key={i} className="rounded-lg overflow-hidden border border-gray-700/50">
            <button
              onClick={() => setExpanded(expanded === i ? null : i)}
              className="flex w-full items-center gap-3 px-3 py-2 text-left text-sm transition hover:bg-gray-800/60"
            >
              <span className="font-semibold text-green-300 min-w-[80px]">{w.word}</span>
              {w.ipa && <span className="text-xs text-gray-500">{w.ipa}</span>}
              <span className="flex-1 text-gray-300">{w.meaning}</span>
              <svg className={`h-3.5 w-3.5 text-gray-500 shrink-0 transition-transform ${expanded === i ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {expanded === i && w.example && (
              <div className="border-t border-gray-700/50 bg-gray-800/40 px-3 py-2 text-xs">
                <div className="italic text-gray-300">{w.example}</div>
                <div className="mt-0.5 text-gray-500">{w.exampleTranslation}</div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function AssetPanel(props: AssetPanelProps) {
  switch (props.asset.type) {
    case "NoteBlock":      return <NoteBlockPanel {...props} />;
    case "GrammarBlock":   return <GrammarBlockPanel {...props} />;
    case "VocabularyBlock": return <VocabularyBlockPanel {...props} />;
    default:
      return (
        <div className="rounded-xl border border-gray-700 bg-gray-800/30 p-4 text-sm text-gray-400">
          <span className="font-medium text-white">{props.asset.title}</span>
          <span className="ml-2 text-xs">({props.asset.type})</span>
        </div>
      );
  }
}

// ── Segment Timeline Bar ──────────────────────────────────────────────────────

interface TimelineBarProps {
  segments: SegmentLearningDto[];
  duration: number;
  currentTime: number;
  onJump: (time: number) => void;
}

function SegmentTimelineBar({ segments, duration, currentTime, onJump }: TimelineBarProps) {
  if (!duration || !segments.length) return null;

  return (
    <div className="flex h-2 w-full overflow-hidden rounded-full bg-gray-800 cursor-pointer" title="Jump to segment">
      {segments.map((seg, i) => {
        const left = (seg.startTime / duration) * 100;
        const width = ((seg.endTime - seg.startTime) / duration) * 100;
        const isActive = currentTime >= seg.startTime && currentTime < seg.endTime;
        const isViewed = seg.progress?.isViewed ?? false;
        const isCompleted = seg.progress?.isCompleted ?? false;

        return (
          <div
            key={seg.id}
            className="relative"
            style={{ width: `${width}%`, marginLeft: i === 0 ? `${left}%` : undefined }}
          >
            <div
              onClick={() => onJump(seg.startTime)}
              className={[
                "h-full w-full rounded-sm transition",
                isActive ? "bg-blue-400" : isCompleted ? "bg-green-500/70" : isViewed ? "bg-blue-700/60" : "bg-gray-600/60",
                "hover:opacity-80",
              ].join(" ")}
              title={seg.title}
            />
          </div>
        );
      })}
      {/* playhead */}
      <div
        className="absolute top-0 h-2 w-0.5 bg-white/80 rounded-full"
        style={{ left: `${(currentTime / duration) * 100}%` }}
      />
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function SessionPlayerPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeSegmentId, setActiveSegmentId] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const seekRef = useRef<((t: number) => void) | null>(null);
  const positionSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data: session, isLoading } = useGetSessionQuery(id, { skip: !id });
  const [startSession]           = useStartSessionMutation();
  const [saveVideoPosition]      = useSaveSessionVideoPositionMutation();
  const [completeSession]        = useCompleteSessionMutation();
  const [markSegmentViewed]      = useMarkSegmentViewedMutation();
  const [completeSegment]        = useCompleteSegmentMutation();
  const [recordAssetInteraction] = useRecordAssetInteractionMutation();

  // Start session on mount
  useEffect(() => {
    if (session && !session.progress) startSession(id);
  }, [session, id, startSession]);

  // Resume position
  useEffect(() => {
    if (session?.progress?.lastPositionSeconds && session.progress.lastPositionSeconds > 5) {
      setCurrentTime(session.progress.lastPositionSeconds);
    }
  }, [session?.progress?.lastPositionSeconds]);

  // Update active segment based on currentTime
  useEffect(() => {
    if (!session?.segments) return;
    const seg = session.segments.find(
      (s) => currentTime >= s.startTime && currentTime < s.endTime
    );
    if (seg && seg.id !== activeSegmentId) {
      setActiveSegmentId(seg.id);
      // mark segment as viewed
      if (!seg.progress?.isViewed) {
        markSegmentViewed(seg.id);
      }
    }
  }, [currentTime, session?.segments, activeSegmentId, markSegmentViewed]);

  const handleTimeUpdate = useCallback((time: number) => {
    setCurrentTime(time);

    // Throttle position save — debounce 5s
    if (positionSaveTimer.current) clearTimeout(positionSaveTimer.current);
    positionSaveTimer.current = setTimeout(() => {
      if (session?.durationSeconds) {
        const watchPct = Math.min((time / session.durationSeconds) * 100, 100);
        saveVideoPosition({
          id,
          lastPositionSeconds: Math.floor(time),
          watchedSeconds: Math.floor(time),
          watchPercentage: watchPct,
        });
      }
    }, 5000);
  }, [id, session?.durationSeconds, saveVideoPosition]);

  const handleEnded = useCallback(async () => {
    await completeSession(id);
  }, [id, completeSession]);

  const handleJumpToTime = useCallback((time: number) => {
    setCurrentTime(time);
    seekRef.current?.(time);
  }, []);

  const handleAssetInteract = useCallback(
    (assetId: string, interactionType: string) => {
      recordAssetInteraction({ id: assetId, interactionType });
    },
    [recordAssetInteraction]
  );

  const handleCompleteSegment = useCallback(
    (segmentId: string) => {
      completeSegment(segmentId);
    },
    [completeSegment]
  );

  // ── Loading ──────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-56px)] items-center justify-center bg-gray-950">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-t-transparent" style={{ borderColor: "#7C3AED", borderTopColor: "transparent" }} />
      </div>
    );
  }
  if (!session) {
    return (
      <div className="flex h-[calc(100vh-56px)] items-center justify-center bg-gray-950 text-white">
        <p className="text-gray-400">Không tìm thấy session.</p>
      </div>
    );
  }

  const activeSegment = session.segments.find((s) => s.id === activeSegmentId) ?? session.segments[0] ?? null;
  const isSessionCompleted = session.progress?.status === "Completed";

  // Assets to show for the active segment that are in range (startTime <= currentTime)
  const visibleAssets = activeSegment
    ? activeSegment.assets.filter((a) => currentTime >= a.startTime)
    : [];

  return (
    <div className="flex h-[calc(100vh-56px)] overflow-hidden bg-gray-950 text-white">

      {/* ════════════════════════════════════════════════════
          MAIN AREA — Video + Active Segment
      ════════════════════════════════════════════════════ */}
      <div className="flex min-w-0 flex-1 flex-col overflow-y-auto">

        {/* Sub-header */}
        <div className="flex shrink-0 items-center gap-2 border-b border-gray-800 bg-gray-900 px-4 py-2 text-sm">
          <button onClick={() => router.back()} className="flex items-center gap-1 text-gray-400 transition hover:text-white">
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Quay lại
          </button>
          <span className="mx-2 text-gray-700">|</span>
          <span className="truncate font-medium text-white">{session.title}</span>

          <div className="ml-auto flex items-center gap-2">
            {isSessionCompleted && (
              <span className="flex items-center gap-1 rounded-full bg-green-900/40 px-2.5 py-1 text-xs font-semibold text-green-400">
                <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
                Hoàn thành
              </span>
            )}
            {session.progress && !isSessionCompleted && (
              <span className="text-xs text-gray-500">
                {Math.round(session.progress.watchPercentage)}% đã xem
              </span>
            )}
            <button
              onClick={() => setSidebarOpen((o) => !o)}
              className="flex items-center gap-1.5 rounded-lg border border-gray-700 px-3 py-1.5 text-xs text-gray-400 transition hover:text-white lg:hidden"
            >
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              Phân đoạn
            </button>
          </div>
        </div>

        {/* Video */}
        <div className="shrink-0 bg-black">
          {session.videoAsset?.hlsPath ? (
            <HlsPlayer
              src={`${API_BASE}/media/${session.videoAsset.hlsPath}`}
              lessonId={id}
              onEnded={handleEnded}
              startTime={session.progress?.lastPositionSeconds && session.progress.lastPositionSeconds > 5 ? session.progress.lastPositionSeconds : 0}
              onTimeUpdate={handleTimeUpdate}
              seekRef={seekRef}
            />
          ) : (
            <div
              className="flex w-full flex-col items-center justify-center gap-3 bg-gray-900 text-gray-500"
              style={{ aspectRatio: "16/9" }}
            >
              <svg className="h-14 w-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.723v6.554a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              <p className="text-sm">Chưa có video cho session này</p>
            </div>
          )}
        </div>

        {/* Segment Timeline Bar */}
        <div className="shrink-0 px-4 py-2 bg-gray-900/60 border-b border-gray-800">
          <div className="relative">
            <SegmentTimelineBar
              segments={session.segments}
              duration={session.durationSeconds}
              currentTime={currentTime}
              onJump={handleJumpToTime}
            />
          </div>
          <div className="mt-1 flex items-center justify-between text-xs text-gray-600">
            <span>{fmtTime(currentTime)}</span>
            <span>{fmtTime(session.durationSeconds)}</span>
          </div>
        </div>

        {/* Active Segment Panel */}
        {activeSegment && (
          <div className="shrink-0 border-b border-gray-800 bg-gray-900/40 px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold text-white" style={{ background: "#7C3AED" }}>
                  {activeSegment.orderIndex + 1}
                </span>
                <div>
                  <h3 className="text-sm font-semibold text-white">{activeSegment.title}</h3>
                  <p className="text-xs text-gray-500">{fmtTime(activeSegment.startTime)} – {fmtTime(activeSegment.endTime)}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {activeSegment.progress?.isCompleted ? (
                  <span className="text-xs text-green-400 flex items-center gap-1">
                    <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                    </svg>
                    Xong
                  </span>
                ) : (
                  <button
                    onClick={() => handleCompleteSegment(activeSegment.id)}
                    className="rounded-lg bg-purple-800/50 px-3 py-1 text-xs font-medium text-purple-300 transition hover:bg-purple-700/60"
                  >
                    Đánh dấu xong
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Assets for active segment */}
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {activeSegment ? (
            <div>
              {activeSegment.description && (
                <p className="mb-4 text-sm text-gray-400">{activeSegment.description}</p>
              )}

              {visibleAssets.length === 0 && (
                <p className="text-sm text-gray-600 italic">
                  {activeSegment.assets.length > 0
                    ? "Tiếp tục xem video — nội dung học sẽ xuất hiện theo tiến trình..."
                    : "Không có tài nguyên học cho phân đoạn này."}
                </p>
              )}

              <div className="space-y-3">
                {visibleAssets.map((asset) => (
                  <AssetPanel
                    key={asset.id}
                    asset={asset}
                    onInteract={(type) => handleAssetInteract(asset.id, type)}
                  />
                ))}
              </div>

              {/* Future assets hint */}
              {activeSegment.assets.length > visibleAssets.length && (
                <div className="mt-4 flex items-center gap-2 text-xs text-gray-600">
                  <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {activeSegment.assets.length - visibleAssets.length} nội dung sẽ xuất hiện khi bạn xem tiếp...
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-600">Nhấn play để bắt đầu session.</p>
          )}
        </div>
      </div>

      {/* ════════════════════════════════════════════════════
          SIDEBAR — Segment List
      ════════════════════════════════════════════════════ */}

      {sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside
        className={[
          "fixed right-0 z-30 flex flex-col",
          "top-[56px] h-[calc(100vh-56px)] w-72 shrink-0",
          "border-l border-gray-800 bg-gray-900",
          "transition-transform duration-300 ease-in-out",
          "lg:relative lg:top-auto lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "translate-x-full",
        ].join(" ")}
      >
        <div className="flex shrink-0 items-center justify-between border-b border-gray-800 px-4 py-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">
            Phân đoạn ({session.segments.length})
          </span>
          <button
            onClick={() => setSidebarOpen(false)}
            className="rounded p-1 text-gray-500 transition hover:bg-gray-800 hover:text-white lg:hidden"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Session progress summary */}
        {session.progress && (
          <div className="shrink-0 border-b border-gray-800 px-4 py-3">
            <div className="mb-1.5 flex items-center justify-between text-xs text-gray-500">
              <span>Tiến độ</span>
              <span>{Math.round(session.progress.watchPercentage)}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-gray-700">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${Math.round(session.progress.watchPercentage)}%`, backgroundColor: "#7C3AED" }}
              />
            </div>
          </div>
        )}

        {/* Segment list */}
        <div className="flex-1 overflow-y-auto">
          {session.segments.map((seg) => {
            const isActive = seg.id === activeSegmentId;
            const isViewed = seg.progress?.isViewed ?? false;
            const isCompleted = seg.progress?.isCompleted ?? false;

            return (
              <button
                key={seg.id}
                onClick={() => {
                  handleJumpToTime(seg.startTime);
                  setSidebarOpen(false);
                }}
                className={[
                  "flex w-full items-start gap-3 border-l-2 px-4 py-3 text-left text-sm transition",
                  isActive
                    ? "border-purple-500 bg-purple-950/50 text-white"
                    : "border-transparent text-gray-400 hover:bg-gray-800/60 hover:text-gray-200",
                ].join(" ")}
              >
                {/* Status icon */}
                <span className="mt-0.5 shrink-0">
                  {isCompleted ? (
                    <svg className="h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                    </svg>
                  ) : isViewed ? (
                    <svg className="h-4 w-4 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  ) : isActive ? (
                    <svg className="h-4 w-4 text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                    </svg>
                  ) : (
                    <span className="flex h-4 w-4 items-center justify-center rounded-full border border-gray-600 text-xs text-gray-600">
                      {seg.orderIndex + 1}
                    </span>
                  )}
                </span>

                <div className="min-w-0 flex-1">
                  <div className={`text-sm leading-snug ${isActive ? "font-medium text-white" : ""}`}>
                    {seg.title}
                  </div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-gray-600">
                    <span>{fmtTime(seg.startTime)} – {fmtTime(seg.endTime)}</span>
                    {seg.assets.length > 0 && (
                      <span>· {seg.assets.length} tài nguyên</span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Complete session CTA */}
        {!isSessionCompleted && (
          <div className="shrink-0 border-t border-gray-800 p-4">
            <button
              onClick={() => completeSession(id)}
              className="w-full rounded-xl py-2.5 text-sm font-semibold text-white transition hover:opacity-90"
              style={{ background: "#7C3AED" }}
            >
              Hoàn thành Session
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
