﻿"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";
import {
  useGetPublicCourseQuery,
  useEnrollCourseMutation,
} from "@/lib/features/courses/coursesApi";

const LEVEL_LABELS: Record<number, string> = {
  1: "Cấp 1 — Nhập môn", 2: "Cấp 2 — Cơ bản",
  3: "Cấp 3 — Sơ trung",  4: "Cấp 4 — Trung cấp",
  5: "Cấp 5 — Trung cao",  6: "Cấp 6 — Nâng cao",
};

function formatDuration(seconds: number) {
  if (!seconds) return "";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}g ${m}p`;
  return `${m} phút`;
}

function formatPrice(price: number | null | undefined) {
  if (price == null || price === 0) return "Miễn phí";
  return price.toLocaleString("vi-VN") + "đ";
}

function discountPct(price: number, discountPrice: number) {
  if (!price || !discountPrice) return 0;
  return Math.round((1 - discountPrice / price) * 100);
}

type TabKey = "intro" | "content" | "reviews";

export default function KhoaHocDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [openModules, setOpenModules] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<TabKey>("intro");

  const { data: course, isLoading } = useGetPublicCourseQuery(id, { skip: !id });
  const [enroll, { isLoading: enrolling }] = useEnrollCourseMutation();

  function toggleModule(moduleId: string) {
    setOpenModules((prev) => {
      const next = new Set(prev);
      if (next.has(moduleId)) next.delete(moduleId); else next.add(moduleId);
      return next;
    });
  }

  async function handleEnroll() {
    await enroll(id);
    router.refresh();
  }

  if (isLoading) {
    return (
      <div style={{ minHeight: "100vh", background: "#F1F5F9" }}>
        <div style={{ height: 340, background: "#0D47A1" }} />
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "32px 16px", display: "flex", gap: 24 }}>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 16 }}>
            {[1, 2, 3].map(i => (
              <div key={i} style={{ height: 18, background: "#E5E7EB", borderRadius: 6, width: i === 1 ? "70%" : i === 2 ? "90%" : "50%" }} />
            ))}
          </div>
          <div style={{ width: 320, height: 400, background: "#E5E7EB", borderRadius: 16 }} />
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <p style={{ color: "#9CA3AF", fontSize: 16 }}>Không tìm thấy khóa học.</p>
      </div>
    );
  }

  const totalLessons = course.modules.reduce((s, m) => s + m.lessons.length, 0);
  const totalDuration = course.modules.flatMap((m) => m.lessons).reduce((s, l) => s + (l.durationSeconds ?? 0), 0);
  const completedLessons = course.modules.flatMap((m) => m.lessons).filter((l) => l.isCompleted).length;
  const progressPct = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
  const firstLessonId = course.modules[0]?.lessons[0]?.id ?? "";
  const coursePrice = course.price ?? 0;
  const hasDiscount = course.discountPrice != null && course.discountPrice < coursePrice;
  const pct = hasDiscount ? discountPct(coursePrice, course.discountPrice!) : 0;
  const thumbUrl = safeImgUrl(course.thumbnailUrl);
  const bannerUrl = safeImgUrl(course.bannerUrl);

  const tabs: { key: TabKey; label: string }[] = [
    { key: "intro", label: "Giới thiệu" },
    { key: "content", label: `Nội dung (${totalLessons} bài)` },
    { key: "reviews", label: "Đánh giá" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#F1F5F9" }}>

      {/* HERO — banner ảnh nền + overlay tối + thông tin + card */}
      <div style={{ position: "relative", overflow: "hidden", background: "#0D47A1" }}>
        {(bannerUrl || thumbUrl) && (
          <img src={bannerUrl ?? thumbUrl!} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 1 }} />
        )}
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(5,30,90,0.88) 0%, rgba(10,50,140,0.72) 55%, rgba(10,50,140,0.45) 100%)" }} />
        <div style={{ position: "relative", maxWidth: 1180, margin: "0 auto", padding: "32px 16px 28px" }}>
          <div style={{ display: "flex", gap: 32, alignItems: "flex-start" }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <span style={{ display: "inline-block", marginBottom: 10, padding: "3px 12px", borderRadius: 999, fontSize: 12, fontWeight: 700, background: "rgba(255,107,53,0.85)", color: "#fff" }}>
                {LEVEL_LABELS[course.level] ?? `Cấp ${course.level}`}
              </span>
              <h1 style={{ fontSize: 26, fontWeight: 800, color: "#fff", margin: "0 0 8px", lineHeight: 1.35 }}>{course.title}</h1>
              {course.shortDescription && (
                <p style={{ fontSize: 14, color: "rgba(255,255,255,0.75)", lineHeight: 1.7, maxWidth: 620, margin: "0 0 16px" }}>{course.shortDescription}</p>
              )}
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: course.isEnrolled && totalLessons > 0 ? 16 : 0 }}>
                {course.teacherName && (
                  <div style={{ display: "flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,0.12)", borderRadius: 999, padding: "4px 12px" }}>
                    <div style={{ width: 20, height: 20, borderRadius: "50%", background: "#FF6B35", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#fff", flexShrink: 0 }}>
                      {course.teacherName[0]}
                    </div>
                    <span style={{ fontSize: 13, color: "rgba(255,255,255,0.9)", fontWeight: 500 }}>{course.teacherName}</span>
                  </div>
                )}
                {[
                  { icon: "📚", text: `${course.modules.length} chương` },
                  { icon: "🎯", text: `${totalLessons} bài học` },
                  ...(totalDuration > 0 ? [{ icon: "⏱", text: formatDuration(totalDuration) }] : []),
                ].map(({ icon, text }) => (
                  <div key={text} style={{ display: "flex", alignItems: "center", gap: 5, background: "rgba(255,255,255,0.12)", borderRadius: 999, padding: "4px 12px" }}>
                    <span style={{ fontSize: 13 }}>{icon}</span>
                    <span style={{ fontSize: 13, color: "rgba(255,255,255,0.85)" }}>{text}</span>
                  </div>
                ))}
              </div>
              {course.isEnrolled && totalLessons > 0 && (
                <div style={{ background: "rgba(255,255,255,0.1)", borderRadius: 10, padding: "12px 16px", maxWidth: 420, border: "1px solid rgba(255,255,255,0.15)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "rgba(255,255,255,0.7)", marginBottom: 6 }}>
                    <span>Tiến độ học tập</span>
                    <span style={{ fontWeight: 700, color: progressPct === 100 ? "#4ADE80" : "#93C5FD" }}>{completedLessons}/{totalLessons} bài ({progressPct}%)</span>
                  </div>
                  <div style={{ height: 6, background: "rgba(255,255,255,0.2)", borderRadius: 99, overflow: "hidden" }}>
                    <div style={{ height: "100%", borderRadius: 99, width: `${progressPct}%`, background: progressPct === 100 ? "#4ADE80" : "#60A5FA", transition: "width 0.4s ease" }} />
                  </div>
                </div>
              )}
            </div>
            <div className="kh-card-desktop" style={{ width: 340, flexShrink: 0 }}>
              <EnrollCard course={course} firstLessonId={firstLessonId} enrolling={enrolling} onEnroll={handleEnroll} hasDiscount={hasDiscount} pct={pct} thumbUrl={thumbUrl} />
            </div>
          </div>
        </div>
      </div>

      <div className="kh-card-mobile" style={{ maxWidth: 1180, margin: "0 auto", padding: "16px 16px 0" }}>
        <EnrollCard course={course} firstLessonId={firstLessonId} enrolling={enrolling} onEnroll={handleEnroll} hasDiscount={hasDiscount} pct={pct} thumbUrl={thumbUrl} />
      </div>

      <div style={{ position: "sticky", top: 56, zIndex: 20, background: "#fff", borderBottom: "2px solid #E5E7EB", boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 16px" }}>
          <nav style={{ display: "flex", gap: 4 }}>
            {tabs.map(({ key, label }) => {
              const active = activeTab === key;
              return (
                <button key={key} onClick={() => setActiveTab(key)} style={{ padding: "14px 20px", fontSize: 14, fontWeight: active ? 700 : 500, border: "none", borderBottom: active ? "3px solid #1565C0" : "3px solid transparent", background: "transparent", cursor: "pointer", color: active ? "#1565C0" : "#6B7280", transition: "all 0.15s", marginBottom: -2 }}>
                  {label}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "32px 16px 80px", display: "flex", gap: 28, alignItems: "flex-start" }}>
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 20 }}>

          {activeTab === "intro" && (
            <>
              <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E5E7EB", overflow: "hidden" }}>
                <div style={{ padding: "18px 24px", borderBottom: "1px solid #F3F4F6" }}>
                  <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "#111827" }}>Thông tin khóa học</h2>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0 }}>
                  {[
                    { icon: "👤", label: "Đối tượng học", value: LEVEL_LABELS[course.level] ?? `Cấp ${course.level}` },
                    { icon: "⏱", label: "Tổng thời lượng", value: totalDuration > 0 ? formatDuration(totalDuration) : "—" },
                    { icon: "📚", label: "Số bài học", value: `${totalLessons} bài / ${course.modules.length} chương` },
                    { icon: "🌐", label: "Ngôn ngữ", value: course.language === "VI" ? "Tiếng Việt" : (course.language ?? "Tiếng Việt") },
                    ...(course.teacherName ? [{ icon: "🎓", label: "Giảng viên", value: course.teacherName }] : []),
                    ...(course.tags ? [{ icon: "🏷", label: "Tags", value: course.tags }] : []),
                  ].map(({ icon, label, value }, i) => (
                    <div key={label} style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "14px 24px", borderBottom: "1px solid #F9FAFB", borderRight: i % 2 === 0 ? "1px solid #F3F4F6" : "none" }}>
                      <span style={{ fontSize: 18, lineHeight: 1, marginTop: 2 }}>{icon}</span>
                      <div>
                        <p style={{ margin: 0, fontSize: 11, color: "#9CA3AF", fontWeight: 500, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</p>
                        <p style={{ margin: 0, fontSize: 14, color: "#111827", fontWeight: 600, marginTop: 2 }}>{value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E5E7EB", overflow: "hidden" }}>
                <div style={{ padding: "18px 24px", borderBottom: "1px solid #F3F4F6" }}>
                  <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "#111827" }}>Mục tiêu chương trình học</h2>
                </div>
                <div style={{ padding: "20px 24px" }}>
                  <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px 24px" }}>
                    {[
                      "Giao tiếp tự tin trong các tình huống thực tế",
                      "Nắm vững ngữ pháp và từ vựng theo cấp độ",
                      "Hiểu và sử dụng tiếng Việt văn viết lẫn văn nói",
                      "Nhận chứng chỉ được công nhận sau khi hoàn thành",
                    ].map((item) => (
                      <li key={item} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                        <svg width="18" height="18" viewBox="0 0 20 20" fill="none" style={{ flexShrink: 0, marginTop: 2 }}>
                          <circle cx="10" cy="10" r="10" fill="#DBEAFE" />
                          <path d="M6 10l3 3 5-5" stroke="#1565C0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        <span style={{ fontSize: 14, color: "#374151", lineHeight: 1.5 }}>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E5E7EB", overflow: "hidden" }}>
                <div style={{ padding: "18px 24px", borderBottom: "1px solid #F3F4F6" }}>
                  <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "#111827" }}>Giới thiệu chi tiết</h2>
                </div>
                <div style={{ padding: "20px 24px" }}>
                  {course.description ? (
                    <div className="prose-kh" dangerouslySetInnerHTML={{ __html: course.description }} />
                  ) : (
                    <p style={{ color: "#9CA3AF", fontSize: 14 }}>Chưa có mô tả chi tiết.</p>
                  )}
                </div>
              </div>
            </>
          )}

          {activeTab === "content" && (
            <div>
              <div style={{ marginBottom: 16, display: "flex", gap: 24, flexWrap: "wrap", background: "#EFF6FF", borderRadius: 12, padding: "14px 20px", fontSize: 14, color: "#1E40AF", border: "1px solid #BFDBFE" }}>
                <span>📚 <strong>{course.modules.length}</strong> chương</span>
                <span>🎯 <strong>{totalLessons}</strong> bài học</span>
                {totalDuration > 0 && <span>⏱ Tổng <strong>{formatDuration(totalDuration)}</strong></span>}
              </div>
              {course.modules.length === 0 ? (
                <div style={{ background: "#fff", borderRadius: 16, padding: 40, textAlign: "center", color: "#9CA3AF", border: "1px solid #E5E7EB" }}>Chưa có nội dung.</div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {course.modules.map((mod, mIdx) => {
                    const isOpen = openModules.has(mod.id);
                    const modDuration = mod.lessons.reduce((s, l) => s + (l.durationSeconds ?? 0), 0);
                    return (
                      <div key={mod.id} style={{ borderRadius: 14, overflow: "hidden", border: "1px solid #E5E7EB", background: "#fff" }}>
                        <button onClick={() => toggleModule(mod.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, background: isOpen ? "#EFF6FF" : "#F9FAFB", padding: "14px 20px", border: "none", cursor: "pointer", textAlign: "left", borderBottom: isOpen ? "1px solid #BFDBFE" : "none" }}>
                          <span style={{ width: 30, height: 30, borderRadius: "50%", background: "#1565C0", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: "#fff", flexShrink: 0 }}>{mIdx + 1}</span>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#111827" }}>{mod.title}</p>
                          </div>
                          <span style={{ fontSize: 12, color: "#9CA3AF", whiteSpace: "nowrap" }}>{mod.lessons.length + (mod.sessions?.length ?? 0)} nội dung{modDuration > 0 ? ` · ${formatDuration(modDuration)}` : ""}</span>
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2" style={{ flexShrink: 0, transform: isOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                          </svg>
                        </button>
                        {isOpen && (
                          <ol style={{ listStyle: "none", margin: 0, padding: 0 }}>
                            {mod.lessons.map((lesson, lIdx) => {
                              const accessible = course.isEnrolled || lesson.isFreeTrial;
                              const inner = (
                                <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 20px 11px 24px", fontSize: 13, color: accessible ? "#374151" : "#9CA3AF", background: lesson.isCompleted ? "#F0FDF4" : undefined }}>
                                  <span style={{ width: 22, height: 22, borderRadius: "50%", background: lesson.isCompleted ? "#22C55E" : accessible ? "#E0E7FF" : "#F3F4F6", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: lesson.isCompleted ? "#fff" : accessible ? "#3730A3" : "#D1D5DB", flexShrink: 0 }}>
                                    {lesson.isCompleted ? <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg> : lIdx + 1}
                                  </span>
                                  {accessible ? (
                                    <svg width="14" height="14" viewBox="0 0 20 20" fill={lesson.isCompleted ? "#22C55E" : "#3B82F6"} style={{ flexShrink: 0 }}>
                                      <path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                                    </svg>
                                  ) : (
                                    <svg width="13" height="13" viewBox="0 0 20 20" fill="#D1D5DB" style={{ flexShrink: 0 }}>
                                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                                    </svg>
                                  )}
                                  <span style={{ flex: 1 }}>{lesson.title}</span>
                                  {lesson.isFreeTrial && !course.isEnrolled && <span style={{ background: "#EFF6FF", color: "#1D4ED8", fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 999, flexShrink: 0 }}>Học thử</span>}
                                  {lesson.durationSeconds > 0 && <span style={{ fontSize: 12, color: "#9CA3AF", flexShrink: 0 }}>{formatDuration(lesson.durationSeconds)}</span>}
                                </div>
                              );
                              return (
                                <li key={lesson.id} style={{ borderBottom: "1px solid #F9FAFB" }}>
                                  {accessible ? <Link href={`/lesson/${lesson.id}`} style={{ textDecoration: "none", display: "block" }}>{inner}</Link> : inner}
                                </li>
                              );
                            })}
                            {(mod.sessions ?? []).map((session) => {
                              const accessible = course.isEnrolled || session.isFreeTrial;
                              const sessionInner = (
                                <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 20px 11px 24px", fontSize: 13, color: accessible ? "#374151" : "#9CA3AF" }}>
                                  <span style={{ width: 22, height: 22, borderRadius: "50%", background: accessible ? "#EDE9FE" : "#F3F4F6", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: accessible ? "#6D28D9" : "#D1D5DB", flexShrink: 0 }}>i</span>
                                  {accessible ? (
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" strokeWidth="2" style={{ flexShrink: 0 }}>
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                    </svg>
                                  ) : (
                                    <svg width="13" height="13" viewBox="0 0 20 20" fill="#D1D5DB" style={{ flexShrink: 0 }}>
                                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                                    </svg>
                                  )}
                                  <span style={{ flex: 1 }}>{session.title}</span>
                                  {session.isFreeTrial && !course.isEnrolled && <span style={{ background: "#EDE9FE", color: "#6D28D9", fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 999, flexShrink: 0 }}>Học thử</span>}
                                  {session.segmentCount > 0 && <span style={{ fontSize: 12, color: "#9CA3AF", flexShrink: 0 }}>{session.segmentCount} phần</span>}
                                </div>
                              );
                              return (
                                <li key={session.id} style={{ borderBottom: "1px solid #F9FAFB" }}>
                                  {accessible ? <Link href={`/session/${session.id}`} style={{ textDecoration: "none", display: "block" }}>{sessionInner}</Link> : sessionInner}
                                </li>
                              );
                            })}
                          </ol>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === "reviews" && (
            <div style={{ maxWidth: 680 }}>
              <div style={{ background: "#fff", borderRadius: 16, padding: 28, border: "1px solid #E5E7EB", display: "flex", gap: 32, flexWrap: "wrap" }}>
                <div style={{ textAlign: "center", minWidth: 100 }}>
                  <p style={{ fontSize: 56, fontWeight: 900, color: "#111827", margin: 0, lineHeight: 1 }}>4.8</p>
                  <div style={{ color: "#F59E0B", fontSize: 20, margin: "8px 0 4px", letterSpacing: 2 }}>\u2605\u2605\u2605\u2605\u2605</div>
                  <p style={{ fontSize: 12, color: "#9CA3AF", margin: 0 }}>Xếp hạng khóa học</p>
                </div>
                <div style={{ flex: 1, minWidth: 160, display: "flex", flexDirection: "column", gap: 8, justifyContent: "center" }}>
                  {[5, 4, 3, 2, 1].map((star) => (
                    <div key={star} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
                      <span style={{ color: "#6B7280", width: 8 }}>{star}</span>
                      <span style={{ color: "#F59E0B" }}>\u2605</span>
                      <div style={{ flex: 1, height: 7, borderRadius: 999, background: "#F3F4F6", overflow: "hidden" }}>
                        <div style={{ height: "100%", borderRadius: 999, background: "#F59E0B", width: star === 5 ? "78%" : star === 4 ? "15%" : "4%" }} />
                      </div>
                      <span style={{ color: "#9CA3AF", width: 32, textAlign: "right" }}>{star === 5 ? "78%" : star === 4 ? "15%" : "4%"}</span>
                    </div>
                  ))}
                </div>
              </div>
              <p style={{ marginTop: 24, textAlign: "center", fontSize: 14, color: "#9CA3AF" }}>Chưa có đánh giá nào.</p>
            </div>
          )}
        </div>
      </div>

      {!course.isEnrolled && (
        <div className="kh-card-mobile" style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 30, background: "#0D47A1", borderTop: "1px solid #1565C0", padding: "10px 16px", boxShadow: "0 -4px 20px rgba(0,0,0,0.2)" }}>
          <div style={{ maxWidth: 1180, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
            <div>
              {hasDiscount ? (
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 18, fontWeight: 800, color: "#FF6B35" }}>{formatPrice(course.discountPrice!)}</span>
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", textDecoration: "line-through" }}>{formatPrice(coursePrice)}</span>
                </div>
              ) : coursePrice === 0 ? (
                <span style={{ fontSize: 16, fontWeight: 800, color: "#4ADE80" }}>Miễn phí</span>
              ) : (
                <span style={{ fontSize: 18, fontWeight: 800, color: "#FF6B35" }}>{formatPrice(coursePrice)}</span>
              )}
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.55)", margin: 0 }}>Mở khóa {totalLessons} bài học</p>
            </div>
            <button onClick={handleEnroll} disabled={enrolling} style={{ background: "#FF6B35", color: "#fff", border: "none", borderRadius: 10, padding: "10px 24px", fontSize: 14, fontWeight: 700, cursor: enrolling ? "not-allowed" : "pointer", opacity: enrolling ? 0.7 : 1, flexShrink: 0 }}>
              {enrolling ? "Đang đăng ký..." : "Đăng ký ngay"}
            </button>
          </div>
        </div>
      )}

      <style>{`
        @media (min-width: 1024px) {
          .kh-card-desktop { display: block !important; }
          .kh-card-mobile  { display: none  !important; }
        }
        @media (max-width: 1023px) {
          .kh-card-desktop { display: none  !important; }
          .kh-card-mobile  { display: block !important; }
        }
        .kh-card-sticky { position: sticky; top: 88px; }
        .prose-kh { font-size: 14px; color: #374151; line-height: 1.8; }
        .prose-kh p { margin: 0 0 12px; }
        .prose-kh h1,.prose-kh h2,.prose-kh h3 { font-weight: 700; color: #111827; margin: 16px 0 8px; line-height: 1.4; }
        .prose-kh h2 { font-size: 17px; }
        .prose-kh h3 { font-size: 15px; }
        .prose-kh ul,.prose-kh ol { padding-left: 20px; margin: 0 0 12px; }
        .prose-kh li { margin-bottom: 4px; }
        .prose-kh strong { font-weight: 700; color: #111827; }
        .prose-kh a { color: #1565C0; }
        .prose-kh img { max-width: 100%; border-radius: 8px; margin: 8px 0; }
        .prose-kh iframe { max-width: 100%; border-radius: 8px; }
      `}</style>
    </div>
  );
}

function EnrollCard({
  course, firstLessonId, enrolling, onEnroll, hasDiscount, pct, thumbUrl,
}: {
  course: { isEnrolled: boolean; price: number | undefined; discountPrice: number | null; discountEndsAt: string | null; modules: { lessons: { id: string }[] }[] };
  firstLessonId: string;
  enrolling: boolean;
  onEnroll: () => void;
  hasDiscount: boolean;
  pct: number;
  thumbUrl: string | null;
}) {
  const cardPrice = course.price ?? 0;
  function fmtPrice(p: number | null | undefined) {
    if (p == null || p === 0) return "Miễn phí";
    return p.toLocaleString("vi-VN") + "đ";
  }
  return (
    <div style={{ borderRadius: 16, background: "#fff", boxShadow: "0 4px 24px rgba(0,0,0,0.12)", overflow: "hidden", border: "1px solid #E5E7EB" }}>
      <div style={{ padding: "20px 22px 24px" }}>
        {!course.isEnrolled && (
          <div style={{ marginBottom: 16 }}>
            {cardPrice === 0 ? (
              <div style={{ fontSize: 24, fontWeight: 800, color: "#16A34A" }}>Miễn phí</div>
            ) : hasDiscount ? (
              <div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 28, fontWeight: 900, color: "#DC2626" }}>{fmtPrice(course.discountPrice)}</span>
                  <span style={{ fontSize: 15, color: "#9CA3AF", textDecoration: "line-through" }}>{fmtPrice(cardPrice)}</span>
                  <span style={{ background: "#FF6B35", color: "#fff", fontSize: 12, fontWeight: 800, padding: "2px 9px", borderRadius: 999 }}>-{pct}%</span>
                </div>
                {course.discountEndsAt && (
                  <p style={{ fontSize: 12, color: "#EF4444", margin: "4px 0 0" }}>⏰ Giảm đến {new Date(course.discountEndsAt).toLocaleDateString("vi-VN")}</p>
                )}
              </div>
            ) : (
              <div style={{ fontSize: 28, fontWeight: 900, color: "#DC2626" }}>{fmtPrice(cardPrice)}</div>
            )}
          </div>
        )}
        {course.isEnrolled ? (
          <Link href={`/lesson/${firstLessonId}`} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, width: "100%", borderRadius: 12, padding: "13px 0", fontWeight: 700, fontSize: 15, background: "#1565C0", color: "#fff", textDecoration: "none", boxShadow: "0 4px 14px rgba(21,101,192,0.35)" }}>
            <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor"><path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" /></svg>
            Tiếp tục học
          </Link>
        ) : (
          <button onClick={onEnroll} disabled={enrolling} style={{ width: "100%", borderRadius: 12, padding: "13px 0", fontWeight: 700, fontSize: 15, background: "#FF6B35", color: "#fff", border: "none", cursor: enrolling ? "not-allowed" : "pointer", opacity: enrolling ? 0.7 : 1, boxShadow: "0 4px 14px rgba(255,107,53,0.35)" }}>
            {enrolling ? "Đang đăng ký..." : cardPrice === 0 ? "Học miễn phí ngay" : "Đăng ký ngay"}
          </button>
        )}
        {!course.isEnrolled && <p style={{ marginTop: 8, textAlign: "center", fontSize: 12, color: "#9CA3AF" }}>Học thử miễn phí một số bài</p>}
        <ul style={{ listStyle: "none", margin: "16px 0 0", padding: 0, borderTop: "1px solid #F3F4F6", paddingTop: 16, display: "flex", flexDirection: "column", gap: 10 }}>
          {[["🕐", "Học mọi lúc, mọi nơi"],["📺", "Video chất lượng HD"],["🏆", "Chứng chỉ sau hoàn thành"],["💬", "Hỗ trợ trực tiếp từ giáo viên"]].map(([icon, text]) => (
            <li key={text} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, color: "#374151" }}>
              <span style={{ fontSize: 15, width: 20, textAlign: "center" }}>{icon}</span>{text}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
