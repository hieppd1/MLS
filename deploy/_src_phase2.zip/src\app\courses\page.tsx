﻿"use client";

import { useState } from "react";
import Link from "next/link";
import { safeImgUrl } from "@/lib/utils";
import { useGetPublicCoursesQuery } from "@/lib/features/courses/coursesApi";

const LEVEL_LABELS: Record<number, string> = {
  1: "Nhập môn", 2: "Cơ bản",
  3: "Sơ trung", 4: "Trung cấp",
  5: "Trung cao", 6: "Nâng cao",
};

const LEVEL_BADGE_COLORS: Record<number, string> = {
  1: "bg-gray-400",
  2: "bg-green-500",
  3: "bg-blue-500",
  4: "bg-purple-500",
  5: "bg-orange-500",
  6: "bg-red-600",
};

type SortOption = "newest" | "popular" | "price_asc" | "price_desc";

const SORT_LABELS: Record<SortOption, string> = {
  newest: "Mới nhất",
  popular: "Phổ biến nhất",
  price_asc: "Giá tăng dần",
  price_desc: "Giá giảm dần",
};

export default function CourseCatalogPage() {
  const [level, setLevel] = useState<number | undefined>();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sort, setSort] = useState<SortOption>("newest");
  const [sortOpen, setSortOpen] = useState(false);
  const [page, setPage] = useState(1);
  const pageSize = 9;

  const { data, isLoading } = useGetPublicCoursesQuery({
    page, pageSize, level, search: debouncedSearch || undefined,
  });

  function handleSearch(value: string) {
    setSearch(value);
    clearTimeout((window as Window & { __st?: ReturnType<typeof setTimeout> }).__st);
    (window as Window & { __st?: ReturnType<typeof setTimeout> }).__st = setTimeout(() => {
      setDebouncedSearch(value); setPage(1);
    }, 400);
  }

  const totalPages = data ? Math.ceil(data.total / pageSize) : 1;

  return (
    <div className="min-h-screen bg-gray-100">

      {/* ── Hero ─────────────────────────────────────────────── */}
      <div
        className="py-14 px-4 text-white"
        style={{ background: "linear-gradient(135deg, #1565C0 0%, #0D47A1 100%)" }}
      >
        <div className="mx-auto max-w-6xl">
          {/* Breadcrumb */}
          <nav className="mb-4 text-sm text-white/60">
            <Link href="/" className="hover:text-white transition">Trang chủ</Link>
            <span className="mx-2">/</span>
            <span className="text-white">Khoá học</span>
          </nav>
          <h1 className="text-3xl font-bold sm:text-4xl">Khoá học tiếng Việt</h1>
          <p className="mt-2 text-blue-200">
            Hệ thống giáo trình 6 cấp độ — từ nhập môn đến nâng cao, phù hợp mọi trình độ.
          </p>

          {/* Search */}
          <div className="mt-6 max-w-lg">
            <div className="relative">
              <svg className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Tìm kiếm khoá học..."
                value={search}
                onChange={(e) => handleSearch(e.target.value)}
                className="w-full rounded-full bg-white/15 pl-9 pr-4 py-2.5 text-sm text-white placeholder-white/50 backdrop-blur focus:outline-none focus:ring-2 focus:ring-white/40"
              />
            </div>
          </div>
        </div>
      </div>

      {/* ── Filter bar (sticky) ──────────────────────────────── */}
      <div className="sticky top-14 z-20 border-b border-gray-200 bg-white shadow-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 overflow-x-auto px-4 py-3">
          {/* Level pills */}
          <div className="flex shrink-0 gap-2">
            <button
              onClick={() => { setLevel(undefined); setPage(1); }}
              className={`whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition ${level === undefined ? "text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
              style={level === undefined ? { backgroundColor: "#1565C0" } : {}}
            >
              Tất cả
            </button>
            {[1, 2, 3, 4, 5, 6].map((l) => (
              <button
                key={l}
                onClick={() => { setLevel(l); setPage(1); }}
                className={`whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition ${level === l ? "text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
                style={level === l ? { backgroundColor: "#1565C0" } : {}}
              >
                Level {l}
              </button>
            ))}
          </div>

          {/* Sort dropdown */}
          <div className="relative shrink-0">
            <button
              onClick={() => setSortOpen((o) => !o)}
              className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50"
            >
              {SORT_LABELS[sort]}
              <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {sortOpen && (
              <div className="absolute right-0 top-full mt-1 w-44 overflow-hidden rounded-xl bg-white shadow-lg ring-1 ring-gray-200 z-30">
                {(Object.keys(SORT_LABELS) as SortOption[]).map((key) => (
                  <button
                    key={key}
                    onClick={() => { setSort(key); setSortOpen(false); }}
                    className={`flex w-full items-center justify-between px-4 py-2.5 text-sm transition hover:bg-gray-50 ${sort === key ? "font-semibold text-blue-700" : "text-gray-700"}`}
                  >
                    {SORT_LABELS[key]}
                    {sort === key && (
                      <svg className="h-4 w-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Grid ────────────────────────────────────────────── */}
      <div className="mx-auto max-w-6xl px-4 py-8">
        {data && !isLoading && (
          <p className="mb-5 text-sm text-gray-500">
            {data.total === 0 ? "Không tìm thấy kết quả" : `${data.total} khoá học`}
          </p>
        )}

        {isLoading ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="overflow-hidden rounded-xl bg-white shadow-sm">
                <div className="animate-pulse bg-gray-200" style={{ aspectRatio: "16/9" }} />
                <div className="space-y-2 p-4">
                  <div className="h-4 w-3/4 animate-pulse rounded bg-gray-200" />
                  <div className="h-3 w-full animate-pulse rounded bg-gray-100" />
                </div>
              </div>
            ))}
          </div>
        ) : !data?.items.length ? (
          <div className="py-24 text-center">
            <div className="mb-4 text-5xl">🔍</div>
            <p className="text-gray-400">Không tìm thấy khoá học nào.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {data.items.map((course) => {
              const badgeColor = LEVEL_BADGE_COLORS[course.level] ?? "bg-gray-400";
              const levelLabel = LEVEL_LABELS[course.level] ?? `Level ${course.level}`;
              return (
                <Link
                  key={course.id}
                  href={`/courses/${course.id}`}
                  className="group flex flex-col overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100 transition-all duration-150 hover:-translate-y-1 hover:shadow-md"
                >
                  {/* Thumbnail */}
                  <div className="relative overflow-hidden bg-gray-100" style={{ aspectRatio: "16/9" }}>
                    {safeImgUrl(course.thumbnailUrl) ? (
                      <img
                        src={safeImgUrl(course.thumbnailUrl)!}
                        alt={course.title}
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-blue-50 to-blue-100">
                        <span className="text-4xl font-black text-blue-200 select-none">L{course.level}</span>
                      </div>
                    )}
                    <span className={`absolute left-3 top-3 rounded-full px-2.5 py-0.5 text-xs font-semibold text-white ${badgeColor}`}>
                      {levelLabel}
                    </span>
                    {course.isEnrolled && (
                      <span className="absolute right-3 top-3 rounded-full bg-green-500 px-2.5 py-0.5 text-xs font-semibold text-white">
                        Đã đăng ký
                      </span>
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex flex-1 flex-col p-4">
                    <h2 className="mb-1 font-semibold text-gray-900 line-clamp-2 transition group-hover:text-blue-700">
                      {course.title}
                    </h2>
                    {course.description && (
                      <p className="mb-3 text-xs text-gray-500 line-clamp-2 leading-relaxed">
                        {course.description}
                      </p>
                    )}
                    <div className="mt-auto flex items-center gap-4 border-t border-gray-100 pt-3 text-xs text-gray-400">
                      <span className="flex items-center gap-1">
                        <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                        {course.moduleCount} chương
                      </span>
                      <span className="flex items-center gap-1">
                        <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                        {course.lessonCount} bài học
                      </span>
                      {course.isEnrolled && (
                        <span className="ml-auto flex items-center gap-1 font-medium text-blue-600">
                          Tiếp tục học →
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="mt-10 flex items-center justify-center gap-3">
            <button
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
              className="rounded-lg border border-gray-200 bg-white px-5 py-2 text-sm font-medium text-gray-700 shadow-sm transition hover:bg-gray-50 disabled:opacity-40"
            >
              ← Trước
            </button>
            <span className="text-sm text-gray-500">{page} / {totalPages}</span>
            <button
              disabled={page >= totalPages}
              onClick={() => setPage((p) => p + 1)}
              className="rounded-lg border border-gray-200 bg-white px-5 py-2 text-sm font-medium text-gray-700 shadow-sm transition hover:bg-gray-50 disabled:opacity-40"
            >
              Tiếp →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
