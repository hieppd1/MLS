import { fetchBaseQuery, type BaseQueryFn, type FetchArgs, type FetchBaseQueryError } from "@reduxjs/toolkit/query/react";
import Cookies from "js-cookie";
import type { RootState } from "./store";
import { setCredentials, clearCredentials } from "./features/auth/authSlice";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5009";

export const rawBaseQuery = (baseUrl: string) =>
  fetchBaseQuery({
    baseUrl,
    prepareHeaders(headers, { getState }) {
      const state = getState() as RootState;
      const token = state.auth.accessToken;
      const tenant = state.auth.tenantSlug;
      if (token) headers.set("Authorization", `Bearer ${token}`);
      if (tenant) headers.set("X-Tenant-Slug", tenant);
      return headers;
    },
  });

/**
 * Wraps any baseQuery with automatic JWT refresh on 401.
 * On 401: calls POST /api/v1/auth/refresh with the refreshToken cookie.
 * On success: stores new tokens and retries the original request.
 * On failure: clears credentials and redirects to /login.
 */
export function withReauth(baseUrl: string): BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError> {
  const base = rawBaseQuery(baseUrl);

  return async (args, api, extraOptions) => {
    let result = await base(args, api, extraOptions);

    if (result.error?.status === 401) {
      const refreshToken = Cookies.get("refreshToken");
      if (refreshToken) {
        const state = api.getState() as RootState;
        const tenant = state.auth.tenantSlug;

        const refreshResult = await fetch(`${API_BASE}/api/v1/auth/refresh`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Tenant-Slug": tenant,
          },
          body: JSON.stringify({ refreshToken }),
        });

        if (refreshResult.ok) {
          const data = await refreshResult.json();
          Cookies.set("refreshToken", data.refreshToken, { expires: 30, sameSite: "strict" });
          api.dispatch(setCredentials({ accessToken: data.accessToken, user: data.user }));
          // Retry original request with new token
          result = await base(args, api, extraOptions);
        } else {
          // Refresh failed — clear session
          Cookies.remove("refreshToken");
          api.dispatch(clearCredentials());
          if (typeof window !== "undefined") {
            window.location.href = "/login";
          }
        }
      } else {
        api.dispatch(clearCredentials());
        if (typeof window !== "undefined") {
          window.location.href = "/login";
        }
      }
    }

    return result;
  };
}
