"use client";

export default function AdminSettingsPage() {
  return (
    <div className="max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Cài đặt Tenant</h1>
        <p className="mt-1 text-sm text-gray-500">Quản lý cấu hình cho tenant này.</p>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white p-6 space-y-6">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-gray-700">Tên tổ chức</label>
          <input
            type="text"
            placeholder="Tên tổ chức của bạn"
            className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-gray-700">Email liên hệ</label>
          <input
            type="email"
            placeholder="admin@example.com"
            className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-gray-700">Domain tùy chỉnh</label>
          <input
            type="text"
            placeholder="learn.yourcompany.com"
            className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
          />
          <p className="mt-1 text-xs text-gray-400">Chức năng này sẽ khả dụng trong phiên bản tiếp theo.</p>
        </div>

        <div className="pt-2">
          <button
            disabled
            className="rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white opacity-40 cursor-not-allowed"
          >
            Lưu cài đặt (Coming soon)
          </button>
        </div>
      </div>
    </div>
  );
}
