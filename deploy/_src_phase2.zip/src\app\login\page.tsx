"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Suspense } from "react";
import Cookies from "js-cookie";
import { useLoginMutation } from "@/lib/features/auth/authApi";
import { setCredentials } from "@/lib/features/auth/authSlice";
import { useAppDispatch } from "@/lib/hooks";
import GoogleLoginButton from "@/components/auth/GoogleLoginButton";

const schema = z.object({
  email: z.string().email("Email không hợp lệ"),
  password: z.string().min(1, "Mật khẩu không được để trống"),
});
type FormData = z.infer<typeof schema>;

const FEATURES = [
  "Lộ trình 6 cấp độ chuẩn CEFR",
  "AI chấm điểm Speaking & Writing",
  "Học mọi lúc, mọi nơi",
  "Chứng chỉ sau hoàn thành khoá học",
];

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const dispatch = useAppDispatch();
  const [login, { isLoading }] = useLoginMutation();

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  async function onSubmit(data: FormData) {
    try {
      const result = await login(data).unwrap();
      Cookies.set("refreshToken", result.refreshToken, { expires: 30, sameSite: "strict" });
      dispatch(setCredentials({ accessToken: result.accessToken, user: result.user }));
      const next = searchParams.get("next");
      if (next) {
        router.push(next);
      } else {
        const role = result.user?.role ?? "";
        const isUserFacing = role === "Student" || role === "Teacher";
        router.push(isUserFacing ? "/" : "/admin");
      }
    } catch (err: unknown) {
      const apiError = err as { data?: { error?: string }; status?: number };
      const message =
        apiError?.data?.error ??
        (apiError?.status === 401 ? "Email hoặc mật khẩu không đúng" : "Đã xảy ra lỗi. Vui lòng thử lại.");
      setError("root", { message });
    }
  }

  const resetSuccess = searchParams.get("reset") === "1";

  return (
    <div className="w-full max-w-md fade-up">
      {/* Mobile logo */}
      <div className="mb-8 lg:hidden text-center">
        <span className="text-3xl font-bold" style={{ color: "var(--brand-blue)" }}>MLS</span>
        <p className="mt-1 text-sm text-gray-500">Nền tảng học tiếng Việt</p>
      </div>

      <h1 className="mb-1 text-2xl font-bold text-gray-900">Đăng nhập</h1>
      <p className="mb-6 text-sm text-gray-500">
        Chưa có tài khoản?{" "}
        <Link href="/register" className="font-medium hover:underline" style={{ color: "var(--brand-blue)" }}>
          Đăng ký miễn phí
        </Link>
      </p>

      {resetSuccess && (
        <div className="mb-4 rounded-lg bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
          Đặt lại mật khẩu thành công! Hãy đăng nhập với mật khẩu mới.
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-gray-700">Email</label>
          <input
            {...register("email")}
            type="email"
            autoComplete="email"
            placeholder="you@example.com"
            className="w-full rounded-lg border border-gray-300 px-3.5 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
          />
          {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>}
        </div>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">Mật khẩu</label>
            <Link href="/forgot-password" className="text-xs font-medium" style={{ color: "var(--brand-blue)" }}>
              Quên mật khẩu?
            </Link>
          </div>
          <input
            {...register("password")}
            type="password"
            autoComplete="current-password"
            placeholder="••••••••"
            className="w-full rounded-lg border border-gray-300 px-3.5 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
          />
          {errors.password && <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>}
        </div>

        {errors.root && (
          <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            {errors.root.message}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full rounded-lg py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-60"
          style={{ background: "var(--brand-blue)" }}
        >
          {isLoading ? "Đang đăng nhập..." : "Đăng nhập"}
        </button>
      </form>

      <div className="relative my-5">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-200" />
        </div>
        <div className="relative flex justify-center text-xs text-gray-400">
          <span className="bg-white px-2">hoặc tiếp tục bằng</span>
        </div>
      </div>

      <div className="flex justify-center">
        <GoogleLoginButton onError={(msg) => setError("root", { message: msg })} />
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <div className="flex min-h-[calc(100vh-3.5rem)]">
      {/* Left panel — brand hero */}
      <div
        className="hidden lg:flex lg:w-2/5 xl:w-1/2 flex-col items-center justify-center p-12 text-white"
        style={{ background: "linear-gradient(135deg, var(--brand-blue-dark) 0%, var(--brand-blue) 60%, var(--brand-blue-light) 100%)" }}
      >
        <div className="max-w-sm w-full">
          <div className="mb-8">
            <span className="text-4xl font-bold">MLS</span>
            <p className="mt-2 text-lg text-blue-100">Học tiếng Việt cùng chuyên gia</p>
          </div>
          <ul className="space-y-3">
            {FEATURES.map((f) => (
              <li key={f} className="flex items-center gap-3 text-sm text-blue-50">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/20 text-xs">✓</span>
                {f}
              </li>
            ))}
          </ul>
          <div className="mt-10 rounded-xl bg-white/10 p-4 text-sm text-blue-100">
            "Nền tảng giúp tôi học tiếng Việt hiệu quả hơn bất kỳ app nào tôi từng dùng!"
            <div className="mt-2 font-semibold text-white">— Nguyễn Minh, học viên Level 4</div>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex flex-1 items-center justify-center bg-white px-6 py-12">
        <Suspense>
          <LoginForm />
        </Suspense>
      </div>
    </div>
  );
}

