"use client";

import { useState } from "react";
import Link from "next/link";
import { useSelector } from "react-redux";
import type { RootState } from "@/lib/store";

/* ─────────────────────────────────────────────────────────────
   CONSTANTS shared with homepage
───────────────────────────────────────────────────────────── */
const LEFT_NAV = [
  {
    id: "new", label: "Bài học mới", href: "/", requireAuth: false,
    icon: (
      <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
      </svg>
    ),
  },
  {
    id: "enrolled", label: "Khoá đã kích hoạt", href: "/my-courses", requireAuth: true,
    icon: (
      <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
      </svg>
    ),
  },
  {
    id: "group", label: "Nhóm của tôi", href: "/groups", requireAuth: true,
    icon: (
      <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
  {
    id: "following", label: "Đang theo dõi", href: "/following", requireAuth: true,
    icon: (
      <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
      </svg>
    ),
  },
  {
    id: "saved", label: "Đã lưu", href: "/saved", requireAuth: true,
    icon: (
      <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
      </svg>
    ),
  },
  {
    id: "liked", label: "Đã thích", href: "/liked", requireAuth: true,
    icon: (
      <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
      </svg>
    ),
  },
];

const MOCK_CHATS = [
  { id: "c1", name: "Thầy Lê Văn Tuấn",       init: "LT", color: "#1565C0",  lastMsg: "Bạn: Đã tạo hội thoại!",                      time: "2 ph",   unread: 0, online: true,  type: "message" as const },
  { id: "c2", name: "Nhóm Tiếng Anh Cấp 2",   init: "TA", color: "#16A34A",  lastMsg: "Cô Trang Anh: Bài tập hôm nay về nhà là...",  time: "15 ph",  unread: 3, online: false, type: "group"   as const },
  { id: "c3", name: "Thầy Chu Đình Mong",      init: "CM", color: "#DC2626",  lastMsg: "Hẹn gặp lại buổi học tới nhé",                time: "1 giờ",  unread: 0, online: true,  type: "message" as const },
  { id: "c4", name: "Hỏi & Đáp: Ngữ pháp",    init: "HĐ", color: "#7C3AED",  lastMsg: "Bạn hỏi: Cách dùng had been?",               time: "2 giờ",  unread: 1, online: false, type: "qa"      as const },
  { id: "c5", name: "Thầy Phan Khắc Nghệ",    init: "PN", color: "#0891B2",  lastMsg: "Xem lại bài giảng số 5 nhé em",              time: "3 giờ",  unread: 0, online: false, type: "message" as const },
  { id: "c6", name: "Nhóm Học Cấp 3 THPT",    init: "N3", color: "#EA580C",  lastMsg: "Có 2 thành viên mới tham gia",               time: "5 giờ",  unread: 2, online: false, type: "group"   as const },
  { id: "c7", name: "Thông báo khoá học",      init: "TB", color: "#CA8A04",  lastMsg: "Khoá học nâng cao khai giảng 01/06",         time: "1 ngày", unread: 1, online: false, type: "notify"  as const },
  { id: "c8", name: "Nhóm Luyện Nói Online",   init: "LN", color: "#0D9488",  lastMsg: "Buổi tới: Thứ 3, 20:00",                    time: "2 ngày", unread: 0, online: false, type: "group"   as const },
];

const CHAT_TYPE_ICON: Record<string, string> = { group: "👥", qa: "❓", notify: "🔔", message: "" };

/* ─────────────────────────────────────────────────────────────
   PROPS
───────────────────────────────────────────────────────────── */
interface AppShellProps {
  /** The content that fills col 3 + (optionally) col 4 merged */
  children: React.ReactNode;
  /** Highlight this nav item */
  activeNavId?: string;
}

/* ─────────────────────────────────────────────────────────────
   APP SHELL  (Col 1 + Col 2 + children)
───────────────────────────────────────────────────────────── */
export default function AppShell({ children, activeNavId }: AppShellProps) {
  const isLoggedIn = useSelector((s: RootState) => !!s.auth?.accessToken);
  const [activeNav,      setActiveNav]      = useState(activeNavId ?? "new");
  const [chatSearch,     setChatSearch]     = useState("");
  const [chatTab,        setChatTab]        = useState<"all" | "unread">("all");
  const [showChatFilter, setShowChatFilter] = useState(false);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);

  const filteredChats = MOCK_CHATS.filter((c) => {
    if (chatSearch && !c.name.toLowerCase().includes(chatSearch.toLowerCase()) &&
        !c.lastMsg.toLowerCase().includes(chatSearch.toLowerCase())) return false;
    if (chatTab === "unread" && c.unread === 0) return false;
    return true;
  });

  return (
    <>
      <style>{`
        .mls-shell-scroll { scrollbar-width: thin; scrollbar-color: transparent transparent; }
        .mls-shell-scroll::-webkit-scrollbar { width: 4px; }
        .mls-shell-scroll::-webkit-scrollbar-track { background: transparent; }
        .mls-shell-scroll::-webkit-scrollbar-thumb { background: transparent; border-radius: 99px; }
        .mls-shell-scroll:hover::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.18); }
        .mls-shell-scroll:hover { scrollbar-color: rgba(0,0,0,0.18) transparent; }
        .mls-mobile-nav { display: none; position: fixed; bottom: 0; left: 0; right: 0;
          height: 56px; background: #fff; border-top: 1px solid #e5e7eb;
          z-index: 200; align-items: center; justify-content: space-around; padding: 0 4px; }
        @media (max-width: 767px) {
          .mls-col1 { display: none !important; }
          .mls-col2 { display: none !important; }
          .mls-mobile-nav { display: flex !important; }
          .mls-shell-body { height: calc(100vh - 56px - 56px) !important; }
        }
      `}</style>

      <div className="mls-shell-body" style={{ display: "flex", height: "calc(100vh - 56px)", overflow: "hidden" }}>

        {/* ══ COL 1: Left nav (72px) ══════════════════════════════ */}
        <aside className="mls-shell-scroll mls-col1" style={{
          width: 72, flexShrink: 0,
          background: "white", borderRight: "1px solid #e5e7eb",
          display: "flex", flexDirection: "column", alignItems: "center",
          paddingTop: 8, overflowY: "auto", zIndex: 10,
        }}>
          {LEFT_NAV.map((item) => {
            const locked = item.requireAuth && !isLoggedIn;
            const active = activeNav === item.id;
            return (
              <Link
                key={item.id}
                href={locked ? "/login" : item.href}
                onClick={() => !locked && setActiveNav(item.id)}
                style={{
                  display: "flex", flexDirection: "column", alignItems: "center",
                  gap: 4, padding: "10px 4px", width: "100%", textAlign: "center",
                  textDecoration: "none",
                  color: active ? "#1565C0" : locked ? "#D1D5DB" : "#6B7280",
                  background: active ? "#EFF6FF" : "transparent",
                  borderTop: "none", borderRight: "none", borderBottom: "none",
                  borderLeft: active ? "3px solid #1565C0" : "3px solid transparent",
                }}
                title={item.label}
              >
                {item.icon}
                <span style={{ fontSize: 9, fontWeight: 500, lineHeight: 1.2 }}>{item.label}</span>
              </Link>
            );
          })}
        </aside>

        {/* ══ COL 2: Messages / Chat (290px) ══════════════════════ */}
        <div className="mls-col2" style={{
          width: 290, flexShrink: 0,
          background: "white", borderRight: "1px solid #e5e7eb",
          display: "flex", flexDirection: "column", zIndex: 10, position: "relative",
        }}>
          {/* Header */}
          <div style={{ padding: "14px 14px 0", borderBottom: "1px solid #f3f4f6", flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: 0 }}>Tin nhắn</h2>
              <button style={{
                width: 28, height: 28, borderRadius: "50%", border: "1px solid #E5E7EB",
                background: "#F9FAFB", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#6B7280" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                </svg>
              </button>
            </div>
            {/* Search */}
            <div style={{ position: "relative", marginBottom: 10 }}>
              <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#9CA3AF"
                style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0" />
              </svg>
              <input
                type="text" placeholder="Tìm tin nhắn..." value={chatSearch}
                onChange={(e) => setChatSearch(e.target.value)}
                style={{
                  width: "100%", paddingLeft: 32, paddingRight: 10, paddingTop: 8, paddingBottom: 8,
                  border: "1px solid #E5E7EB", borderRadius: 20, fontSize: 12,
                  outline: "none", boxSizing: "border-box", background: "#F9FAFB",
                }}
              />
            </div>
            {/* Tabs */}
            <div style={{ display: "flex", alignItems: "center" }}>
              {(["all", "unread"] as const).map((tab) => (
                <button key={tab} onClick={() => setChatTab(tab)} style={{
                  padding: "7px 14px", fontSize: 12, fontWeight: 500,
                  borderTop: "none", borderLeft: "none", borderRight: "none",
                  borderBottom: chatTab === tab ? "2px solid #1565C0" : "2px solid transparent",
                  cursor: "pointer", background: "transparent",
                  color: chatTab === tab ? "#1565C0" : "#6B7280",
                }}>
                  {tab === "all" ? "Tất cả" : "Chưa đọc"}
                </button>
              ))}
              <div style={{ position: "relative", marginLeft: "auto" }}>
                <button
                  onClick={() => setShowChatFilter((v) => !v)}
                  style={{
                    padding: "7px 10px", fontSize: 12, fontWeight: 500,
                    borderTop: "none", borderLeft: "none", borderRight: "none",
                    borderBottom: showChatFilter ? "2px solid #1565C0" : "2px solid transparent",
                    cursor: "pointer", background: "transparent",
                    color: showChatFilter ? "#1565C0" : "#6B7280",
                  }}
                >
                  Phân loại ▾
                </button>
                {showChatFilter && (
                  <div style={{
                    position: "absolute", top: "calc(100% + 6px)", right: 0,
                    background: "#fff", border: "1px solid #E5E7EB",
                    borderRadius: 10, boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
                    zIndex: 50, width: 210, padding: "10px 0",
                  }}>
                    <p style={{ fontSize: 11, fontWeight: 700, color: "#9CA3AF", padding: "2px 14px 8px", textTransform: "uppercase", letterSpacing: "0.05em", margin: 0 }}>Phân loại</p>
                    {["Tất cả", "Tin nhắn riêng", "Nhóm học", "Hỏi & Đáp", "Thông báo khoá học"].map((opt, i) => (
                      <button key={opt} style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 14px", width: "100%", textAlign: "left", background: "none", border: "none", cursor: "pointer", fontSize: 13, color: "#374151" }}>
                        <div style={{ width: 14, height: 14, borderRadius: "50%", border: i === 0 ? "4px solid #1565C0" : "2px solid #D1D5DB", flexShrink: 0 }} />
                        {opt}
                      </button>
                    ))}
                    <div style={{ borderTop: "1px solid #F3F4F6", margin: "8px 0 4px" }} />
                    <p style={{ fontSize: 11, fontWeight: 700, color: "#9CA3AF", padding: "2px 14px 8px", textTransform: "uppercase", letterSpacing: "0.05em", margin: 0 }}>Môn học</p>
                    {["Tất cả", "Tiếng Việt", "Tiếng Anh", "Toán học", "Kỹ năng mềm"].map((opt, i) => (
                      <button key={opt} style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 14px", width: "100%", textAlign: "left", background: "none", border: "none", cursor: "pointer", fontSize: 13, color: "#374151" }}>
                        <div style={{ width: 14, height: 14, borderRadius: "50%", border: i === 0 ? "4px solid #1565C0" : "2px solid #D1D5DB", flexShrink: 0 }} />
                        {opt}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {showChatFilter && (
            <div style={{ position: "fixed", inset: 0, zIndex: 40 }} onClick={() => setShowChatFilter(false)} />
          )}

          {MOCK_CHATS.filter(c => c.unread > 0).length > 0 && chatTab === "all" && (
            <div style={{ margin: "8px 14px 0", padding: "6px 12px", borderRadius: 8, background: "#EFF6FF", border: "1px solid #DBEAFE", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: 12, color: "#1565C0", fontWeight: 500 }}>
                {MOCK_CHATS.filter(c => c.unread > 0).reduce((a, c) => a + c.unread, 0)} tin chưa đọc
              </span>
              <button onClick={() => setChatTab("unread")} style={{ fontSize: 11, color: "#1565C0", fontWeight: 600, background: "none", border: "none", cursor: "pointer", padding: 0 }}>Xem tất cả</button>
            </div>
          )}

          {/* Chat list */}
          <div className="mls-shell-scroll" style={{ flex: 1, overflowY: "auto", paddingTop: 4 }}>
            {filteredChats.length === 0 ? (
              <div style={{ padding: "48px 14px", textAlign: "center" }}>
                <div style={{ fontSize: 36, marginBottom: 10 }}>💬</div>
                <p style={{ fontSize: 13, color: "#9CA3AF" }}>Không có tin nhắn nào</p>
              </div>
            ) : filteredChats.map((chat) => (
              <button
                key={chat.id}
                onClick={() => setSelectedChatId(chat.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "11px 14px", width: "100%", textAlign: "left",
                  background: selectedChatId === chat.id ? "#EFF6FF" : "transparent",
                  borderTop: "none", borderRight: "none",
                  borderBottom: "1px solid #f3f4f6",
                  borderLeft: selectedChatId === chat.id ? "3px solid #1565C0" : "3px solid transparent",
                  cursor: "pointer",
                }}
              >
                <div style={{ position: "relative", flexShrink: 0 }}>
                  <div style={{ width: 44, height: 44, borderRadius: "50%", background: chat.color, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 13 }}>
                    {chat.init}
                  </div>
                  {chat.online && <div style={{ position: "absolute", bottom: 1, right: 1, width: 11, height: 11, borderRadius: "50%", background: "#22C55E", border: "2px solid #fff" }} />}
                  {CHAT_TYPE_ICON[chat.type] && <div style={{ position: "absolute", bottom: -2, right: -2, width: 17, height: 17, borderRadius: "50%", background: "#fff", border: "1px solid #E5E7EB", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9 }}>{CHAT_TYPE_ICON[chat.type]}</div>}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 3 }}>
                    <span style={{ fontSize: 13, fontWeight: chat.unread > 0 ? 700 : 600, color: "#111827", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 140 }}>{chat.name}</span>
                    <span style={{ fontSize: 10, color: "#9CA3AF", flexShrink: 0, marginLeft: 6 }}>{chat.time}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 12, color: chat.unread > 0 ? "#374151" : "#9CA3AF", fontWeight: chat.unread > 0 ? 500 : 400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 172 }}>{chat.lastMsg}</span>
                    {chat.unread > 0 && <div style={{ background: "#1565C0", color: "#fff", fontSize: 10, fontWeight: 700, minWidth: 18, height: 18, borderRadius: 99, display: "flex", alignItems: "center", justifyContent: "center", paddingLeft: 4, paddingRight: 4, flexShrink: 0, marginLeft: 4 }}>{chat.unread}</div>}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* ══ MAIN CONTENT (col 3+4, or just col 3) — provided by caller ══ */}
        {children}

      </div>

      {/* ══ MOBILE BOTTOM NAV (hidden on desktop) ══════════════ */}
      <nav className="mls-mobile-nav">
        {[
          { href: "/",              icon: "📚", label: "Học" },
          { href: "/khoa-hoc",      icon: "🎓", label: "Khoá học" },
          { href: "/placement-test",icon: "✏️", label: "Thi thử" },
          { href: "/giao-vien",     icon: "👨‍🏫", label: "Giáo viên" },
          { href: "/profile",       icon: "👤", label: "Tôi" },
        ].map(({ href, icon, label }) => (
          <a key={href} href={href} style={{
            display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
            textDecoration: "none", flex: 1, padding: "6px 0",
            color: activeNav === href.slice(1) || (href === "/" && activeNav === "new") ? "#1565C0" : "#6B7280",
          }}>
            <span style={{ fontSize: 20, lineHeight: 1 }}>{icon}</span>
            <span style={{ fontSize: 10, fontWeight: 500 }}>{label}</span>
          </a>
        ))}
      </nav>
    </>
  );
}
