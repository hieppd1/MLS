"use client";

import Link from "next/link";
import AppShell from "@/app/_components/AppShell";

export default function PlacementTestPage() {
  return (
    <AppShell>
      <main style={{
        flex: 1, minWidth: 0, overflowY: "auto",
        background: "#F8FAFC",
        display: "flex", alignItems: "center", justifyContent: "center",
        padding: "40px 20px",
      }}>
        <div style={{
          maxWidth: 520, width: "100%", textAlign: "center",
          background: "#fff", borderRadius: 16,
          padding: "48px 40px",
          boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
          border: "1px solid #e5e7eb",
        }}>
          {/* Icon */}
          <div style={{
            width: 80, height: 80, borderRadius: "50%",
            background: "linear-gradient(135deg,#1565C0 0%,#0D47A1 100%)",
            display: "flex", alignItems: "center", justifyContent: "center",
            margin: "0 auto 24px",
            boxShadow: "0 8px 24px rgba(21,101,192,0.3)",
          }}>
            <svg width="40" height="40" fill="none" viewBox="0 0 24 24" stroke="white" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round"
                d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75a2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
            </svg>
          </div>

          <h1 style={{ fontSize: 24, fontWeight: 700, color: "#111827", marginBottom: 12 }}>
            Bài Kiểm Tra Đầu Vào
          </h1>

          <p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.6, marginBottom: 8 }}>
            Kiểm tra trình độ để chúng tôi gợi ý khoá học phù hợp với bạn.
          </p>

          <div style={{
            display: "inline-block",
            background: "#FEF3C7", color: "#92400E",
            borderRadius: 99, padding: "4px 14px",
            fontSize: 12, fontWeight: 600, marginBottom: 32,
          }}>
            Sắp ra mắt
          </div>

          {/* Features */}
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12,
            marginBottom: 36, textAlign: "left",
          }}>
            {[
              { icon: "⏱", title: "20 phút", desc: "Thời gian làm bài" },
              { icon: "📊", title: "40 câu", desc: "Trắc nghiệm & tự luận" },
              { icon: "🎯", title: "6 cấp độ", desc: "Từ Sơ cấp đến Nâng cao" },
              { icon: "📚", title: "Gợi ý khoá", desc: "Phù hợp trình độ bạn" },
            ].map(({ icon, title, desc }) => (
              <div key={title} style={{
                background: "#F9FAFB", borderRadius: 10, padding: "12px 14px",
                border: "1px solid #F3F4F6",
              }}>
                <div style={{ fontSize: 22, marginBottom: 6 }}>{icon}</div>
                <p style={{ fontSize: 13, fontWeight: 700, color: "#111827", margin: "0 0 2px" }}>{title}</p>
                <p style={{ fontSize: 12, color: "#9CA3AF", margin: 0 }}>{desc}</p>
              </div>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <button style={{
              width: "100%", padding: "13px 0",
              background: "#E5E7EB", color: "#9CA3AF",
              border: "none", borderRadius: 10, fontSize: 15, fontWeight: 600,
              cursor: "not-allowed",
            }} disabled>
              Làm bài kiểm tra — Sắp có
            </button>
            <Link href="/khoa-hoc" style={{
              display: "block", width: "100%", padding: "13px 0",
              background: "#1565C0", color: "white",
              border: "none", borderRadius: 10, fontSize: 15, fontWeight: 600,
              textDecoration: "none", textAlign: "center",
              boxSizing: "border-box",
            }}>
              Khám phá khoá học ngay
            </Link>
          </div>
        </div>
      </main>
    </AppShell>
  );
}
