import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./features/auth/authSlice";
import { authApi } from "./features/auth/authApi";
import { usersApi } from "./features/users/usersApi";
import { adminApi } from "./features/admin/adminApi";
import { cmsApi } from "./features/cms/cmsApi";
import { coursesApi } from "./features/courses/coursesApi";
import { teachersApi } from "./features/teachers/teachersApi";
import { learningApi } from "./features/learning/learningApi";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    [authApi.reducerPath]: authApi.reducer,
    [usersApi.reducerPath]: usersApi.reducer,
    [adminApi.reducerPath]: adminApi.reducer,
    [cmsApi.reducerPath]: cmsApi.reducer,
    [coursesApi.reducerPath]: coursesApi.reducer,
    [teachersApi.reducerPath]: teachersApi.reducer,
    [learningApi.reducerPath]: learningApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(authApi.middleware)
      .concat(usersApi.middleware)
      .concat(adminApi.middleware)
      .concat(cmsApi.middleware)
      .concat(coursesApi.middleware)
      .concat(teachersApi.middleware)
      .concat(learningApi.middleware),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
