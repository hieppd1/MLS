"use client";

import { useState } from "react";
import { ActionButtons } from "@/app/admin/_components/ActionButtons";
import {
  useGetLearningLevelsQuery,
  useCreateLearningLevelMutation,
  useUpdateLearningLevelMutation,
  useSetLearningLevelActiveMutation,
  useDeleteLearningLevelMutation,
  type LearningLevel,
} from "@/lib/features/cms/cmsApi";

const inputCls = "w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";
const labelCls = "mb-1 block text-sm font-semibold text-gray-700";

export default function LearningLevelsPage() {
  const { data: levels = [], isLoading } = useGetLearningLevelsQuery({ includeInactive: true });
  const [createLevel, { isLoading: creating }] = useCreateLearningLevelMutation();
  const [updateLevel, { isLoading: updating }] = useUpdateLearningLevelMutation();
  const [setActive] = useSetLearningLevelActiveMutation();
  const [deleteLevel] = useDeleteLearningLevelMutation();

  const [showAdd, setShowAdd] = useState(false);
  const [addForm, setAddForm] = useState({ name: "", description: "", orderIndex: 0 });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ name: "", description: "", orderIndex: 0 });
  const [msg, setMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const showMsg = (type: "success" | "error", text: string) => {
    setMsg({ type, text });
    setTimeout(() => setMsg(null), 3500);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createLevel({
        name: addForm.name,
        description: addForm.description || undefined,
        orderIndex: addForm.orderIndex,
      }).unwrap();
      setShowAdd(false);
      setAddForm({ name: "", description: "", orderIndex: levels.length });
      showMsg("success", "Đã thêm cấp độ");
    } catch {
      showMsg("error", "Thêm thất bại");
    }
  };

  const startEdit = (lv: LearningLevel) => {
    setEditingId(lv.id);
    setEditForm({ name: lv.name, description: lv.description ?? "", orderIndex: lv.orderIndex });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;
    try {
      await updateLevel({
        id: editingId,
        name: editForm.name,
        description: editForm.description || undefined,
        orderIndex: editForm.orderIndex,
      }).unwrap();
      setEditingId(null);
      showMsg("success", "Đã cập nhật cấp độ");
    } catch {
      showMsg("error", "Cập nhật thất bại");
    }
  };

  const handleToggleActive = async (lv: LearningLevel) => {
    try {
      await setActive({ id: lv.id, active: !lv.isActive }).unwrap();
      showMsg("success", lv.isActive ? "Đã ẩn cấp độ" : "Đã kích hoạt cấp độ");
    } catch {
      showMsg("error", "Thao tác thất bại");
    }
  };

  const handleDelete = async (lv: LearningLevel) => {
    if (!confirm(`Xóa cấp độ "${lv.name}"? Các khóa học sử dụng cấp độ này sẽ không bị ảnh hưởng.`)) return;
    try {
      await deleteLevel(lv.id).unwrap();
      showMsg("success", "Đã xóa cấp độ");
    } catch {
      showMsg("error", "Xóa thất bại");
    }
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Quản lý Cấp độ</h1>
          <p className="mt-1 text-sm text-gray-500">
            Cấu hình danh sách cấp độ khóa học (Beginner, Elementary...). Danh sách này được dùng khi tạo/sửa khóa học.
          </p>
        </div>
        <button
          onClick={() => { setShowAdd(true); setAddForm({ name: "", description: "", orderIndex: levels.length }); }}
          className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
        >
          + Thêm cấp độ
        </button>
      </div>

      {msg && (
        <div className={`mb-4 rounded-lg px-4 py-3 text-sm font-medium ${msg.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
          {msg.text}
        </div>
      )}

      {isLoading ? (
        <div className="py-10 text-center text-gray-400">Đang tải...</div>
      ) : levels.length === 0 ? (
        <div className="rounded-xl border-2 border-dashed border-gray-200 py-16 text-center">
          <div className="mb-3 text-5xl">🎓</div>
          <p className="font-semibold text-gray-600">Chưa có cấp độ nào</p>
          <p className="mt-1 text-sm text-gray-400">Nhấn "+ Thêm cấp độ" để cấu hình danh sách cấp độ</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-xs font-semibold uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-5 py-3 text-left">Thứ tự</th>
                <th className="px-5 py-3 text-left">Tên cấp độ</th>
                <th className="px-5 py-3 text-left">Mô tả</th>
                <th className="px-5 py-3 text-center">Trạng thái</th>
                <th className="px-5 py-3 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {[...levels].sort((a, b) => a.orderIndex - b.orderIndex).map((lv) => (
                <tr key={lv.id} className={`transition-colors hover:bg-gray-50/50 ${!lv.isActive ? "opacity-50" : ""}`}>
                  {editingId === lv.id ? (
                    <td colSpan={5} className="px-5 py-4">
                      <form onSubmit={handleSave} className="flex flex-wrap items-end gap-3">
                        <div style={{ width: 80 }}>
                          <label className={labelCls}>Thứ tự</label>
                          <input type="number" min={0} value={editForm.orderIndex}
                            onChange={(e) => setEditForm({ ...editForm, orderIndex: Number(e.target.value) })}
                            className={inputCls} />
                        </div>
                        <div style={{ flex: "1 1 180px" }}>
                          <label className={labelCls}>Tên <span className="text-red-500">*</span></label>
                          <input required value={editForm.name}
                            onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                            className={inputCls} placeholder="VD: Cấp 1 – Beginner" />
                        </div>
                        <div style={{ flex: "2 1 240px" }}>
                          <label className={labelCls}>Mô tả</label>
                          <input value={editForm.description}
                            onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                            className={inputCls} placeholder="Dành cho người mới bắt đầu..." />
                        </div>
                        <div className="flex gap-2 pb-0.5">
                          <button type="submit" disabled={updating}
                            className="rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                            {updating ? "Đang lưu..." : "Lưu"}
                          </button>
                          <button type="button" onClick={() => setEditingId(null)}
                            className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm hover:bg-gray-50">
                            Hủy
                          </button>
                        </div>
                      </form>
                    </td>
                  ) : (
                    <>
                      <td className="px-5 py-4">
                        <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-700">
                          {lv.orderIndex + 1}
                        </span>
                      </td>
                      <td className="px-5 py-4 font-medium text-gray-900">{lv.name}</td>
                      <td className="px-5 py-4 text-gray-500">{lv.description ?? <span className="italic text-gray-300">—</span>}</td>
                      <td className="px-5 py-4 text-center">
                        <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          lv.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                        }`}>
                          {lv.isActive ? "Hoạt động" : "Đã ẩn"}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <button onClick={() => handleToggleActive(lv)}
                            className={`rounded-lg px-3 py-1 text-xs font-medium ${
                              lv.isActive
                                ? "bg-orange-50 text-orange-600 hover:bg-orange-100"
                                : "bg-green-50 text-green-600 hover:bg-green-100"
                            }`}>
                            {lv.isActive ? "Ẩn" : "Kích hoạt"}
                          </button>
                          <ActionButtons
                            onEdit={() => startEdit(lv)}
                            onDelete={() => handleDelete(lv)}
                          />
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
            <h2 className="mb-4 text-lg font-semibold">Thêm cấp độ mới</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className={labelCls}>Tên cấp độ <span className="text-red-500">*</span></label>
                <input required value={addForm.name}
                  onChange={(e) => setAddForm({ ...addForm, name: e.target.value })}
                  className={inputCls}
                  placeholder="VD: Cấp 1 – Beginner" />
              </div>
              <div>
                <label className={labelCls}>Mô tả</label>
                <input value={addForm.description}
                  onChange={(e) => setAddForm({ ...addForm, description: e.target.value })}
                  className={inputCls}
                  placeholder="VD: Dành cho người mới bắt đầu hoàn toàn" />
              </div>
              <div>
                <label className={labelCls}>Thứ tự hiển thị</label>
                <input type="number" min={0} value={addForm.orderIndex}
                  onChange={(e) => setAddForm({ ...addForm, orderIndex: Number(e.target.value) })}
                  className={inputCls} />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowAdd(false)}
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">
                  Hủy
                </button>
                <button type="submit" disabled={creating}
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                  {creating ? "Đang thêm..." : "Thêm"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
