"use client";

import { useParams, useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import type { RootState } from "@/lib/store";
import {
  useGetTeacherBySlugQuery,
  useGetTeacherCoursesQuery,
  useFollowTeacherMutation,
  useUnfollowTeacherMutation,
  type TeacherCourseItem,
} from "@/lib/features/teachers/teachersApi";
import { safeImgUrl } from "@/lib/utils";
import Link from "next/link";
import { useState } from "react";
import AppShell from "@/app/_components/AppShell";

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtNumber(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

function fmtPrice(p: number) {
  return p.toLocaleString("vi-VN") + "đ";
}

const LEVEL_LABELS: Record<number, string> = {
  1: "Cấp 1 - Nhập môn",
  2: "Cấp 2 - Sơ cấp",
  3: "Cấp 3 - Trước trung cấp",
  4: "Cấp 4 - Trung cấp",
  5: "Cấp 5 - Trên trung cấp",
  6: "Cấp 6 - Nâng cao",
};

// ── Course Card ───────────────────────────────────────────────────────────────

function CourseCard({ course }: { course: TeacherCourseItem }) {
  const thumb = safeImgUrl(course.thumbnailUrl);
  const hasDiscount = course.discountPrice != null && course.discountPrice < course.price;
  return (
    <Link
      href={`/khoa-hoc/${course.id}`}
      style={{
        display: "block",
        border: "1px solid #E2E8F0",
        borderRadius: 10,
        overflow: "hidden",
        background: "#fff",
        transition: "box-shadow 0.15s",
        textDecoration: "none",
        color: "inherit",
      }}
      onMouseEnter={(e) => (e.currentTarget.style.boxShadow = "0 4px 16px rgba(0,0,0,0.12)")}
      onMouseLeave={(e) => (e.currentTarget.style.boxShadow = "none")}
    >
      {/* Thumbnail */}
      <div style={{ aspectRatio: "16/9", background: "#EBF4FF", position: "relative", overflow: "hidden" }}>
        {thumb ? (
          <img src={thumb} alt={course.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, color: "#90CAF9" }}>
            📚
          </div>
        )}
      </div>
      {/* Info */}
      <div style={{ padding: "12px 14px 14px" }}>
        <div style={{ fontSize: 11, color: "#64748B", marginBottom: 4 }}>
          {LEVEL_LABELS[course.level] ?? `Cấp ${course.level}`}
        </div>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#1E293B", lineHeight: 1.4, marginBottom: 8, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
          {course.title}
        </div>
        {course.shortDescription && (
          <div style={{ fontSize: 12, color: "#64748B", marginBottom: 8, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
            {course.shortDescription}
          </div>
        )}
        {/* Price */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {course.isFree ? (
            <span style={{ fontSize: 15, fontWeight: 800, color: "#16A34A" }}>Miễn phí</span>
          ) : (
            <>
              <span style={{ fontSize: 16, fontWeight: 800, color: "#E53E3E" }}>
                {fmtPrice(hasDiscount ? course.discountPrice! : course.price)}
              </span>
              {hasDiscount && (
                <span style={{ fontSize: 12, color: "#94A3B8", textDecoration: "line-through" }}>
                  {fmtPrice(course.price)}
                </span>
              )}
            </>
          )}
        </div>
      </div>
    </Link>
  );
}

// ── Stat Item ─────────────────────────────────────────────────────────────────

function StatItem({ value, label }: { value: string; label: string }) {
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{ fontSize: 22, fontWeight: 800, color: "#111827", lineHeight: 1.2 }}>{value}</div>
      <div style={{ fontSize: 11, color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.07em", marginTop: 2 }}>{label}</div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function TeacherPage() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug;
  const router = useRouter();

  const isLoggedIn = useSelector((s: RootState) => !!s.auth.accessToken);

  const { data: teacher, isLoading, isError } = useGetTeacherBySlugQuery(slug);
  const { data: courses = [] } = useGetTeacherCoursesQuery(teacher?.id ?? "", {
    skip: !teacher?.id,
  });

  const [follow] = useFollowTeacherMutation();
  const [unfollow] = useUnfollowTeacherMutation();
  const [followLoading, setFollowLoading] = useState(false);

  async function handleFollow() {
    if (!isLoggedIn) { router.push("/login"); return; }
    if (!teacher) return;
    setFollowLoading(true);
    try {
      if (teacher.isFollowing) await unfollow(teacher.id);
      else await follow(teacher.id);
    } finally {
      setFollowLoading(false);
    }
  }

  const avatarUrl = safeImgUrl(teacher?.avatarUrl);
  const avatarInitial = teacher?.displayName?.[0]?.toUpperCase() ?? "T";

  return (
    <>
      <style>{`
        .mls-scroll { scrollbar-width: thin; scrollbar-color: transparent transparent; }
        .mls-scroll::-webkit-scrollbar { width: 4px; }
        .mls-scroll::-webkit-scrollbar-track { background: transparent; }
        .mls-scroll::-webkit-scrollbar-thumb { background: transparent; border-radius: 99px; }
        .mls-scroll:hover::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.18); }
        .mls-scroll:hover { scrollbar-color: rgba(0,0,0,0.18) transparent; }
      `}</style>
      <AppShell activeNavId="following">
        {/* ══ COL 3+4 merged: Teacher profile content ══ */}
        <div className="mls-scroll" style={{
          flex: 1, minWidth: 0, overflowY: "auto",
          background: "#F8FAFC",
          height: "calc(100vh - 56px)",
        }}>

          {/* Loading state */}
          {isLoading && (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh" }}>
              <div style={{ width: 40, height: 40, borderRadius: "50%", border: "3px solid #E2E8F0", borderTop: "3px solid #1565C0", animation: "spin 0.8s linear infinite" }} />
              <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
            </div>
          )}

          {/* Error state */}
          {(isError || (!isLoading && !teacher)) && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "60vh", gap: 12 }}>
              <div style={{ fontSize: 48 }}>😕</div>
              <div style={{ fontSize: 18, fontWeight: 700, color: "#1E293B" }}>Không tìm thấy giáo viên</div>
              <Link href="/" style={{ color: "#1565C0", fontSize: 14 }}>Quay về trang chủ</Link>
            </div>
          )}

          {/* Teacher content */}
          {teacher && (
            <>
              {/* ── Profile Card — moon.vn style ── */}
              <div style={{ background: "#fff", borderBottom: "1px solid #E2E8F0" }}>
                <div style={{ padding: "28px 32px 24px", display: "flex", gap: 24, alignItems: "flex-start" }}>

                  {/* LEFT: Avatar */}
                  <div style={{ flexShrink: 0, display: "flex", flexDirection: "column", alignItems: "center", gap: 0 }}>
                    {avatarUrl ? (
                      <img src={avatarUrl} alt={teacher.displayName}
                        style={{ width: 100, height: 100, borderRadius: "50%", objectFit: "cover", border: "3px solid #E2E8F0", display: "block" }} />
                    ) : (
                      <div style={{
                        width: 100, height: 100, borderRadius: "50%",
                        background: "linear-gradient(135deg, #1565C0, #0D47A1)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 38, fontWeight: 800, color: "#fff", border: "3px solid #E2E8F0",
                      }}>
                        {avatarInitial}
                      </div>
                    )}
                  </div>

                  {/* CENTER: Name, bio, buttons */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    {/* Name + verified */}
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                      <h1 style={{ fontSize: 20, fontWeight: 800, color: "#1E293B", margin: 0, lineHeight: 1.3 }}>
                        {teacher.displayName}
                      </h1>
                      {teacher.isVerified && (
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" title="Đã xác minh">
                          <circle cx="10" cy="10" r="10" fill="#16A34A" />
                          <path d="M6 10l3 3 5-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      )}
                    </div>

                    {/* Bio */}
                    {(teacher.bio || teacher.headline) && (
                      <div style={{ fontSize: 13, color: "#374151", lineHeight: 1.65, marginBottom: 16, whiteSpace: "pre-line" }}>
                        {teacher.bio || teacher.headline}
                      </div>
                    )}

                    {/* Buttons */}
                    <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                      <button onClick={handleFollow} disabled={followLoading} style={{
                        padding: "8px 28px", borderRadius: 24, fontSize: 14, fontWeight: 700,
                        cursor: "pointer", border: "none", minWidth: 110,
                        background: teacher.isFollowing ? "#F1F5F9" : "#EF4444",
                        color: teacher.isFollowing ? "#475569" : "#fff",
                        transition: "background 0.15s",
                      }}>
                        {followLoading ? "..." : teacher.isFollowing ? "Đang theo dõi" : "Theo dõi"}
                      </button>
                      <button style={{
                        padding: "8px 22px", borderRadius: 24, fontSize: 14, fontWeight: 600,
                        cursor: "pointer", border: "1px solid #CBD5E1", background: "#fff",
                        color: "#374151", display: "flex", alignItems: "center", gap: 6,
                      }}>
                        <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                        Nhắn tin
                      </button>

                      {/* Social links */}
                      {teacher.facebookUrl && (
                        <a href={teacher.facebookUrl} target="_blank" rel="noopener noreferrer"
                          style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 34, height: 34, borderRadius: "50%", background: "#EBF4FF", color: "#1565C0", fontSize: 14, textDecoration: "none", fontWeight: 700 }}>
                          f
                        </a>
                      )}
                      {teacher.youtubeUrl && (
                        <a href={teacher.youtubeUrl} target="_blank" rel="noopener noreferrer"
                          style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 34, height: 34, borderRadius: "50%", background: "#FEE2E2", color: "#DC2626", fontSize: 13, textDecoration: "none" }}>
                          ▶
                        </a>
                      )}
                      {teacher.tiktokUrl && (
                        <a href={teacher.tiktokUrl} target="_blank" rel="noopener noreferrer"
                          style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 34, height: 34, borderRadius: "50%", background: "#F3F4F6", color: "#111827", fontSize: 13, textDecoration: "none", border: "1px solid #E5E7EB" }}>
                          ♪
                        </a>
                      )}
                      {teacher.websiteUrl && (
                        <a href={teacher.websiteUrl} target="_blank" rel="noopener noreferrer"
                          style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 34, height: 34, borderRadius: "50%", background: "#F0FDF4", color: "#16A34A", fontSize: 13, textDecoration: "none" }}>
                          🌐
                        </a>
                      )}
                    </div>
                  </div>

                  {/* RIGHT: Stats */}
                  <div style={{ flexShrink: 0, display: "flex", gap: 32, alignItems: "center" }}>
                    <StatItem value={fmtNumber(teacher.totalViews)} label="Views" />
                    <StatItem value={fmtNumber(teacher.totalStudents)} label="Likes" />
                    <StatItem value={fmtNumber(teacher.followerCount)} label="Followers" />
                  </div>
                </div>
              </div>

              {/* ── Shop / Courses ── */}
              <div style={{ padding: "24px 32px" }}>
                <h2 style={{ fontSize: 17, fontWeight: 800, color: "#1E293B", marginBottom: 16, marginTop: 0 }}>Shop</h2>

                {courses.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "48px 0", color: "#94A3B8", fontSize: 14 }}>
                    Giáo viên chưa có khóa học nào được công bố.
                  </div>
                ) : (
                  <div style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
                    gap: 14,
                  }}>
                    {courses.map((c) => (
                      <CourseCard key={c.id} course={c} />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </AppShell>
    </>
  );
}
