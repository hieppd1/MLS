"use client";

import { useState } from "react";
import Link from "next/link";
import { useSelector } from "react-redux";
import type { RootState } from "@/lib/store";
import { safeImgUrl } from "@/lib/utils";
import {
  useGetPublicCoursesQuery,
  type PublicCourseListItem,
} from "@/lib/features/courses/coursesApi";

/* ═══════════════════════════════════════════════════════════════
   CONSTANTS
═══════════════════════════════════════════════════════════════ */
const LEVEL_LABELS: Record<number, string> = {
  1: "Nhập môn", 2: "Cơ bản", 3: "Sơ trung",
  4: "Trung cấp", 5: "Trung cao", 6: "Nâng cao",
};

const LEFT_NAV = [
  { id: "new",       label: "Bài học mới",       href: "/my-lesson",  requireAuth: false,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg> },
  { id: "enrolled",  label: "Khoá đã kích hoạt", href: "/my-courses", requireAuth: true,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg> },
  { id: "group",     label: "Nhóm của tôi",       href: "/groups",     requireAuth: true,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
  { id: "following", label: "Đang theo dõi",      href: "/following",  requireAuth: true,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg> },
  { id: "saved",     label: "Đã lưu",             href: "/saved",      requireAuth: true,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg> },
  { id: "liked",     label: "Đã thích",           href: "/liked",      requireAuth: true,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg> },
  { id: "friends",   label: "Bạn bè",             href: "/friends",    requireAuth: true,
    icon: <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg> },
];

/* ═══════════════════════════════════════════════════════════════
   MOCK CHAT DATA + ChatItem (Col 2)
═══════════════════════════════════════════════════════════════ */
interface MockChat {
  id: string; name: string; init: string; color: string;
  lastMsg: string; time: string; unread: number; online: boolean;
  type: "message" | "group" | "qa" | "notify";
}

const MOCK_CHATS: MockChat[] = [
  { id: "c1", name: "Thầy Lê Văn Tuấn",       init: "LT", color: "#1565C0",
    lastMsg: "Bạn: Đã tạo hội thoại!",         time: "2 ph",   unread: 0, online: true,  type: "message" },
  { id: "c2", name: "Nhóm Tiếng Anh Cấp 2",   init: "TA", color: "#16A34A",
    lastMsg: "Cô Trang Anh: Bài tập hôm nay về nhà là...", time: "15 ph",  unread: 3, online: false, type: "group" },
  { id: "c3", name: "Thầy Chu Đình Mong",      init: "CM", color: "#DC2626",
    lastMsg: "Hẹn gặp lại buổi học tới nhé",   time: "1 giờ",  unread: 0, online: true,  type: "message" },
  { id: "c4", name: "Hỏi & Đáp: Ngữ pháp",    init: "HĐ", color: "#7C3AED",
    lastMsg: "Bạn hỏi: Cách dùng had been?",   time: "2 giờ",  unread: 1, online: false, type: "qa" },
  { id: "c5", name: "Thầy Phan Khắc Nghệ",    init: "PN", color: "#0891B2",
    lastMsg: "Xem lại bài giảng số 5 nhé em",  time: "3 giờ",  unread: 0, online: false, type: "message" },
  { id: "c6", name: "Nhóm Học Cấp 3 THPT",    init: "N3", color: "#EA580C",
    lastMsg: "Có 2 thành viên mới tham gia",   time: "5 giờ",  unread: 2, online: false, type: "group" },
  { id: "c7", name: "Thông báo khoá học",      init: "TB", color: "#CA8A04",
    lastMsg: "Khoá học nâng cao khai giảng 01/06", time: "1 ngày", unread: 1, online: false, type: "notify" },
  { id: "c8", name: "Nhóm Luyện Nói Online",   init: "LN", color: "#0D9488",
    lastMsg: "Buổi tới: Thứ 3, 20:00",         time: "2 ngày", unread: 0, online: false, type: "group" },
  { id: "c9", name: "Cô Trang Anh",            init: "TA", color: "#DB2777",
    lastMsg: "Cô đã gửi tài liệu mới",         time: "3 ngày", unread: 0, online: false, type: "message" },
];

const CHAT_TYPE_ICON: Record<string, string> = { group: "👥", qa: "❓", notify: "🔔", message: "" };

function ChatItem({ chat, selected, onClick }: { chat: MockChat; selected: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "11px 14px", width: "100%", textAlign: "left",
      background: selected ? "#EFF6FF" : "transparent",
      borderTop: "none", borderRight: "none",
      borderBottom: "1px solid #f3f4f6",
      borderLeft: selected ? "3px solid #1565C0" : "3px solid transparent",
      cursor: "pointer",
    }}>
      <div style={{ position: "relative", flexShrink: 0 }}>
        <div style={{
          width: 44, height: 44, borderRadius: "50%", background: chat.color,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "#fff", fontWeight: 700, fontSize: 13,
        }}>
          {chat.init}
        </div>
        {chat.online && (
          <div style={{
            position: "absolute", bottom: 1, right: 1,
            width: 11, height: 11, borderRadius: "50%",
            background: "#22C55E", border: "2px solid #fff",
          }} />
        )}
        {CHAT_TYPE_ICON[chat.type] && (
          <div style={{
            position: "absolute", bottom: -2, right: -2, width: 17, height: 17,
            borderRadius: "50%", background: "#fff", border: "1px solid #E5E7EB",
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9,
          }}>{CHAT_TYPE_ICON[chat.type]}</div>
        )}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 3 }}>
          <span style={{
            fontSize: 13, fontWeight: chat.unread > 0 ? 700 : 600, color: "#111827",
            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 140,
          }}>{chat.name}</span>
          <span style={{ fontSize: 10, color: "#9CA3AF", flexShrink: 0, marginLeft: 6 }}>{chat.time}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{
            fontSize: 12, color: chat.unread > 0 ? "#374151" : "#9CA3AF",
            fontWeight: chat.unread > 0 ? 500 : 400,
            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 172,
          }}>{chat.lastMsg}</span>
          {chat.unread > 0 && (
            <div style={{
              background: "#1565C0", color: "#fff", fontSize: 10, fontWeight: 700,
              minWidth: 18, height: 18, borderRadius: 99,
              display: "flex", alignItems: "center", justifyContent: "center",
              paddingLeft: 4, paddingRight: 4, flexShrink: 0, marginLeft: 4,
            }}>{chat.unread}</div>
          )}
        </div>
      </div>
    </button>
  );
}

/* ═══════════════════════════════════════════════════════════════
   LESSON ROW (Col 3 table)
═══════════════════════════════════════════════════════════════ */
function LessonRow({ course, index, saved, onSave }: {
  course: PublicCourseListItem; index: number; saved: boolean; onSave: () => void;
}) {
  const price = course.price ?? 0;
  const hasDiscount = course.discountPrice != null && course.discountPrice < price;
  return (
    <Link href={`/khoa-hoc/${course.id}`} style={{ textDecoration: "none", display: "block" }}>
      <div
        style={{ display: "grid", gridTemplateColumns: "48px 1fr 130px 52px", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #F3F4F6", background: "transparent", cursor: "pointer" }}
        onMouseEnter={e => (e.currentTarget as HTMLDivElement).style.background = "#F9FAFB"}
        onMouseLeave={e => (e.currentTarget as HTMLDivElement).style.background = "transparent"}
      >
        <span style={{ fontSize: 13, color: "#9CA3AF", textAlign: "center" }}>{index + 1}</span>
        <div style={{ display: "flex", alignItems: "center", gap: 12, paddingRight: 12 }}>
          <div style={{ width: 80, height: 50, flexShrink: 0, borderRadius: 6, overflow: "hidden", background: "linear-gradient(135deg,#1565C0,#0D47A1)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {safeImgUrl(course.thumbnailUrl)
              ? <img src={safeImgUrl(course.thumbnailUrl)!} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              : <svg width="16" height="16" fill="white" viewBox="0 0 20 20"><path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z"/></svg>
            }
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 13, fontWeight: 600, color: "#111827", lineHeight: 1.4, marginBottom: 4, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{course.title}</p>
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span style={{ fontSize: 10, background: "#EFF6FF", color: "#1565C0", fontWeight: 700, padding: "1px 8px", borderRadius: 99 }}>{LEVEL_LABELS[course.level] ?? `Cấp ${course.level}`}</span>
              <span style={{ fontSize: 11, color: "#9CA3AF" }}>{course.moduleCount} chương • {course.lessonCount} bài</span>
            </div>
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          {course.isEnrolled
            ? <span style={{ fontSize: 12, color: "#16A34A", fontWeight: 600 }}>✓ Đang học</span>
            : price === 0
              ? <span style={{ fontSize: 12, color: "#16A34A", fontWeight: 600 }}>Miễn phí</span>
              : hasDiscount
                ? <div>
                    <span style={{ fontSize: 12, color: "#DC2626", fontWeight: 700, display: "block" }}>{(course.discountPrice!).toLocaleString("vi-VN")}đ</span>
                    <span style={{ fontSize: 10, color: "#9CA3AF", textDecoration: "line-through" }}>{price.toLocaleString("vi-VN")}đ</span>
                  </div>
                : <span style={{ fontSize: 12, color: "#DC2626", fontWeight: 700 }}>{price.toLocaleString("vi-VN")}đ</span>
          }
        </div>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <button onClick={(e) => { e.preventDefault(); onSave(); }} style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
            <svg width="18" height="18" fill={saved ? "#1565C0" : "none"} viewBox="0 0 24 24" stroke={saved ? "#1565C0" : "#9CA3AF"} strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
            </svg>
          </button>
        </div>
      </div>
    </Link>
  );
}

/* ═══════════════════════════════════════════════════════════════
   MY LESSON PAGE
═══════════════════════════════════════════════════════════════ */
export default function MyLessonPage() {
  const isLoggedIn = useSelector((s: RootState) => !!s.auth?.accessToken);

  // Chat state
  const [chatSearch,     setChatSearch]     = useState("");
  const [chatTab,        setChatTab]        = useState<"all" | "unread">("all");
  const [showChatFilter, setShowChatFilter] = useState(false);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);

  // Lesson table state
  const [lessonTab,   setLessonTab]   = useState<"new" | "unread" | "done" | "schedule">("new");
  const [lessonLevel, setLessonLevel] = useState<number | undefined>(undefined);
  const [savedIds,    setSavedIds]    = useState<Set<string>>(new Set());

  const { data: courses, isLoading } = useGetPublicCoursesQuery({ page: 1, pageSize: 50 });

  const filteredChats = MOCK_CHATS.filter((c) => {
    if (chatSearch && !c.name.toLowerCase().includes(chatSearch.toLowerCase()) &&
        !c.lastMsg.toLowerCase().includes(chatSearch.toLowerCase())) return false;
    if (chatTab === "unread" && c.unread === 0) return false;
    return true;
  });

  const filteredLessons = (courses?.items ?? []).filter((c) => {
    if (lessonLevel !== undefined && c.level !== lessonLevel) return false;
    if (lessonTab === "done" && !c.isEnrolled) return false;
    if (lessonTab === "unread" && c.isEnrolled) return false;
    return true;
  });

  const savedCourses = (courses?.items ?? []).filter(c => savedIds.has(c.id));

  return (
    <>
      <style>{`
        .ml-scroll { scrollbar-width: thin; scrollbar-color: transparent transparent; }
        .ml-scroll::-webkit-scrollbar { width: 4px; }
        .ml-scroll::-webkit-scrollbar-track { background: transparent; }
        .ml-scroll::-webkit-scrollbar-thumb { background: transparent; border-radius: 99px; }
        .ml-scroll:hover::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.18); }
        .ml-scroll:hover { scrollbar-color: rgba(0,0,0,0.18) transparent; }
      `}</style>

      <div style={{ display: "flex", height: "calc(100vh - 56px)", overflow: "hidden", background: "#F3F4F6" }}>

        {/* ═══ COL 1: LEFT NAV (72px) ════════════════════════════ */}
        <aside className="ml-scroll" style={{
          width: 72, flexShrink: 0,
          background: "white", borderRight: "1px solid #e5e7eb",
          display: "flex", flexDirection: "column", alignItems: "center",
          paddingTop: 8, overflowY: "auto", zIndex: 10,
        }}>
          {LEFT_NAV.map((item) => {
            const locked  = item.requireAuth && !isLoggedIn;
            const active  = item.id === "new";
            return (
              <Link key={item.id} href={locked ? "/login" : item.href}
                style={{
                  display: "flex", flexDirection: "column", alignItems: "center",
                  gap: 4, padding: "10px 4px", width: "100%", textAlign: "center",
                  textDecoration: "none",
                  color: active ? "#1565C0" : locked ? "#D1D5DB" : "#6B7280",
                  background: active ? "#EFF6FF" : "transparent",
                  borderTop: "none", borderRight: "none", borderBottom: "none",
                  borderLeft: active ? "3px solid #1565C0" : "3px solid transparent",
                }}
                title={item.label}
              >
                {item.icon}
                <span style={{ fontSize: 9, fontWeight: 500, lineHeight: 1.2 }}>{item.label}</span>
              </Link>
            );
          })}
        </aside>

        {/* ═══ COL 2: TIN NHẮN (290px) ═══════════════════════════ */}
        <div style={{
          width: 290, flexShrink: 0,
          background: "white", borderRight: "1px solid #e5e7eb",
          display: "flex", flexDirection: "column", zIndex: 10,
        }}>
          {/* Header */}
          <div style={{ padding: "14px 14px 0", borderBottom: "1px solid #f3f4f6", flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, color: "#111827", margin: 0 }}>Tin nhắn</h2>
              <button style={{
                width: 28, height: 28, borderRadius: "50%", border: "1px solid #E5E7EB",
                background: "#F9FAFB", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#6B7280" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                </svg>
              </button>
            </div>
            {/* Search */}
            <div style={{ position: "relative", marginBottom: 10 }}>
              <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#9CA3AF"
                style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0" />
              </svg>
              <input
                type="text" placeholder="Tìm tin nhắn..." value={chatSearch}
                onChange={e => setChatSearch(e.target.value)}
                style={{
                  width: "100%", paddingLeft: 32, paddingRight: 10, paddingTop: 8, paddingBottom: 8,
                  border: "1px solid #E5E7EB", borderRadius: 20, fontSize: 12,
                  outline: "none", boxSizing: "border-box", background: "#F9FAFB",
                }}
              />
            </div>
            {/* Tabs */}
            <div style={{ display: "flex", alignItems: "center" }}>
              {(["all", "unread"] as const).map((tab) => (
                <button key={tab} onClick={() => setChatTab(tab)} style={{
                  padding: "7px 14px", fontSize: 12, fontWeight: 500,
                  borderTop: "none", borderLeft: "none", borderRight: "none",
                  borderBottom: chatTab === tab ? "2px solid #1565C0" : "2px solid transparent",
                  cursor: "pointer", background: "transparent",
                  color: chatTab === tab ? "#1565C0" : "#6B7280",
                }}>
                  {tab === "all" ? "Tất cả" : "Chưa đọc"}
                </button>
              ))}
              <div style={{ position: "relative", marginLeft: "auto" }}>
                <button onClick={() => setShowChatFilter(v => !v)} style={{
                  padding: "7px 10px", fontSize: 12, fontWeight: 500,
                  borderTop: "none", borderLeft: "none", borderRight: "none",
                  borderBottom: showChatFilter ? "2px solid #1565C0" : "2px solid transparent",
                  cursor: "pointer", background: "transparent",
                  color: showChatFilter ? "#1565C0" : "#6B7280",
                }}>
                  Phân loại ▾
                </button>
                {showChatFilter && (
                  <div style={{
                    position: "absolute", right: 0, top: "100%", zIndex: 50,
                    background: "white", border: "1px solid #E5E7EB", borderRadius: 8,
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)", minWidth: 120, padding: "4px 0",
                  }}>
                    {["Giáo viên", "Nhóm học", "Hỏi & Đáp", "Thông báo"].map((label) => (
                      <button key={label} style={{
                        display: "block", width: "100%", textAlign: "left",
                        padding: "8px 14px", fontSize: 12, color: "#374151",
                        background: "none", border: "none", cursor: "pointer",
                      }}
                        onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.background = "#F9FAFB"}
                        onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.background = "none"}
                      >{label}</button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {showChatFilter && (
            <div style={{ position: "fixed", inset: 0, zIndex: 40 }} onClick={() => setShowChatFilter(false)} />
          )}

          {/* Unread badge */}
          {MOCK_CHATS.filter(c => c.unread > 0).length > 0 && chatTab === "all" && (
            <div style={{
              margin: "8px 14px 0", padding: "6px 12px", borderRadius: 8,
              background: "#EFF6FF", border: "1px solid #DBEAFE",
              display: "flex", alignItems: "center", justifyContent: "space-between",
            }}>
              <span style={{ fontSize: 12, color: "#1565C0", fontWeight: 500 }}>
                {MOCK_CHATS.filter(c => c.unread > 0).reduce((a, c) => a + c.unread, 0)} tin chưa đọc
              </span>
              <button onClick={() => setChatTab("unread")} style={{
                fontSize: 11, color: "#1565C0", fontWeight: 600,
                background: "none", border: "none", cursor: "pointer", padding: 0,
              }}>Xem tất cả</button>
            </div>
          )}

          {/* Chat list */}
          <div className="ml-scroll" style={{ flex: 1, overflowY: "auto", paddingTop: 4 }}>
            {filteredChats.length === 0 ? (
              <div style={{ padding: "48px 14px", textAlign: "center" }}>
                <div style={{ fontSize: 36, marginBottom: 10 }}>💬</div>
                <p style={{ fontSize: 13, color: "#9CA3AF" }}>Không có tin nhắn nào</p>
              </div>
            ) : filteredChats.map((chat) => (
              <ChatItem key={chat.id} chat={chat}
                selected={selectedChatId === chat.id}
                onClick={() => setSelectedChatId(chat.id)}
              />
            ))}
          </div>
        </div>

        {/* ═══ COL 3: BÀI HỌC MỚI — table (flex-1) ══════════════ */}
        <main className="ml-scroll" style={{ flex: 1, minWidth: 0, background: "#fff", display: "flex", flexDirection: "column", overflow: "hidden" }}>

          {/* Top tabs */}
          <div style={{ borderBottom: "1px solid #E5E7EB", padding: "0 24px", flexShrink: 0 }}>
            <div style={{ display: "flex" }}>
              {(["new", "unread", "done", "schedule"] as const).map((tab) => {
                const labels = { new: "Bài mới", unread: "Bài chưa học", done: "Bài đã học", schedule: "Lịch phát hành" };
                return (
                  <button key={tab} onClick={() => setLessonTab(tab)} style={{
                    padding: "14px 20px", fontSize: 13,
                    fontWeight: lessonTab === tab ? 700 : 400,
                    color: lessonTab === tab ? "#1565C0" : "#374151",
                    borderTop: "none", borderLeft: "none", borderRight: "none",
                    borderBottom: lessonTab === tab ? "2px solid #1565C0" : "2px solid transparent",
                    background: "transparent", cursor: "pointer", whiteSpace: "nowrap",
                  }}>{labels[tab]}</button>
                );
              })}
            </div>
          </div>

          {/* Level filter chips */}
          <div style={{ padding: "10px 24px", display: "flex", gap: 8, overflowX: "auto", flexShrink: 0, borderBottom: "1px solid #F3F4F6", scrollbarWidth: "none" }}>
            {[
              { label: "All",       value: undefined as number | undefined },
              ...[1,2,3,4,5,6].map(n => ({ label: LEVEL_LABELS[n] ?? `Cấp ${n}`, value: n as number | undefined })),
            ].map((item) => (
              <button key={item.label} onClick={() => setLessonLevel(item.value)} style={{
                flexShrink: 0, padding: "5px 18px", borderRadius: 99, fontSize: 12, fontWeight: 500,
                border: lessonLevel === item.value ? "2px solid #1565C0" : "1px solid #E5E7EB",
                background: lessonLevel === item.value ? "#1565C0" : "#fff",
                color: lessonLevel === item.value ? "#fff" : "#374151",
                cursor: "pointer",
              }}>{item.label}</button>
            ))}
          </div>

          {/* Table header */}
          <div style={{ display: "grid", gridTemplateColumns: "48px 1fr 130px 52px", padding: "9px 24px", background: "#F9FAFB", borderBottom: "1px solid #E5E7EB", flexShrink: 0 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: "#6B7280", textAlign: "center" }}>Stt</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: "#6B7280" }}>Bài học</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: "#6B7280", textAlign: "center" }}>Kết quả</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: "#6B7280", textAlign: "center" }}>Lưu</span>
          </div>

          {/* Table body */}
          <div className="ml-scroll" style={{ flex: 1, overflowY: "auto", padding: "0 24px" }}>
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "48px 1fr 130px 52px", padding: "12px 0", borderBottom: "1px solid #F3F4F6", alignItems: "center" }}>
                  <div style={{ width: 24, height: 12, background: "#E5E7EB", borderRadius: 4, margin: "0 auto" }} />
                  <div style={{ display: "flex", gap: 12 }}>
                    <div style={{ width: 80, height: 50, background: "#E5E7EB", borderRadius: 6, flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ height: 12, background: "#E5E7EB", borderRadius: 4, marginBottom: 6 }} />
                      <div style={{ height: 10, width: "50%", background: "#F3F4F6", borderRadius: 4 }} />
                    </div>
                  </div>
                  <div style={{ height: 12, background: "#F3F4F6", borderRadius: 4, margin: "0 auto", width: 60 }} />
                  <div style={{ width: 18, height: 18, background: "#F3F4F6", borderRadius: 4, margin: "0 auto" }} />
                </div>
              ))
            ) : filteredLessons.length === 0 ? (
              <div style={{ padding: "80px 0", textAlign: "center" }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📚</div>
                <p style={{ color: "#9CA3AF", fontSize: 14 }}>Không có dữ liệu</p>
              </div>
            ) : filteredLessons.map((course, i) => (
              <LessonRow
                key={course.id} course={course} index={i}
                saved={savedIds.has(course.id)}
                onSave={() => setSavedIds(prev => {
                  const next = new Set(prev);
                  next.has(course.id) ? next.delete(course.id) : next.add(course.id);
                  return next;
                })}
              />
            ))}
          </div>
        </main>

        {/* ═══ COL 4: BÀI ĐÃ LƯU (270px) ════════════════════════ */}
        <aside className="ml-scroll" style={{
          width: 270, flexShrink: 0,
          background: "white", borderLeft: "1px solid #e5e7eb",
          display: "flex", flexDirection: "column", overflowY: "auto", zIndex: 10,
        }}>
          <div style={{ padding: "16px 16px 12px", borderBottom: "1px solid #F3F4F6", flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: "#111827", margin: 0 }}>Bài đã lưu</h3>
              <button style={{ fontSize: 12, color: "#1565C0", fontWeight: 500, background: "none", border: "none", cursor: "pointer" }}>Xem tất cả</button>
            </div>
          </div>

          <div style={{ flex: 1, overflowY: "auto" }}>
            {savedCourses.length === 0 ? (
              <div style={{ padding: "64px 16px", textAlign: "center" }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>🔖</div>
                <p style={{ fontSize: 13, color: "#9CA3AF", lineHeight: 1.6 }}>
                  Không có dữ liệu<br/>
                  <span style={{ fontSize: 12 }}>Bấm icon lưu để thêm bài học</span>
                </p>
              </div>
            ) : savedCourses.map((course) => (
              <Link key={course.id} href={`/khoa-hoc/${course.id}`} style={{ display: "block", textDecoration: "none" }}>
                <div
                  style={{ display: "flex", gap: 10, padding: "10px 14px", borderBottom: "1px solid #F3F4F6" }}
                  onMouseEnter={e => (e.currentTarget as HTMLDivElement).style.background = "#F9FAFB"}
                  onMouseLeave={e => (e.currentTarget as HTMLDivElement).style.background = "transparent"}
                >
                  <div style={{ width: 60, height: 40, borderRadius: 6, overflow: "hidden", background: "linear-gradient(135deg,#1565C0,#0D47A1)", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {safeImgUrl(course.thumbnailUrl)
                      ? <img src={safeImgUrl(course.thumbnailUrl)!} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      : <svg width="12" height="12" fill="white" viewBox="0 0 20 20"><path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z"/></svg>
                    }
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 12, fontWeight: 600, color: "#111827", lineHeight: 1.4, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{course.title}</p>
                    <p style={{ fontSize: 11, color: "#1565C0", marginTop: 3, fontWeight: 500 }}>{LEVEL_LABELS[course.level] ?? ""}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </aside>

      </div>
    </>
  );
}
