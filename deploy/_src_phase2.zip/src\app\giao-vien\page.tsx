"use client";

import { useState } from "react";
import Link from "next/link";
import AppShell from "@/app/_components/AppShell";
import { useGetTeacherListQuery, type TeacherProfileDto } from "@/lib/features/teachers/teachersApi";
import { safeImgUrl } from "@/lib/utils";

const AVATAR_COLORS = ["#1565C0", "#0D47A1", "#7C3AED", "#DC2626", "#0891B2", "#16A34A", "#EA580C", "#CA8A04"];

function fmtNumber(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

function TeacherCard({ teacher, index }: { teacher: TeacherProfileDto; index: number }) {
  const color = AVATAR_COLORS[index % AVATAR_COLORS.length];
  const initials = teacher.displayName.split(" ").map((w) => w[0]).slice(-2).join("").toUpperCase();
  const imgUrl = safeImgUrl(teacher.avatarUrl);

  return (
    <Link href={`/giao-vien/${teacher.slug}`} style={{ textDecoration: "none" }}>
      <div style={{
        background: "#fff", borderRadius: 14, border: "1px solid #E5E7EB",
        overflow: "hidden", transition: "box-shadow 0.2s",
        cursor: "pointer",
      }}
        onMouseEnter={(e) => (e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.12)")}
        onMouseLeave={(e) => (e.currentTarget.style.boxShadow = "none")}
      >
        {/* Cover */}
        <div style={{
          height: 72, background: color + "22",
          borderBottom: "1px solid #F3F4F6",
          position: "relative",
        }} />
        {/* Avatar */}
        <div style={{ padding: "0 16px 16px", marginTop: -28 }}>
          <div style={{ marginBottom: 10 }}>
            {imgUrl
              ? <img src={imgUrl} alt={teacher.displayName} style={{
                  width: 56, height: 56, borderRadius: "50%",
                  objectFit: "cover", border: "3px solid #fff",
                  boxShadow: "0 2px 10px rgba(0,0,0,0.15)",
                }} />
              : <div style={{
                  width: 56, height: 56, borderRadius: "50%",
                  background: color, border: "3px solid #fff",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "#fff", fontWeight: 700, fontSize: 18,
                  boxShadow: `0 2px 10px ${color}55`,
                }}>{initials}</div>
            }
          </div>

          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8, marginBottom: 4 }}>
            <div style={{ minWidth: 0 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: "#111827", margin: "0 0 2px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {teacher.displayName}
                {teacher.isVerified && <span style={{ marginLeft: 4, color: "#1565C0", fontSize: 13 }}>✓</span>}
              </h3>
              {teacher.specialization && (
                <p style={{ fontSize: 12, color: "#6B7280", margin: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {teacher.specialization}
                </p>
              )}
            </div>
          </div>

          {teacher.headline && (
            <p style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 10, lineHeight: 1.4, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
              {teacher.headline}
            </p>
          )}

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <div style={{ textAlign: "center" }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: "#111827", margin: 0 }}>{fmtNumber(teacher.followerCount)}</p>
              <p style={{ fontSize: 10, color: "#9CA3AF", margin: 0 }}>Theo dõi</p>
            </div>
            <div style={{ textAlign: "center" }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: "#111827", margin: 0 }}>{teacher.courseCount}</p>
              <p style={{ fontSize: 10, color: "#9CA3AF", margin: 0 }}>Khoá học</p>
            </div>
            {teacher.ratingAverage > 0 && (
              <div style={{ textAlign: "center" }}>
                <p style={{ fontSize: 13, fontWeight: 700, color: "#111827", margin: 0 }}>⭐ {teacher.ratingAverage.toFixed(1)}</p>
                <p style={{ fontSize: 10, color: "#9CA3AF", margin: 0 }}>Đánh giá</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}

function SkeletonCard() {
  return (
    <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E5E7EB", overflow: "hidden" }}>
      <div style={{ height: 72, background: "#F3F4F6" }} />
      <div style={{ padding: "0 16px 16px", marginTop: -28 }}>
        <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#E5E7EB", border: "3px solid #fff", marginBottom: 10 }} />
        <div style={{ height: 14, background: "#E5E7EB", borderRadius: 4, marginBottom: 6, width: "70%" }} />
        <div style={{ height: 11, background: "#F3F4F6", borderRadius: 4, marginBottom: 10, width: "50%" }} />
        <div style={{ display: "flex", gap: 12 }}>
          {[0, 1].map((i) => (
            <div key={i}>
              <div style={{ height: 13, width: 32, background: "#E5E7EB", borderRadius: 4, marginBottom: 3 }} />
              <div style={{ height: 10, width: 40, background: "#F3F4F6", borderRadius: 4 }} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function GiaoVienPage() {
  const [search, setSearch] = useState("");
  const { data: teachers, isLoading } = useGetTeacherListQuery({ pageSize: 50 });

  const filtered = teachers?.filter((t) =>
    !search || t.displayName.toLowerCase().includes(search.toLowerCase()) ||
    (t.specialization ?? "").toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  return (
    <AppShell>
      <main style={{
        flex: 1, minWidth: 0, overflowY: "auto",
        background: "#F8FAFC",
      }}>
        {/* Header */}
        <div style={{
          background: "linear-gradient(135deg,#1565C0 0%,#0D47A1 100%)",
          padding: "32px 24px 28px",
        }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#fff", margin: "0 0 4px" }}>Giáo viên</h1>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.75)", margin: "0 0 16px" }}>
            Khám phá các giáo viên tận tâm của MLS
          </p>
          {/* Search */}
          <div style={{ position: "relative", maxWidth: 420 }}>
            <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="rgba(255,255,255,0.6)"
              style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0" />
            </svg>
            <input
              type="text"
              placeholder="Tìm giáo viên..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: "100%", boxSizing: "border-box",
                paddingLeft: 36, paddingRight: 14, paddingTop: 10, paddingBottom: 10,
                background: "rgba(255,255,255,0.15)",
                border: "1px solid rgba(255,255,255,0.3)",
                borderRadius: 10, fontSize: 14, color: "#fff",
                outline: "none",
              }}
            />
          </div>
        </div>

        {/* Grid */}
        <div style={{ padding: "20px 20px 80px" }}>
          {isLoading ? (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16 }}>
              {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px" }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>👨‍🏫</div>
              <p style={{ fontSize: 16, fontWeight: 600, color: "#374151", marginBottom: 6 }}>
                {search ? "Không tìm thấy giáo viên" : "Chưa có giáo viên nào"}
              </p>
              <p style={{ fontSize: 14, color: "#9CA3AF" }}>
                {search ? `Thử tìm kiếm với từ khoá khác` : "Vui lòng quay lại sau."}
              </p>
            </div>
          ) : (
            <>
              <p style={{ fontSize: 13, color: "#6B7280", marginBottom: 16 }}>
                {filtered.length} giáo viên{search ? ` cho "${search}"` : ""}
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16 }}>
                {filtered.map((t, i) => <TeacherCard key={t.id} teacher={t} index={i} />)}
              </div>
            </>
          )}
        </div>
      </main>
    </AppShell>
  );
}
