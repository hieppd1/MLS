"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  useGetLevelQuery,
  useUpdateLevelMutation,
  usePublishLevelMutation,
  useDeleteLevelMutation,
  useCreateModuleMutation,
  useDeleteModuleMutation,
  useUpdateModuleMutation,
} from "@/lib/features/cms/cmsApi";

const inputCls = "w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";
const labelCls = "mb-1 block text-sm font-semibold text-gray-700";

export default function LevelDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();

  const { data: level, isLoading } = useGetLevelQuery(id);
  const [updateLevel, { isLoading: updating }] = useUpdateLevelMutation();
  const [publishLevel] = usePublishLevelMutation();
  const [deleteLevel] = useDeleteLevelMutation();
  const [createModule, { isLoading: creatingModule }] = useCreateModuleMutation();
  const [deleteModule] = useDeleteModuleMutation();
  const [updateModule] = useUpdateModuleMutation();

  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", orderIndex: 0 });
  const [showAddModule, setShowAddModule] = useState(false);
  const [moduleForm, setModuleForm] = useState({ title: "", description: "" });
  const [editingModuleId, setEditingModuleId] = useState<string | null>(null);
  const [editModuleForm, setEditModuleForm] = useState({ title: "", description: "", orderIndex: 0 });
  const [msg, setMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const showMsg = (type: "success" | "error", text: string) => {
    setMsg({ type, text });
    setTimeout(() => setMsg(null), 4000);
  };

  const startEdit = () => {
    if (!level) return;
    setForm({ name: level.name, description: level.description ?? "", orderIndex: level.orderIndex });
    setEditMode(true);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateLevel({ id, courseId: level!.courseId, name: form.name, description: form.description || undefined, orderIndex: form.orderIndex }).unwrap();
      setEditMode(false);
      showMsg("success", "Đã cập nhật level");
    } catch {
      showMsg("error", "Cập nhật thất bại");
    }
  };

  const handleTogglePublish = async () => {
    if (!level) return;
    try {
      await publishLevel({ id, courseId: level.courseId, publish: !level.isPublished }).unwrap();
      showMsg("success", level.isPublished ? "Đã ẩn level" : "Đã publish level");
    } catch {
      showMsg("error", "Thao tác thất bại");
    }
  };

  const handleDelete = async () => {
    if (!level) return;
    if (!confirm(`Xóa level "${level.name}"? Các module sẽ được gỡ khỏi level (không bị xóa).`)) return;
    try {
      await deleteLevel({ id, courseId: level.courseId }).unwrap();
      showMsg("success", "Đã xóa level");
      setTimeout(() => router.push(`/admin/courses/${level.courseId}`), 1000);
    } catch {
      showMsg("error", "Xóa thất bại");
    }
  };

  const handleAddModule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!level) return;
    try {
      await createModule({ courseId: level.courseId, levelId: id, ...moduleForm }).unwrap();
      setShowAddModule(false);
      setModuleForm({ title: "", description: "" });
      showMsg("success", "Đã thêm module");
    } catch {
      showMsg("error", "Thêm module thất bại");
    }
  };

  const handleRemoveModuleFromLevel = async (moduleId: string, moduleTitle: string, orderIndex: number) => {
    if (!confirm(`Gỡ module "${moduleTitle}" khỏi level này?`)) return;
    try {
      await updateModule({ id: moduleId, title: moduleTitle, description: null, orderIndex, isLocked: false, levelId: undefined }).unwrap();
      showMsg("success", "Đã gỡ module khỏi level");
    } catch {
      showMsg("error", "Thao tác thất bại");
    }
  };

  const handleDeleteModule = async (moduleId: string, title: string) => {
    if (!confirm(`Xóa module "${title}"? Toàn bộ bài học trong module sẽ bị xóa.`)) return;
    try {
      await deleteModule({ id: moduleId, courseId: level!.courseId }).unwrap();
      showMsg("success", "Đã xóa module");
    } catch {
      showMsg("error", "Xóa thất bại");
    }
  };

  const startEditModule = (mod: { id: string; title: string; description: string | null; orderIndex: number }) => {
    setEditingModuleId(mod.id);
    setEditModuleForm({ title: mod.title, description: mod.description ?? "", orderIndex: mod.orderIndex });
  };

  const handleSaveModule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingModuleId) return;
    try {
      await updateModule({ id: editingModuleId, ...editModuleForm, description: editModuleForm.description || undefined, levelId: id }).unwrap();
      setEditingModuleId(null);
      showMsg("success", "Đã cập nhật module");
    } catch {
      showMsg("error", "Cập nhật thất bại");
    }
  };

  if (isLoading) return <div className="p-6 text-gray-500">Đang tải...</div>;
  if (!level) return <div className="p-6 text-red-500">Không tìm thấy level</div>;

  return (
    <div className="p-6">
      {/* Breadcrumb */}
      <nav className="mb-4 text-sm text-gray-500">
        <Link href="/admin/courses" className="hover:text-blue-600">Khóa học</Link>
        <span className="mx-2">/</span>
        <Link href={`/admin/courses/${level.courseId}`} className="hover:text-blue-600">Chi tiết khóa học</Link>
        <span className="mx-2">/</span>
        <span className="font-medium text-gray-800">{level.name}</span>
      </nav>

      {msg && (
        <div className={`mb-4 rounded-lg px-4 py-3 text-sm font-medium ${msg.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
          {msg.text}
        </div>
      )}

      {/* Header */}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="text-xl font-bold text-gray-900">{level.name}</h1>
          <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
            level.isPublished ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
          }`}>
            {level.isPublished ? "Đã publish" : "Nháp"}
          </span>
          <span className="rounded-full bg-blue-50 px-2 py-0.5 text-xs text-blue-600">
            Thứ tự: {level.orderIndex + 1}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleTogglePublish}
            className={`rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors ${
              level.isPublished
                ? "border-orange-300 bg-orange-50 text-orange-700 hover:bg-orange-100"
                : "border-green-300 bg-green-50 text-green-700 hover:bg-green-100"
            }`}
          >
            {level.isPublished ? "Ẩn level" : "Publish level"}
          </button>
          <button
            onClick={handleDelete}
            className="rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-100"
          >
            🗑 Xóa level
          </button>
          {!editMode && (
            <button
              onClick={startEdit}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700"
            >
              ✏️ Chỉnh sửa
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left: Level info */}
        <div className="col-span-1">
          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-gray-400">Thông tin Level</h2>

            {editMode ? (
              <form onSubmit={handleUpdate} className="space-y-4">
                <div>
                  <label className={labelCls}>Tên level <span className="text-red-500">*</span></label>
                  <input required value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className={inputCls} placeholder="VD: Cấp độ 1 – Sơ cấp" />
                </div>
                <div>
                  <label className={labelCls}>Mô tả</label>
                  <textarea rows={3} value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className={inputCls} placeholder="Mục tiêu của level này..." />
                </div>
                <div>
                  <label className={labelCls}>Thứ tự hiển thị</label>
                  <input type="number" min={0} value={form.orderIndex}
                    onChange={(e) => setForm({ ...form, orderIndex: Number(e.target.value) })}
                    className={inputCls} />
                </div>
                <div className="flex gap-2 pt-2">
                  <button type="submit" disabled={updating}
                    className="flex-1 rounded-lg bg-blue-600 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                    {updating ? "Đang lưu..." : "Lưu"}
                  </button>
                  <button type="button" onClick={() => setEditMode(false)}
                    className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">
                    Hủy
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-3 text-sm">
                {level.description && (
                  <p className="text-gray-600">{level.description}</p>
                )}
                <div className="flex items-center gap-2 text-gray-500">
                  <span>📦</span>
                  <span><strong>{level.modules.length}</strong> module</span>
                </div>
                <div className="flex items-center gap-2 text-gray-500">
                  <span>📅</span>
                  <span>Tạo: {new Date(level.createdAt).toLocaleDateString("vi-VN")}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-500">
                  <span>🔢</span>
                  <span>Thứ tự: {level.orderIndex + 1}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Modules list */}
        <div className="col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-semibold text-gray-900">
              Modules trong level ({level.modules.length})
            </h2>
            <button onClick={() => setShowAddModule(true)}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700">
              + Thêm module
            </button>
          </div>

          {level.modules.length === 0 ? (
            <div className="rounded-xl border-2 border-dashed border-gray-200 py-14 text-center">
              <div className="mb-2 text-4xl">📦</div>
              <p className="font-medium text-gray-500">Chưa có module nào trong level này</p>
              <p className="mt-1 text-sm text-gray-400">Nhấn "+ Thêm module" để thêm mới</p>
            </div>
          ) : (
            <div className="space-y-3">
              {level.modules.map((mod, idx) => (
                <div key={mod.id} className="rounded-xl border border-gray-200 bg-white shadow-sm">
                  {editingModuleId === mod.id ? (
                    <form onSubmit={handleSaveModule} className="p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className={labelCls}>Tên module</label>
                          <input required value={editModuleForm.title}
                            onChange={(e) => setEditModuleForm({ ...editModuleForm, title: e.target.value })}
                            className={inputCls} />
                        </div>
                        <div>
                          <label className={labelCls}>Thứ tự</label>
                          <input type="number" min={0} value={editModuleForm.orderIndex}
                            onChange={(e) => setEditModuleForm({ ...editModuleForm, orderIndex: Number(e.target.value) })}
                            className={inputCls} />
                        </div>
                      </div>
                      <div>
                        <label className={labelCls}>Mô tả</label>
                        <input value={editModuleForm.description}
                          onChange={(e) => setEditModuleForm({ ...editModuleForm, description: e.target.value })}
                          className={inputCls} placeholder="Mục tiêu module..." />
                      </div>
                      <div className="flex gap-2">
                        <button type="submit"
                          className="rounded-lg bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-700">
                          Lưu
                        </button>
                        <button type="button" onClick={() => setEditingModuleId(null)}
                          className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">
                          Hủy
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="flex items-center justify-between px-5 py-4">
                      <div className="flex items-center gap-4">
                        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-sm font-bold text-blue-700">
                          {idx + 1}
                        </span>
                        <div>
                          <Link href={`/admin/modules/${mod.id}`}
                            className="font-semibold text-gray-900 hover:text-blue-600">
                            {mod.title}
                          </Link>
                          {mod.description && (
                            <p className="mt-0.5 line-clamp-1 text-xs text-gray-400">{mod.description}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-400">{mod.lessonCount} bài học</span>
                        <Link href={`/admin/modules/${mod.id}`}
                          className="rounded-lg bg-gray-100 px-3 py-1 text-xs font-medium text-gray-700 hover:bg-gray-200">
                          Quản lý
                        </Link>
                        <button onClick={() => startEditModule(mod)}
                          className="rounded-lg bg-blue-50 px-3 py-1 text-xs font-medium text-blue-600 hover:bg-blue-100">
                          Sửa
                        </button>
                        <button onClick={() => handleRemoveModuleFromLevel(mod.id, mod.title, mod.orderIndex)}
                          className="rounded-lg bg-yellow-50 px-3 py-1 text-xs font-medium text-yellow-700 hover:bg-yellow-100">
                          Gỡ khỏi level
                        </button>
                        <button onClick={() => handleDeleteModule(mod.id, mod.title)}
                          className="rounded-lg bg-red-50 px-3 py-1 text-xs font-medium text-red-600 hover:bg-red-100">
                          Xóa
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Module Modal */}
      {showAddModule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
            <h2 className="mb-4 text-lg font-semibold">Thêm module vào level</h2>
            <form onSubmit={handleAddModule} className="space-y-4">
              <div>
                <label className={labelCls}>Tên module <span className="text-red-500">*</span></label>
                <input required value={moduleForm.title}
                  onChange={(e) => setModuleForm({ ...moduleForm, title: e.target.value })}
                  className={inputCls}
                  placeholder="VD: Bài 1 – Phát âm cơ bản" />
              </div>
              <div>
                <label className={labelCls}>Mô tả</label>
                <textarea value={moduleForm.description}
                  onChange={(e) => setModuleForm({ ...moduleForm, description: e.target.value })}
                  rows={2} className={inputCls}
                  placeholder="Mục tiêu của module này..." />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={() => setShowAddModule(false)}
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">
                  Hủy
                </button>
                <button type="submit" disabled={creatingModule}
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">
                  {creatingModule ? "Đang thêm..." : "Thêm module"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
