using MediatR;
using Microsoft.EntityFrameworkCore;
using MLS.Application.Common.Interfaces;
using MLS.Domain.Entities;

namespace MLS.Application.Learning.Queries;

// ── DTOs ──────────────────────────────────────────────────────────────────────

public record PublicCourseListItem(
    Guid Id,
    string Title,
    string? Description,
    string? ShortDescription,
    int Level,
    string? ThumbnailUrl,
    string? Slug,
    int ModuleCount,
    int LessonCount,
    bool IsEnrolled,
    bool IsFree,
    decimal Price,
    decimal? DiscountPrice);

public record PublicCoursesResult(
    IReadOnlyList<PublicCourseListItem> Items,
    int Total,
    int Page,
    int PageSize);

public record PublicLessonItem(
    Guid Id,
    string Title,
    string? Description,
    int OrderIndex,
    bool IsFreeTrial,
    bool IsLocked,
    string? VideoStatus,
    int DurationSeconds,
    bool IsCompleted = false);

public record PublicModuleItem(
    Guid Id,
    string Title,
    string? Description,
    int OrderIndex,
    IReadOnlyList<PublicLessonItem> Lessons);

public record PublicCourseDetail(
    Guid Id,
    string Title,
    string? Description,
    string? ShortDescription,
    int Level,
    string? ThumbnailUrl,
    string? BannerUrl,
    string? Slug,
    string? TeacherName,
    DateTime? PublishedAt,
    bool IsEnrolled,
    bool IsFree,
    bool CertificateEnabled,
    IReadOnlyList<PublicModuleItem> Modules,
    decimal Price,
    decimal? DiscountPrice,
    DateTime? DiscountEndsAt);

public record LessonViewDto(
    Guid Id,
    string Title,
    string? Description,
    bool IsFreeTrial,
    int PassScore,
    bool IsLocked,
    string? VideoHlsPath,
    string? VideoStatus,
    int VideoDurationSeconds,
    string? VideoThumbnailUrl,
    IReadOnlyList<LessonDocumentPublicDto> Documents,
    LessonProgressDto? Progress,
    Guid? PrevLessonId,
    Guid? NextLessonId,
    Guid CourseId);

public record LessonDocumentPublicDto(Guid Id, string Title, string Type, long SizeBytes);
public record LessonProgressDto(string Status, int? Score, DateTime? CompletedAt);

// ── Queries ───────────────────────────────────────────────────────────────────

public record GetPublicCoursesQuery(
    int Page = 1,
    int PageSize = 12,
    int? Level = null,
    string? Search = null,
    Guid? CurrentUserId = null) : IRequest<PublicCoursesResult>;

public record GetPublicCourseDetailQuery(
    Guid CourseId,
    Guid? CurrentUserId = null) : IRequest<PublicCourseDetail?>;

public record GetPublicLessonQuery(
    Guid LessonId,
    Guid? CurrentUserId) : IRequest<LessonViewDto?>;

public record LearningStreakDto(
    int CurrentStreak,
    int LongestStreak,
    int TotalDaysLearned,
    DateTime? LastLearningDate,
    bool LearnedToday);

public record GetLearningStreakQuery(Guid UserId) : IRequest<LearningStreakDto>;

// ── Handlers ─────────────────────────────────────────────────────────────────

public class GetPublicCoursesHandler(IApplicationDbContext db)
    : IRequestHandler<GetPublicCoursesQuery, PublicCoursesResult>
{
    public async Task<PublicCoursesResult> Handle(GetPublicCoursesQuery q, CancellationToken ct)
    {
        var query = db.Courses.AsNoTracking()
            .Where(c => c.Status == CourseStatus.Published && c.Visibility == CourseVisibility.Public);

        if (q.Level.HasValue)
            query = query.Where(c => c.Level == q.Level.Value);

        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.ToLower();
            query = query.Where(c => c.Title.ToLower().Contains(s) || (c.Description != null && c.Description.ToLower().Contains(s)));
        }

        var total = await query.CountAsync(ct);

        var courses = await query
            .OrderBy(c => c.Level).ThenBy(c => c.CreatedAt)
            .Skip((q.Page - 1) * q.PageSize)
            .Take(q.PageSize)
            .Select(c => new
            {
                c.Id, c.Title, c.Description, c.ShortDescription, c.Level, c.ThumbnailUrl, c.Slug,
                c.Price, c.DiscountPrice, c.IsFree,
                ModuleCount = c.Modules.Count(),
                LessonCount = c.Modules.SelectMany(m => m.Lessons).Count(),
            })
            .ToListAsync(ct);

        // enrollment check
        HashSet<Guid> enrolledIds = [];
        if (q.CurrentUserId.HasValue)
        {
            var uid = q.CurrentUserId.Value;
            enrolledIds = (await db.CourseEnrollments.AsNoTracking()
                .Where(e => e.UserId == uid && courses.Select(c => c.Id).Contains(e.CourseId))
                .Select(e => e.CourseId)
                .ToListAsync(ct)).ToHashSet();
        }

        var items = courses.Select(c => new PublicCourseListItem(
            c.Id, c.Title, c.Description, c.ShortDescription, c.Level, c.ThumbnailUrl, c.Slug,
            c.ModuleCount, c.LessonCount,
            enrolledIds.Contains(c.Id),
            c.IsFree, c.Price, c.DiscountPrice)).ToList();

        return new PublicCoursesResult(items, total, q.Page, q.PageSize);
    }
}

public class GetPublicCourseDetailHandler(IApplicationDbContext db)
    : IRequestHandler<GetPublicCourseDetailQuery, PublicCourseDetail?>
{
    public async Task<PublicCourseDetail?> Handle(GetPublicCourseDetailQuery q, CancellationToken ct)
    {
        var course = await db.Courses.AsNoTracking()
            .Where(c => c.Id == q.CourseId && c.Status == CourseStatus.Published)
            .Select(c => new { c.Id, c.Title, c.Description, c.ShortDescription, c.Level, c.ThumbnailUrl, c.BannerUrl, c.Slug, c.TeacherId, c.PublishedAt, c.Price, c.DiscountPrice, c.DiscountEndsAt, c.IsFree, c.CertificateEnabled })
            .FirstOrDefaultAsync(ct);

        if (course == null) return null;

        var isEnrolled = false;
        if (q.CurrentUserId.HasValue)
        {
            isEnrolled = await db.CourseEnrollments.AsNoTracking()
                .AnyAsync(e => e.UserId == q.CurrentUserId && e.CourseId == q.CourseId, ct);
        }

        // Load completed lesson IDs for current user
        HashSet<Guid> completedLessonIds = [];
        if (q.CurrentUserId.HasValue)
        {
            completedLessonIds = (await db.LessonProgresses.AsNoTracking()
                .Where(p => p.UserId == q.CurrentUserId.Value
                    && p.Status == LessonProgressStatus.Completed)
                .Select(p => p.LessonId)
                .ToListAsync(ct)).ToHashSet();
        }

        // Build module+lesson tree
        var modules = await db.CourseModules.AsNoTracking()
            .Where(m => m.CourseId == q.CourseId)
            .OrderBy(m => m.OrderIndex)
            .Select(m => new
            {
                m.Id, m.Title, m.Description, m.OrderIndex,
                Lessons = m.Lessons.OrderBy(l => l.OrderIndex).Select(l => new
                {
                    l.Id, l.Title, l.Description, l.OrderIndex, l.IsFreeTrial,
                    VideoStatus = l.VideoAsset != null ? l.VideoAsset.Status.ToString() : null,
                    DurationSeconds = l.VideoAsset != null ? l.VideoAsset.DurationSeconds : 0,
                }).ToList(),
            })
            .ToListAsync(ct);

        // All lessons in order for lock logic
        int lessonIndex = 0;
        var moduleItems = modules.Select(m =>
        {
            var lessons = m.Lessons.Select(l =>
            {
                bool isLocked = !isEnrolled && !l.IsFreeTrial && lessonIndex > 0;
                bool isCompleted = completedLessonIds.Contains(l.Id);
                lessonIndex++;
                return new PublicLessonItem(
                    l.Id, l.Title, l.Description, l.OrderIndex,
                    l.IsFreeTrial, isLocked, l.VideoStatus, l.DurationSeconds, isCompleted);
            }).ToList();

            return new PublicModuleItem(m.Id, m.Title, m.Description, m.OrderIndex, lessons);
        }).ToList();

        return new PublicCourseDetail(
            course.Id, course.Title, course.Description, course.ShortDescription, course.Level,
            course.ThumbnailUrl, course.BannerUrl, course.Slug, null, course.PublishedAt, isEnrolled,
            course.IsFree, course.CertificateEnabled, moduleItems,
            course.Price, course.DiscountPrice, course.DiscountEndsAt);
    }
}

public class GetPublicLessonHandler(IApplicationDbContext db)
    : IRequestHandler<GetPublicLessonQuery, LessonViewDto?>
{
    public async Task<LessonViewDto?> Handle(GetPublicLessonQuery q, CancellationToken ct)
    {
        var lesson = await db.Lessons.AsNoTracking()
            .Where(l => l.Id == q.LessonId)
            .Select(l => new
            {
                l.Id, l.Title, l.Description, l.IsFreeTrial, l.PassScore, l.ModuleId,
                l.OrderIndex,
                Video = l.VideoAsset == null ? null : new
                {
                    l.VideoAsset.HlsPath,
                    Status = l.VideoAsset.Status.ToString(),
                    l.VideoAsset.DurationSeconds,
                    l.VideoAsset.ThumbnailUrl,
                },
                Documents = l.Documents.OrderBy(d => d.OrderIndex).Select(d => new
                {
                    d.Id, d.Title, d.Type, d.SizeBytes,
                }).ToList(),
                Module = new { l.Module.CourseId },
            })
            .FirstOrDefaultAsync(ct);

        if (lesson == null) return null;

        // Access control
        var isEnrolled = q.CurrentUserId.HasValue && await db.CourseEnrollments.AsNoTracking()
            .AnyAsync(e => e.UserId == q.CurrentUserId.Value && e.CourseId == lesson.Module.CourseId, ct);

        bool isLocked = !isEnrolled && !lesson.IsFreeTrial;

        // Progress
        var progress = q.CurrentUserId.HasValue
            ? await db.LessonProgresses.AsNoTracking()
                .Where(p => p.UserId == q.CurrentUserId.Value && p.LessonId == q.LessonId)
                .Select(p => new LessonProgressDto(p.Status.ToString(), p.Score, p.CompletedAt))
                .FirstOrDefaultAsync(ct)
            : null;

        // Prev / Next lessons in same module
        var siblings = await db.Lessons.AsNoTracking()
            .Where(l => l.ModuleId == lesson.ModuleId)
            .OrderBy(l => l.OrderIndex)
            .Select(l => l.Id)
            .ToListAsync(ct);

        var idx = siblings.IndexOf(q.LessonId);
        var prevId = idx > 0 ? siblings[idx - 1] : (Guid?)null;
        var nextId = idx < siblings.Count - 1 ? siblings[idx + 1] : (Guid?)null;

        var docs = lesson.Documents.Select(d =>
            new LessonDocumentPublicDto(d.Id, d.Title, d.Type.ToString(), d.SizeBytes)).ToList();

        return new LessonViewDto(
            lesson.Id, lesson.Title, lesson.Description,
            lesson.IsFreeTrial, lesson.PassScore, isLocked,
            lesson.Video?.HlsPath,       // always return path for preview on homepage
            lesson.Video?.Status,
            lesson.Video?.DurationSeconds ?? 0,
            lesson.Video?.ThumbnailUrl,
            docs, progress, prevId, nextId, lesson.Module.CourseId);
    }
}

// ── Learning Streak ───────────────────────────────────────────────────────────

public class GetLearningStreakHandler(IApplicationDbContext db)
    : IRequestHandler<GetLearningStreakQuery, LearningStreakDto>
{
    public async Task<LearningStreakDto> Handle(GetLearningStreakQuery q, CancellationToken ct)
    {
        // Get distinct UTC dates the user completed at least one lesson
        var learningDates = await db.LessonProgresses.AsNoTracking()
            .Where(p => p.UserId == q.UserId && p.CompletedAt != null)
            .Select(p => p.CompletedAt!.Value.Date)
            .Distinct()
            .OrderByDescending(d => d)
            .ToListAsync(ct);

        if (learningDates.Count == 0)
            return new LearningStreakDto(0, 0, 0, null, false);

        var today = DateTime.UtcNow.Date;
        var learnedToday = learningDates.Contains(today);

        // Current streak: consecutive days ending today or yesterday
        int currentStreak = 0;
        var checkDate = learnedToday ? today : today.AddDays(-1);
        foreach (var date in learningDates)
        {
            if (date == checkDate)
            {
                currentStreak++;
                checkDate = checkDate.AddDays(-1);
            }
            else if (date < checkDate) break;
        }

        // Longest streak
        int longestStreak = 0, tempStreak = 1;
        for (int i = 1; i < learningDates.Count; i++)
        {
            if ((learningDates[i - 1] - learningDates[i]).Days == 1)
            {
                tempStreak++;
                longestStreak = Math.Max(longestStreak, tempStreak);
            }
            else
            {
                longestStreak = Math.Max(longestStreak, tempStreak);
                tempStreak = 1;
            }
        }
        longestStreak = Math.Max(longestStreak, tempStreak);
        longestStreak = Math.Max(longestStreak, currentStreak);

        return new LearningStreakDto(
            currentStreak,
            longestStreak,
            learningDates.Count,
            learningDates.FirstOrDefault(),
            learnedToday);
    }
}
