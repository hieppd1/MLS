using Microsoft.EntityFrameworkCore;
using MLS.Domain.Entities;

namespace MLS.Application.Common.Interfaces;

public interface IApplicationDbContext
{
    DbSet<User> Users { get; }
    DbSet<UserProfile> UserProfiles { get; }
    DbSet<Role> Roles { get; }
    DbSet<UserRole> UserRoles { get; }
    DbSet<RefreshToken> RefreshTokens { get; }
    DbSet<OtpVerification> OtpVerifications { get; }

    // CMS
    DbSet<Course> Courses { get; }
    DbSet<CourseLevel> CourseLevels { get; }
    DbSet<LearningLevel> LearningLevels { get; }
    DbSet<CourseModule> CourseModules { get; }
    DbSet<Lesson> Lessons { get; }
    DbSet<VideoAsset> VideoAssets { get; }
    DbSet<LessonDocument> LessonDocuments { get; }
    DbSet<CourseEnrollment> CourseEnrollments { get; }
    DbSet<LessonProgress> LessonProgresses { get; }
    DbSet<VideoTracking> VideoTrackings { get; }

    // System config
    DbSet<BannerSlide> BannerSlides { get; }

    // Teacher marketplace
    DbSet<TeacherProfile> TeacherProfiles { get; }
    DbSet<TeacherFollower> TeacherFollowers { get; }

    // V4 Interactive Learning
    DbSet<Session> Sessions { get; }
    DbSet<SessionVideoAsset> SessionVideoAssets { get; }
    DbSet<Segment> Segments { get; }
    DbSet<LearningAsset> LearningAssets { get; }
    DbSet<SessionProgress> SessionProgresses { get; }
    DbSet<SegmentProgress> SegmentProgresses { get; }
    DbSet<LearningAssetInteraction> LearningAssetInteractions { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
