using MLS.Application.Common.Interfaces;
using MLS.Domain.Entities;
using MLS.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MLS.Infrastructure.Persistence;

/// <summary>
/// Main EF Core DbContext. Uses PostgreSQL search_path to isolate tenant schemas.
/// Each HTTP request gets its own DbContext instance (scoped), configured for the
/// current tenant's schema.
/// </summary>
public class ApplicationDbContext : DbContext, IApplicationDbContext
{
    private readonly ITenantContext _tenantContext;

    // ── DbSets ────────────────────────────────────────────────────────────────
    public DbSet<User> Users => Set<User>();
    public DbSet<UserProfile> UserProfiles => Set<UserProfile>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<OtpVerification> OtpVerifications => Set<OtpVerification>();
    public DbSet<Tenant> Tenants => Set<Tenant>();

    // CMS
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<CourseLevel> CourseLevels => Set<CourseLevel>();
    public DbSet<LearningLevel> LearningLevels => Set<LearningLevel>();
    public DbSet<CourseModule> CourseModules => Set<CourseModule>();
    public DbSet<Lesson> Lessons => Set<Lesson>();
    public DbSet<VideoAsset> VideoAssets => Set<VideoAsset>();
    public DbSet<LessonDocument> LessonDocuments => Set<LessonDocument>();
    public DbSet<CourseEnrollment> CourseEnrollments => Set<CourseEnrollment>();
    public DbSet<LessonProgress> LessonProgresses => Set<LessonProgress>();
    public DbSet<VideoTracking> VideoTrackings => Set<VideoTracking>();

    // System config
    public DbSet<BannerSlide> BannerSlides => Set<BannerSlide>();

    // Teacher marketplace
    public DbSet<TeacherProfile> TeacherProfiles => Set<TeacherProfile>();
    public DbSet<TeacherFollower> TeacherFollowers => Set<TeacherFollower>();

    // V4 Interactive Learning
    public DbSet<Session> Sessions => Set<Session>();
    public DbSet<SessionVideoAsset> SessionVideoAssets => Set<SessionVideoAsset>();
    public DbSet<Segment> Segments => Set<Segment>();
    public DbSet<LearningAsset> LearningAssets => Set<LearningAsset>();
    public DbSet<SessionProgress> SessionProgresses => Set<SessionProgress>();
    public DbSet<SegmentProgress> SegmentProgresses => Set<SegmentProgress>();
    public DbSet<LearningAssetInteraction> LearningAssetInteractions => Set<LearningAssetInteraction>();

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, ITenantContext tenantContext)
        : base(options)
    {
        _tenantContext = tenantContext;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // Set the PostgreSQL search_path to the tenant's schema so all queries
        // are automatically scoped. Falls back to "public" during migrations.
        if (_tenantContext.IsResolved)
        {
            optionsBuilder.UseNpgsql(o => o.SetPostgresVersion(14, 0));
        }

        base.OnConfiguring(optionsBuilder);
    }

    /// <summary>
    /// Override to inject SET search_path before every connection is used.
    /// This is the actual tenant isolation mechanism.
    /// </summary>
    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        // Auto-set timestamps for all BaseEntity entries
        var now = DateTime.UtcNow;
        foreach (var entry in ChangeTracker.Entries<MLS.Domain.Common.BaseEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                if (entry.Entity.CreatedAt == default)
                    entry.Property(nameof(MLS.Domain.Common.BaseEntity.CreatedAt)).CurrentValue = now;
                entry.Property(nameof(MLS.Domain.Common.BaseEntity.UpdatedAt)).CurrentValue = now;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Property(nameof(MLS.Domain.Common.BaseEntity.UpdatedAt)).CurrentValue = now;
            }
        }

        await SetSearchPathAsync(cancellationToken);
        return await base.SaveChangesAsync(cancellationToken);
    }

    public async Task SetSearchPathAsync(CancellationToken ct = default)
    {
        if (!_tenantContext.IsResolved) return;
        // Schema name is validated to contain only alphanumeric+underscore chars (enforced by TenantContext).
        // PostgreSQL does not support parameterized identifiers in SET statements, so we format manually.
        var schema = _tenantContext.SchemaName;
        // Validate schema name is safe before interpolating (only lowercase letters, digits, underscores)
        if (!System.Text.RegularExpressions.Regex.IsMatch(schema, @"^[a-z0-9_]+$"))
            throw new InvalidOperationException($"Invalid schema name: {schema}");
#pragma warning disable EF1002 // SET search_path cannot use parameters; schema validated above
        await Database.ExecuteSqlRawAsync($"SET search_path TO {schema}, public", ct);
#pragma warning restore EF1002
    }
}
