using MediatR;
using Microsoft.EntityFrameworkCore;
using MLS.Application.Common.Interfaces;
using MLS.Domain.Common;
using MLS.Domain.Entities;

namespace MLS.Application.CMS.Courses.Commands;

// ── Course ────────────────────────────────────────────────────────────────────

public record CreateCourseCommand(
    string Title,
    string? Description,
    int Level,
    Guid? TeacherId,
    Guid CreatedBy,
    decimal Price = 0,
    decimal? DiscountPrice = null,
    DateTime? DiscountEndsAt = null,
    string? ShortDescription = null,
    bool IsFree = false,
    bool CertificateEnabled = false,
    string Visibility = "Public",
    string? Code = null,
    string? Language = "VI",
    string? ThumbnailUrl = null,
    string? BannerUrl = null,
    string? Tags = null,
    int? Duration = null,
    DateTime? StartDate = null,
    DateTime? EndDate = null,
    bool CompletionRequired = false
) : IRequest<Guid>;

public class CreateCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CreateCourseCommand, Guid>
{
    public async Task<Guid> Handle(CreateCourseCommand request, CancellationToken ct)
    {
        var visibility = Enum.TryParse<CourseVisibility>(request.Visibility, out var v) ? v : CourseVisibility.Public;
        var course = Course.Create(request.Title, request.Description, request.Level, request.CreatedBy, request.TeacherId,
            request.Price, request.DiscountPrice, request.DiscountEndsAt,
            request.ShortDescription, request.IsFree, request.CertificateEnabled, visibility,
            request.Code, request.Language, request.BannerUrl, request.Tags,
            request.Duration, request.StartDate, request.EndDate, request.CompletionRequired);
        if (request.ThumbnailUrl != null) course.SetThumbnail(request.ThumbnailUrl);
        db.Courses.Add(course);
        await db.SaveChangesAsync(ct);
        return course.Id;
    }
}

public record UpdateCourseCommand(
    Guid CourseId,
    string Title,
    string? Description,
    int Level,
    Guid? TeacherId,
    decimal Price = 0,
    decimal? DiscountPrice = null,
    DateTime? DiscountEndsAt = null,
    string? ShortDescription = null,
    bool IsFree = false,
    bool CertificateEnabled = false,
    string Visibility = "Public",
    string? ThumbnailUrl = null,
    string? BannerUrl = null,
    string? Language = null,
    string? Tags = null,
    int? Duration = null,
    DateTime? StartDate = null,
    DateTime? EndDate = null,
    bool CompletionRequired = false,
    string? Code = null
) : IRequest;

public class UpdateCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<UpdateCourseCommand>
{
    public async Task Handle(UpdateCourseCommand request, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);
        var visibility = Enum.TryParse<CourseVisibility>(request.Visibility, out var v) ? v : CourseVisibility.Public;
        course.Update(request.Title, request.Description, request.Level, request.TeacherId,
            request.Price, request.DiscountPrice, request.DiscountEndsAt,
            request.ShortDescription, request.IsFree, request.CertificateEnabled, visibility,
            request.ThumbnailUrl, request.BannerUrl, request.Language,
            request.Tags, request.Duration, request.StartDate, request.EndDate, request.CompletionRequired,
            request.Code);
        await db.SaveChangesAsync(ct);
    }
}

public record DeleteCourseCommand(Guid CourseId) : IRequest;

public class DeleteCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<DeleteCourseCommand>
{
    public async Task Handle(DeleteCourseCommand request, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);
        db.Courses.Remove(course);
        await db.SaveChangesAsync(ct);
    }
}

public record PublishCourseCommand(Guid CourseId, bool Approve) : IRequest;

public class PublishCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<PublishCourseCommand>
{
    public async Task Handle(PublishCourseCommand request, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);
        if (request.Approve) course.Publish();
        else course.Reject();
        await db.SaveChangesAsync(ct);
    }
}

public record HideCourseCommand(Guid CourseId) : IRequest;

public class HideCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<HideCourseCommand>
{
    public async Task Handle(HideCourseCommand request, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);
        course.Hide();
        await db.SaveChangesAsync(ct);
    }
}

public record ArchiveCourseCommand(Guid CourseId) : IRequest;

public class ArchiveCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<ArchiveCourseCommand>
{
    public async Task Handle(ArchiveCourseCommand request, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);
        course.Archive();
        await db.SaveChangesAsync(ct);
    }
}

public record CloneCourseCommand(Guid CourseId, Guid CreatedBy) : IRequest<Guid>;

public class CloneCourseCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CloneCourseCommand, Guid>
{
    public async Task<Guid> Handle(CloneCourseCommand request, CancellationToken ct)
    {
        var original = await db.Courses
            .Include(c => c.Modules.OrderBy(m => m.OrderIndex))
                .ThenInclude(m => m.Lessons.OrderBy(l => l.OrderIndex))
            .FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);

        var clone = original.CloneAs(request.CreatedBy);
        db.Courses.Add(clone);
        await db.SaveChangesAsync(ct);
        return clone.Id;
    }
}

// ── Module ────────────────────────────────────────────────────────────────────

public record CreateModuleCommand(
    Guid CourseId,
    string Title,
    string? Description,
    Guid? LevelId = null,
    string? ThumbnailUrl = null,
    int EstimatedDuration = 0
) : IRequest<Guid>;

public class CreateModuleCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CreateModuleCommand, Guid>
{
    public async Task<Guid> Handle(CreateModuleCommand request, CancellationToken ct)
    {
        // Auto-determine next OrderIndex
        var maxOrder = await db.CourseModules
            .Where(m => m.CourseId == request.CourseId)
            .Select(m => (int?)m.OrderIndex)
            .MaxAsync(ct) ?? -1;

        var module = CourseModule.Create(request.CourseId, request.Title, request.Description, maxOrder + 1, request.LevelId);
        if (request.ThumbnailUrl != null || request.EstimatedDuration > 0)
            module.Update(request.Title, request.Description, maxOrder + 1, false, request.LevelId, request.ThumbnailUrl, request.EstimatedDuration);
        db.CourseModules.Add(module);
        await db.SaveChangesAsync(ct);
        return module.Id;
    }
}

public record UpdateModuleCommand(
    Guid ModuleId,
    string Title,
    string? Description,
    int OrderIndex,
    bool IsLocked = false,
    Guid? LevelId = null,
    string? ThumbnailUrl = null,
    int EstimatedDuration = 0
) : IRequest;

public class UpdateModuleCommandHandler(IApplicationDbContext db)
    : IRequestHandler<UpdateModuleCommand>
{
    public async Task Handle(UpdateModuleCommand request, CancellationToken ct)
    {
        var module = await db.CourseModules.FirstOrDefaultAsync(m => m.Id == request.ModuleId, ct)
            ?? throw new NotFoundException("CourseModule", request.ModuleId);
        module.Update(request.Title, request.Description, request.OrderIndex, request.IsLocked, request.LevelId, request.ThumbnailUrl, request.EstimatedDuration);
        await db.SaveChangesAsync(ct);
    }
}

public record DeleteModuleCommand(Guid ModuleId) : IRequest;

public class DeleteModuleCommandHandler(IApplicationDbContext db)
    : IRequestHandler<DeleteModuleCommand>
{
    public async Task Handle(DeleteModuleCommand request, CancellationToken ct)
    {
        var module = await db.CourseModules.FirstOrDefaultAsync(m => m.Id == request.ModuleId, ct)
            ?? throw new NotFoundException("CourseModule", request.ModuleId);
        db.CourseModules.Remove(module);
        await db.SaveChangesAsync(ct);
    }
}

// ── Lesson ────────────────────────────────────────────────────────────────────

public record CreateLessonCommand(
    Guid ModuleId,
    string Title,
    string? Description,
    bool IsFreeTrial,
    string? LessonType = null,
    string? Content = null,
    int DurationMinutes = 0,
    int PassScore = 0
) : IRequest<Guid>;

public class CreateLessonCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CreateLessonCommand, Guid>
{
    public async Task<Guid> Handle(CreateLessonCommand request, CancellationToken ct)
    {
        var maxOrder = await db.Lessons
            .Where(l => l.ModuleId == request.ModuleId)
            .Select(l => (int?)l.OrderIndex)
            .MaxAsync(ct) ?? -1;

        var lessonType = Enum.TryParse<LessonType>(request.LessonType, out var lt) ? lt : LessonType.Video;
        var lesson = Lesson.CreateWithType(request.ModuleId, request.Title, request.Description, maxOrder + 1, request.IsFreeTrial, lessonType, request.Content);
        if (request.DurationMinutes > 0 || request.PassScore > 0)
            lesson.Update(request.Title, request.Description, maxOrder + 1, request.IsFreeTrial, request.PassScore,
                lessonType, request.Content, durationMinutes: request.DurationMinutes);
        db.Lessons.Add(lesson);
        await db.SaveChangesAsync(ct);
        return lesson.Id;
    }
}

public record UpdateLessonCommand(
    Guid LessonId,
    string Title,
    string? Description,
    int OrderIndex,
    bool IsFreeTrial,
    int PassScore,
    string? LessonType = null,
    string? Content = null,
    string? ThumbnailUrl = null,
    string? AudioUrl = null,
    string? DocumentUrl = null,
    string? Transcript = null,
    int DurationMinutes = 0,
    string? PublishStatus = null
) : IRequest;

public class UpdateLessonCommandHandler(IApplicationDbContext db)
    : IRequestHandler<UpdateLessonCommand>
{
    public async Task Handle(UpdateLessonCommand request, CancellationToken ct)
    {
        var lesson = await db.Lessons.FirstOrDefaultAsync(l => l.Id == request.LessonId, ct)
            ?? throw new NotFoundException("Lesson", request.LessonId);
        var lessonType = Enum.TryParse<LessonType>(request.LessonType, out var lt) ? lt : (LessonType?)null;
        var publishStatus = Enum.TryParse<LessonPublishStatus>(request.PublishStatus, out var ps) ? ps : (LessonPublishStatus?)null;
        lesson.Update(request.Title, request.Description, request.OrderIndex, request.IsFreeTrial, request.PassScore,
            lessonType, request.Content, request.ThumbnailUrl, request.AudioUrl, request.DocumentUrl,
            request.Transcript, request.DurationMinutes, publishStatus);
        await db.SaveChangesAsync(ct);
    }
}

public record DeleteLessonCommand(Guid LessonId) : IRequest;

public class DeleteLessonCommandHandler(IApplicationDbContext db)
    : IRequestHandler<DeleteLessonCommand>
{
    public async Task Handle(DeleteLessonCommand request, CancellationToken ct)
    {
        var lesson = await db.Lessons.FirstOrDefaultAsync(l => l.Id == request.LessonId, ct)
            ?? throw new NotFoundException("Lesson", request.LessonId);
        db.Lessons.Remove(lesson);
        await db.SaveChangesAsync(ct);
    }
}

// ── Level ─────────────────────────────────────────────────────────────────────

public record CreateLevelCommand(Guid CourseId, string Name, string? Description) : IRequest<Guid>;

public class CreateLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CreateLevelCommand, Guid>
{
    public async Task<Guid> Handle(CreateLevelCommand request, CancellationToken ct)
    {
        var maxOrder = await db.CourseLevels
            .Where(lv => lv.CourseId == request.CourseId)
            .Select(lv => (int?)lv.OrderIndex)
            .MaxAsync(ct) ?? -1;

        var level = CourseLevel.Create(request.CourseId, request.Name, request.Description, maxOrder + 1);
        db.CourseLevels.Add(level);
        await db.SaveChangesAsync(ct);
        return level.Id;
    }
}

public record UpdateLevelCommand(Guid LevelId, string Name, string? Description, int OrderIndex) : IRequest;

public class UpdateLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<UpdateLevelCommand>
{
    public async Task Handle(UpdateLevelCommand request, CancellationToken ct)
    {
        var level = await db.CourseLevels.FirstOrDefaultAsync(lv => lv.Id == request.LevelId, ct)
            ?? throw new NotFoundException("CourseLevel", request.LevelId);
        level.Update(request.Name, request.Description, request.OrderIndex);
        await db.SaveChangesAsync(ct);
    }
}

public record PublishLevelCommand(Guid LevelId, bool Publish) : IRequest;

public class PublishLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<PublishLevelCommand>
{
    public async Task Handle(PublishLevelCommand request, CancellationToken ct)
    {
        var level = await db.CourseLevels.FirstOrDefaultAsync(lv => lv.Id == request.LevelId, ct)
            ?? throw new NotFoundException("CourseLevel", request.LevelId);
        if (request.Publish) level.Publish(); else level.Unpublish();
        await db.SaveChangesAsync(ct);
    }
}

public record DeleteLevelCommand(Guid LevelId) : IRequest;

public class DeleteLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<DeleteLevelCommand>
{
    public async Task Handle(DeleteLevelCommand request, CancellationToken ct)
    {
        var level = await db.CourseLevels.FirstOrDefaultAsync(lv => lv.Id == request.LevelId, ct)
            ?? throw new NotFoundException("CourseLevel", request.LevelId);
        var modules = await db.CourseModules.Where(m => m.LevelId == request.LevelId).ToListAsync(ct);
        foreach (var m in modules)
            m.Update(m.Title, m.Description, m.OrderIndex, m.IsLocked, null);
        db.CourseLevels.Remove(level);
        await db.SaveChangesAsync(ct);
    }
}

// ── Content Approval Workflow ─────────────────────────────────────────────────

public record SubmitForReviewCommand(Guid CourseId) : IRequest;

public class SubmitForReviewCommandHandler(IApplicationDbContext db)
    : IRequestHandler<SubmitForReviewCommand>
{
    public async Task Handle(SubmitForReviewCommand request, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);
        course.SubmitForReview();
        await db.SaveChangesAsync(ct);
    }
}

// ── Learning Level (global config) ──────────────────────────────────────────

public record CreateLearningLevelCommand(string Name, string? Description, int OrderIndex) : IRequest<Guid>;

public class CreateLearningLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CreateLearningLevelCommand, Guid>
{
    public async Task<Guid> Handle(CreateLearningLevelCommand request, CancellationToken ct)
    {
        var level = LearningLevel.Create(request.Name, request.Description, request.OrderIndex);
        db.LearningLevels.Add(level);
        await db.SaveChangesAsync(ct);
        return level.Id;
    }
}

public record UpdateLearningLevelCommand(Guid Id, string Name, string? Description, int OrderIndex) : IRequest;

public class UpdateLearningLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<UpdateLearningLevelCommand>
{
    public async Task Handle(UpdateLearningLevelCommand request, CancellationToken ct)
    {
        var level = await db.LearningLevels.FirstOrDefaultAsync(l => l.Id == request.Id, ct)
            ?? throw new NotFoundException("LearningLevel", request.Id);
        level.Update(request.Name, request.Description, request.OrderIndex);
        await db.SaveChangesAsync(ct);
    }
}

public record SetLearningLevelActiveCommand(Guid Id, bool IsActive) : IRequest;

public class SetLearningLevelActiveCommandHandler(IApplicationDbContext db)
    : IRequestHandler<SetLearningLevelActiveCommand>
{
    public async Task Handle(SetLearningLevelActiveCommand request, CancellationToken ct)
    {
        var level = await db.LearningLevels.FirstOrDefaultAsync(l => l.Id == request.Id, ct)
            ?? throw new NotFoundException("LearningLevel", request.Id);
        level.SetActive(request.IsActive);
        await db.SaveChangesAsync(ct);
    }
}

public record DeleteLearningLevelCommand(Guid Id) : IRequest;

public class DeleteLearningLevelCommandHandler(IApplicationDbContext db)
    : IRequestHandler<DeleteLearningLevelCommand>
{
    public async Task Handle(DeleteLearningLevelCommand request, CancellationToken ct)
    {
        var level = await db.LearningLevels.FirstOrDefaultAsync(l => l.Id == request.Id, ct)
            ?? throw new NotFoundException("LearningLevel", request.Id);
        db.LearningLevels.Remove(level);
        await db.SaveChangesAsync(ct);
    }
}

// ── Video Upload ──────────────────────────────────────────────────────────────

public record CreateVideoAssetCommand(
    Guid LessonId,
    string OriginalFileName,
    long SizeBytes,
    Stream FileStream,
    string ContentType,
    string TenantSlug) : IRequest<Guid>;

public class CreateVideoAssetCommandHandler(
    IApplicationDbContext db,
    MLS.Domain.Interfaces.IStorageService storage)
    : IRequestHandler<CreateVideoAssetCommand, Guid>
{
    public async Task<Guid> Handle(CreateVideoAssetCommand request, CancellationToken ct)
    {
        // Reuse existing record if present — avoids UNIQUE constraint violation on LessonId
        var asset = await db.VideoAssets.FirstOrDefaultAsync(v => v.LessonId == request.LessonId, ct);
        if (asset == null)
        {
            asset = VideoAsset.Create(request.LessonId, request.OriginalFileName, request.SizeBytes);
            db.VideoAssets.Add(asset);
        }
        else
        {
            asset.Reset(request.OriginalFileName, request.SizeBytes);
        }

        var safeFileName = $"{asset.Id}{Path.GetExtension(request.OriginalFileName)}";
        var storedPath = await storage.UploadAsync(
            request.TenantSlug, "videos", safeFileName, request.FileStream, request.ContentType, ct);

        asset.SetReady(storedPath, null, 0);
        await db.SaveChangesAsync(ct);
        return asset.Id;
    }
}

// ── Lesson Document Upload ────────────────────────────────────────────────────

public record AddLessonDocumentCommand(
    Guid LessonId,
    string Title,
    string DocumentType,
    string OriginalFileName,
    long SizeBytes,
    Stream FileStream,
    string ContentType,
    bool IsProtected,
    string TenantSlug) : IRequest<Guid>;

public class AddLessonDocumentCommandHandler(
    IApplicationDbContext db,
    MLS.Domain.Interfaces.IStorageService storage)
    : IRequestHandler<AddLessonDocumentCommand, Guid>
{
    public async Task<Guid> Handle(AddLessonDocumentCommand request, CancellationToken ct)
    {
        if (!await db.Lessons.AnyAsync(l => l.Id == request.LessonId, ct))
            throw new KeyNotFoundException($"Lesson {request.LessonId} not found.");

        if (!Enum.TryParse<DocumentType>(request.DocumentType, ignoreCase: true, out var docType))
            docType = DocumentType.PDF;

        var orderIndex = await db.LessonDocuments
            .Where(d => d.LessonId == request.LessonId)
            .CountAsync(ct);

        // Pre-generate file ID so we can name the file consistently
        var fileId = Guid.NewGuid();
        var safeFileName = $"{fileId}{Path.GetExtension(request.OriginalFileName)}";
        var storedPath = await storage.UploadAsync(
            request.TenantSlug, "documents", safeFileName, request.FileStream, request.ContentType, ct);

        var doc = LessonDocument.Create(
            request.LessonId, docType, request.Title,
            storedPath, request.SizeBytes, request.IsProtected, orderIndex);

        db.LessonDocuments.Add(doc);
        await db.SaveChangesAsync(ct);
        return doc.Id;
    }
}

public record DeleteLessonDocumentCommand(Guid DocumentId) : IRequest;

public class DeleteLessonDocumentCommandHandler(
    IApplicationDbContext db,
    MLS.Domain.Interfaces.IStorageService storage)
    : IRequestHandler<DeleteLessonDocumentCommand>
{
    public async Task Handle(DeleteLessonDocumentCommand request, CancellationToken ct)
    {
        var doc = await db.LessonDocuments.FindAsync([request.DocumentId], ct)
            ?? throw new KeyNotFoundException($"Document {request.DocumentId} not found.");

        if (!string.IsNullOrEmpty(doc.FileUrl))
            await storage.DeleteAsync(doc.FileUrl, ct);

        db.LessonDocuments.Remove(doc);
        await db.SaveChangesAsync(ct);
    }
}
