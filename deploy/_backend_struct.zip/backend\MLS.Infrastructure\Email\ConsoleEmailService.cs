using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MLS.Domain.Interfaces;

namespace MLS.Infrastructure.Email;

/// <summary>
/// Stub email service — logs emails to console in development.
/// Replace with SendGrid implementation before production.
/// Set Email:Provider = "SendGrid" and Email:SendGridApiKey in appsettings.
/// </summary>
public class ConsoleEmailService(
    IConfiguration configuration,
    ILogger<ConsoleEmailService> logger) : IEmailService
{
    private readonly string _fromEmail = configuration["Email:From"] ?? "noreply@mls.app";
    private readonly string _appName = configuration["Email:AppName"] ?? "MLS";
    private readonly string _frontendUrl = configuration["Frontend:BaseUrl"] ?? "http://localhost:3000";

    public Task SendPasswordResetAsync(string toEmail, string toName, string resetToken, CancellationToken ct = default)
    {
        var resetUrl = $"{_frontendUrl}/reset-password?token={Uri.EscapeDataString(resetToken)}";
        logger.LogInformation(
            "[EMAIL STUB] Password reset for {Email} — URL: {Url}",
            toEmail, resetUrl);
        return Task.CompletedTask;
    }

    public Task SendEmailVerificationAsync(string toEmail, string toName, string otp, CancellationToken ct = default)
    {
        logger.LogInformation(
            "[EMAIL STUB] Verification OTP for {Email} — Code: {Otp}",
            toEmail, otp);
        return Task.CompletedTask;
    }

    public Task SendWelcomeAsync(string toEmail, string toName, CancellationToken ct = default)
    {
        logger.LogInformation("[EMAIL STUB] Welcome email to {Email}", toEmail);
        return Task.CompletedTask;
    }

    public Task SendInvitationAsync(string toEmail, string inviterName, string tenantName, string inviteLink, CancellationToken ct = default)
    {
        logger.LogInformation(
            "[EMAIL STUB] Invitation for {Email} from {Inviter} ({Tenant}) — Link: {Link}",
            toEmail, inviterName, tenantName, inviteLink);
        return Task.CompletedTask;
    }
}
