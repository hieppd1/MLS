using MediatR;
using Microsoft.EntityFrameworkCore;
using MLS.Application.Common.Interfaces;
using MLS.Domain.Common;
using MLS.Domain.Entities;

namespace MLS.Application.CMS.LearningAssets.Commands;

// ── Create LearningAsset ──────────────────────────────────────────────────────

public record CreateLearningAssetCommand(
    Guid SegmentId,
    string Type,
    string Title,
    string? Description,
    int StartTime,
    int? EndTime = null,
    string Metadata = "{}",
    bool IsPublic = true
) : IRequest<Guid>;

public class CreateLearningAssetCommandHandler(IApplicationDbContext db)
    : IRequestHandler<CreateLearningAssetCommand, Guid>
{
    public async Task<Guid> Handle(CreateLearningAssetCommand request, CancellationToken ct)
    {
        if (!Enum.TryParse<LearningAssetType>(request.Type, out var assetType))
            throw new DomainException($"Unknown asset type: '{request.Type}'. " +
                $"Valid values: {string.Join(", ", Enum.GetNames<LearningAssetType>())}");

        // Validate startTime is within the owning segment's time range
        var segment = await db.Segments.FindAsync([request.SegmentId], ct)
            ?? throw new NotFoundException(nameof(Segment), request.SegmentId);

        if (request.StartTime < segment.StartTime || request.StartTime > segment.EndTime)
            throw new DomainException(
                $"Asset startTime ({request.StartTime}s) must be within segment " +
                $"[{segment.StartTime}–{segment.EndTime}s].");

        if (request.EndTime.HasValue && request.EndTime.Value > segment.EndTime)
            throw new DomainException(
                $"Asset endTime ({request.EndTime}s) must not exceed segment endTime ({segment.EndTime}s).");

        var orderIndex = await db.LearningAssets
            .Where(a => a.SegmentId == request.SegmentId)
            .CountAsync(ct);

        var asset = LearningAsset.Create(
            request.SegmentId, assetType, request.Title, request.Description,
            request.StartTime, request.EndTime, orderIndex, request.Metadata, request.IsPublic);

        db.LearningAssets.Add(asset);
        await db.SaveChangesAsync(ct);
        return asset.Id;
    }
}

// ── Update LearningAsset ──────────────────────────────────────────────────────

public record UpdateLearningAssetCommand(
    Guid AssetId,
    string Title,
    string? Description,
    int StartTime,
    int? EndTime,
    string Metadata,
    bool IsPublic
) : IRequest;

public class UpdateLearningAssetCommandHandler(IApplicationDbContext db)
    : IRequestHandler<UpdateLearningAssetCommand>
{
    public async Task Handle(UpdateLearningAssetCommand request, CancellationToken ct)
    {
        var asset = await db.LearningAssets
            .Include(a => a.Segment)
            .FirstOrDefaultAsync(a => a.Id == request.AssetId, ct)
            ?? throw new NotFoundException(nameof(LearningAsset), request.AssetId);

        var segment = asset.Segment;

        if (request.StartTime < segment.StartTime || request.StartTime > segment.EndTime)
            throw new DomainException(
                $"Asset startTime ({request.StartTime}s) must be within segment " +
                $"[{segment.StartTime}–{segment.EndTime}s].");

        if (request.EndTime.HasValue && request.EndTime.Value > segment.EndTime)
            throw new DomainException(
                $"Asset endTime ({request.EndTime}s) must not exceed segment endTime ({segment.EndTime}s).");

        asset.Update(request.Title, request.Description, request.StartTime, request.EndTime,
            request.Metadata, request.IsPublic);
        await db.SaveChangesAsync(ct);
    }
}

// ── Delete LearningAsset ──────────────────────────────────────────────────────

public record DeleteLearningAssetCommand(Guid AssetId) : IRequest;

public class DeleteLearningAssetCommandHandler(IApplicationDbContext db)
    : IRequestHandler<DeleteLearningAssetCommand>
{
    public async Task Handle(DeleteLearningAssetCommand request, CancellationToken ct)
    {
        var asset = await db.LearningAssets.FindAsync([request.AssetId], ct)
            ?? throw new NotFoundException(nameof(LearningAsset), request.AssetId);

        db.LearningAssets.Remove(asset);
        await db.SaveChangesAsync(ct);
    }
}

// ── Reorder LearningAssets ────────────────────────────────────────────────────

public record ReorderLearningAssetsCommand(Guid SegmentId, List<Guid> OrderedIds) : IRequest;

public class ReorderLearningAssetsCommandHandler(IApplicationDbContext db)
    : IRequestHandler<ReorderLearningAssetsCommand>
{
    public async Task Handle(ReorderLearningAssetsCommand request, CancellationToken ct)
    {
        var assets = await db.LearningAssets
            .Where(a => a.SegmentId == request.SegmentId)
            .ToListAsync(ct);

        for (var i = 0; i < request.OrderedIds.Count; i++)
        {
            var asset = assets.FirstOrDefault(a => a.Id == request.OrderedIds[i]);
            asset?.SetOrder(i);
        }

        await db.SaveChangesAsync(ct);
    }
}


