using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using MLS.Application.Common.Interfaces;
using MLS.Domain.Interfaces;
using MLS.Infrastructure.Auth;
using MLS.Infrastructure.Email;
using MLS.Infrastructure.Moodle;
using MLS.Infrastructure.MultiTenancy;
using MLS.Infrastructure.Persistence;
using MLS.Infrastructure.Storage;
using MLS.Infrastructure.Tenancy;

namespace MLS.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        // ── Multi-tenancy ────────────────────────────────────────────────────
        services.AddScoped<TenantContext>();
        services.AddScoped<ITenantContext>(sp => sp.GetRequiredService<TenantContext>());

        // ── Database ─────────────────────────────────────────────────────────
        var connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

        services.AddDbContext<ApplicationDbContext>((sp, options) =>
        {
            var tenant = sp.GetRequiredService<ITenantContext>();
            var connStr = tenant.IsResolved
                ? $"{connectionString};Search Path={tenant.SchemaName},public"
                : connectionString;
            options.UseNpgsql(connStr);
        });

        services.AddScoped<IApplicationDbContext>(sp =>
            sp.GetRequiredService<ApplicationDbContext>());

        services.AddScoped<TenantProvisioner>();

        // ── Auth services ─────────────────────────────────────────────────────
        services.AddScoped<IJwtService, JwtService>();
        services.AddScoped<IPasswordHasher, PasswordHasher>();
        services.AddScoped<IGoogleAuthService, GoogleAuthService>();

        // ── Email service ─────────────────────────────────────────────────────
        // Dev: logs to console. Prod: swap ConsoleEmailService → SendGridEmailService
        services.AddScoped<IEmailService, ConsoleEmailService>();

        // ── Moodle LMS sync ───────────────────────────────────────────────────
        // Enabled = false by default. Set Moodle:Enabled = true + supply a Token once Moodle is running.
        services.Configure<MoodleOptions>(configuration.GetSection(MoodleOptions.Section));
        services.AddHttpClient<IMoodleService, MoodleService>();

        // ── JWT Bearer authentication ─────────────────────────────────────────
        var jwtSecret = configuration["Jwt:Secret"]
            ?? throw new InvalidOperationException("Jwt:Secret is not configured.");

        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.MapInboundClaims = false; // Keep claim names as-is (prevent "role" → ClaimTypes.Role remapping)
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
                ValidateIssuer = true,
                ValidIssuer = configuration["Jwt:Issuer"] ?? "mls-api",
                ValidateAudience = true,
                ValidAudience = configuration["Jwt:Audience"] ?? "mls-clients",
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero,
                // Map "role" claim → ClaimTypes.Role so [Authorize(Roles=)] works
                RoleClaimType = "role",
                NameClaimType = "sub"
            };
        });

        services.AddAuthorizationBuilder()
            .AddPolicy("SuperAdmin", p => p.RequireRole("SuperAdmin"))
            .AddPolicy("Admin",      p => p.RequireRole("SuperAdmin", "Admin"))
            .AddPolicy("Teacher",    p => p.RequireRole("SuperAdmin", "Admin", "Teacher"))
            .AddPolicy("Staff",      p => p.RequireRole("SuperAdmin", "Admin", "ContentManager", "Support"))
            .AddPolicy("Enrolled",   p => p.RequireAuthenticatedUser());

        // ── Storage ───────────────────────────────────────────────────────────
        var mediaRoot = configuration["Storage:RootPath"]
            ?? Path.Combine(Directory.GetCurrentDirectory(), "media");

        services.AddSingleton<IStorageService>(new LocalFileStorageService(mediaRoot));

        return services;
    }
}
