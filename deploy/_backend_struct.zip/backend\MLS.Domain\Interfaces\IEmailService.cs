namespace MLS.Domain.Interfaces;

public interface IEmailService
{
    Task SendPasswordResetAsync(string toEmail, string toName, string resetToken, CancellationToken ct = default);
    Task SendEmailVerificationAsync(string toEmail, string toName, string otp, CancellationToken ct = default);
    Task SendWelcomeAsync(string toEmail, string toName, CancellationToken ct = default);
    Task SendInvitationAsync(string toEmail, string inviterName, string tenantName, string inviteLink, CancellationToken ct = default);
}
