using MediatR;
using Microsoft.EntityFrameworkCore;
using MLS.Application.Common.Interfaces;
using MLS.Domain.Common;
using MLS.Domain.Entities;

namespace MLS.Application.CMS.Courses.Queries;

// ── DTOs ─────────────────────────────────────────────────────────────────────

public record CourseListItemDto(
    Guid Id,
    string Title,
    string? Description,
    string? ShortDescription,
    int Level,
    string? ThumbnailUrl,
    string? Slug,
    string Status,
    string Visibility,
    bool IsFree,
    bool CertificateEnabled,
    int ModuleCount,
    int EnrollmentCount,
    DateTime CreatedAt,
    decimal Price,
    decimal? DiscountPrice,
    string? Code,
    string? Language,
    string? BannerUrl,
    string? Tags
);

public record CourseDetailDto(
    Guid Id,
    string Title,
    string? Description,
    string? ShortDescription,
    int Level,
    string? ThumbnailUrl,
    string? Slug,
    string Status,
    string Visibility,
    bool IsFree,
    bool CertificateEnabled,
    bool CompletionRequired,
    Guid? TeacherId,
    Guid CreatedBy,
    DateTime? PublishedAt,
    DateTime CreatedAt,
    List<CourseLevelDto> Levels,
    List<ModuleSummaryDto> Modules,
    decimal Price,
    decimal? DiscountPrice,
    DateTime? DiscountEndsAt,
    string? Code,
    string? Language,
    string? BannerUrl,
    string? Tags,
    int? Duration,
    DateTime? StartDate,
    DateTime? EndDate
);

public record ModuleSummaryDto(
    Guid Id,
    string Title,
    string? Description,
    int OrderIndex,
    int LessonCount,
    int SessionCount,
    Guid? LevelId
);

public record CourseLevelDto(
    Guid Id,
    Guid CourseId,
    string Name,
    string? Description,
    int OrderIndex,
    bool IsPublished,
    int ModuleCount,
    DateTime CreatedAt
);

public record LevelDetailDto(
    Guid Id,
    Guid CourseId,
    string Name,
    string? Description,
    int OrderIndex,
    bool IsPublished,
    DateTime CreatedAt,
    List<ModuleSummaryDto> Modules
);

public record ModuleDetailDto(
    Guid Id,
    Guid CourseId,
    string Title,
    string? Description,
    string? ThumbnailUrl,
    int EstimatedDuration,
    int OrderIndex,
    bool IsLocked,
    DateTime CreatedAt,
    List<LessonSummaryDto> Lessons
);

public record LessonSummaryDto(
    Guid Id,
    string Title,
    string? Description,
    int OrderIndex,
    bool IsFreeTrial,
    int PassScore,
    string LessonType,
    string? VideoStatus,
    int DocumentCount
);

public record LessonDetailDto(
    Guid Id,
    Guid ModuleId,
    string Title,
    string? Description,
    int OrderIndex,
    bool IsFreeTrial,
    int PassScore,
    string LessonType,
    string PublishStatus,
    string? Content,
    string? ThumbnailUrl,
    string? AudioUrl,
    string? DocumentUrl,
    string? Transcript,
    int DurationMinutes,
    VideoAssetDto? Video,
    List<LessonDocumentDto> Documents
);

public record VideoAssetDto(
    Guid Id,
    string Status,
    string? HlsPath,
    string? ThumbnailUrl,
    int DurationSeconds,
    long SizeBytes,
    string? OriginalFileName
);

public record LessonDocumentDto(
    Guid Id,
    string Type,
    string Title,
    string FileUrl,
    long SizeBytes,
    bool IsProtected,
    int OrderIndex
);

// ── List Courses ─────────────────────────────────────────────────────────────

public record GetCoursesQuery(
    int Page = 1,
    int PageSize = 20,
    string? Search = null,
    int? Level = null,
    string? Status = null
) : IRequest<PagedCoursesResult>;

public record PagedCoursesResult(List<CourseListItemDto> Items, int Total, int Page, int PageSize);

public class GetCoursesQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetCoursesQuery, PagedCoursesResult>
{
    public async Task<PagedCoursesResult> Handle(GetCoursesQuery request, CancellationToken ct)
    {
        var query = db.Courses.AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var s = request.Search.Trim().ToLower();
            query = query.Where(c => c.Title.ToLower().Contains(s));
        }

        if (request.Level.HasValue)
            query = query.Where(c => c.Level == request.Level.Value);

        if (!string.IsNullOrWhiteSpace(request.Status)
            && Enum.TryParse<CourseStatus>(request.Status, out var status))
            query = query.Where(c => c.Status == status);

        var total = await query.CountAsync(ct);

        var courses = await query
            .Include(c => c.Modules).ThenInclude(m => m.Lessons)
            .Include(c => c.Enrollments)
            .OrderByDescending(c => c.CreatedAt)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync(ct);

        var items = courses.Select(c => new CourseListItemDto(
            c.Id, c.Title, c.Description, c.ShortDescription, c.Level, c.ThumbnailUrl, c.Slug,
            c.Status.ToString(), c.Visibility.ToString(), c.IsFree, c.CertificateEnabled,
            c.Modules.Count,
            c.Enrollments.Count,
            c.CreatedAt,
            c.Price,
            c.DiscountPrice,
            c.Code, c.Language, c.BannerUrl, c.Tags
        )).ToList();

        return new PagedCoursesResult(items, total, request.Page, request.PageSize);
    }
}

// ── Get Course Detail ─────────────────────────────────────────────────────────

public record GetCourseDetailQuery(Guid CourseId) : IRequest<CourseDetailDto>;

public class GetCourseDetailQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetCourseDetailQuery, CourseDetailDto>
{
    public async Task<CourseDetailDto> Handle(GetCourseDetailQuery request, CancellationToken ct)
    {
        var course = await db.Courses
            .Include(c => c.Levels.OrderBy(lv => lv.OrderIndex))
            .Include(c => c.Modules.OrderBy(m => m.OrderIndex))
                .ThenInclude(m => m.Lessons.OrderBy(l => l.OrderIndex))
            .Include(c => c.Modules)
                .ThenInclude(m => m.Sessions)
            .FirstOrDefaultAsync(c => c.Id == request.CourseId, ct)
            ?? throw new NotFoundException("Course", request.CourseId);

        return new CourseDetailDto(
            course.Id, course.Title, course.Description, course.ShortDescription, course.Level,
            course.ThumbnailUrl, course.Slug, course.Status.ToString(), course.Visibility.ToString(),
            course.IsFree, course.CertificateEnabled, course.CompletionRequired,
            course.TeacherId, course.CreatedBy, course.PublishedAt, course.CreatedAt,
            course.Levels.Select(lv => new CourseLevelDto(
                lv.Id, lv.CourseId, lv.Name, lv.Description, lv.OrderIndex, lv.IsPublished,
                course.Modules.Count(m => m.LevelId == lv.Id),
                lv.CreatedAt
            )).ToList(),
            course.Modules.Select(m => new ModuleSummaryDto(
                m.Id, m.Title, m.Description, m.OrderIndex, m.Lessons.Count, m.Sessions.Count, m.LevelId
            )).ToList(),
            course.Price, course.DiscountPrice, course.DiscountEndsAt,
            course.Code, course.Language, course.BannerUrl, course.Tags,
            course.Duration, course.StartDate, course.EndDate
        );
    }
}

// ── Get Module Detail ─────────────────────────────────────────────────────────

public record GetModuleDetailQuery(Guid ModuleId) : IRequest<ModuleDetailDto>;

public class GetModuleDetailQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetModuleDetailQuery, ModuleDetailDto>
{
    public async Task<ModuleDetailDto> Handle(GetModuleDetailQuery request, CancellationToken ct)
    {
        var module = await db.CourseModules
            .Include(m => m.Lessons.OrderBy(l => l.OrderIndex))
                .ThenInclude(l => l.VideoAsset)
            .Include(m => m.Lessons)
                .ThenInclude(l => l.Documents)
            .FirstOrDefaultAsync(m => m.Id == request.ModuleId, ct)
            ?? throw new NotFoundException("CourseModule", request.ModuleId);

        return new ModuleDetailDto(
            module.Id, module.CourseId, module.Title, module.Description,
            module.ThumbnailUrl, module.EstimatedDuration,
            module.OrderIndex, module.IsLocked, module.CreatedAt,
            module.Lessons.Select(l => new LessonSummaryDto(
                l.Id, l.Title, l.Description, l.OrderIndex, l.IsFreeTrial, l.PassScore,
                l.LessonType.ToString(),
                l.VideoAsset?.Status.ToString(),
                l.Documents.Count
            )).ToList()
        );
    }
}

// ── Get Lesson Detail ─────────────────────────────────────────────────────────

public record GetLessonDetailQuery(Guid LessonId) : IRequest<LessonDetailDto>;

public class GetLessonDetailQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetLessonDetailQuery, LessonDetailDto>
{
    public async Task<LessonDetailDto> Handle(GetLessonDetailQuery request, CancellationToken ct)
    {
        var lesson = await db.Lessons
            .Include(l => l.VideoAsset)
            .Include(l => l.Documents.OrderBy(d => d.OrderIndex))
            .FirstOrDefaultAsync(l => l.Id == request.LessonId, ct)
            ?? throw new NotFoundException("Lesson", request.LessonId);

        return new LessonDetailDto(
            lesson.Id, lesson.ModuleId, lesson.Title, lesson.Description,
            lesson.OrderIndex, lesson.IsFreeTrial, lesson.PassScore,
            lesson.LessonType.ToString(), lesson.PublishStatus.ToString(),
            lesson.Content, lesson.ThumbnailUrl, lesson.AudioUrl, lesson.DocumentUrl,
            lesson.Transcript, lesson.DurationMinutes,
            lesson.VideoAsset == null ? null : new VideoAssetDto(
                lesson.VideoAsset.Id, lesson.VideoAsset.Status.ToString(),
                lesson.VideoAsset.HlsPath, lesson.VideoAsset.ThumbnailUrl,
                lesson.VideoAsset.DurationSeconds, lesson.VideoAsset.SizeBytes,
                lesson.VideoAsset.OriginalFileName
            ),
            lesson.Documents.Select(d => new LessonDocumentDto(
                d.Id, d.Type.ToString(), d.Title, d.FileUrl, d.SizeBytes, d.IsProtected, d.OrderIndex
            )).ToList()
        );
    }
}

// ── Content Approvals Queue ───────────────────────────────────────────────────

public record ApprovalQueueItem(
    Guid CourseId,
    string Title,
    int Level,
    string? ThumbnailUrl,
    Guid CreatedBy,
    DateTime CreatedAt,
    DateTime? UpdatedAt);

public record GetApprovalsQueueQuery : IRequest<IReadOnlyList<ApprovalQueueItem>>;

public class GetApprovalsQueueHandler(IApplicationDbContext db)
    : IRequestHandler<GetApprovalsQueueQuery, IReadOnlyList<ApprovalQueueItem>>
{
    public async Task<IReadOnlyList<ApprovalQueueItem>> Handle(GetApprovalsQueueQuery _, CancellationToken ct)
    {
        return await db.Courses.AsNoTracking()
            .Where(c => c.Status == CourseStatus.PendingReview)
            .OrderBy(c => c.UpdatedAt)
            .Select(c => new ApprovalQueueItem(
                c.Id, c.Title, c.Level, c.ThumbnailUrl,
                c.CreatedBy, c.CreatedAt, c.UpdatedAt))
            .ToListAsync(ct);
    }
}

// ── Get Course Levels ─────────────────────────────────────────────────────────

public record GetCourseLevelsQuery(Guid CourseId) : IRequest<List<CourseLevelDto>>;

public class GetCourseLevelsQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetCourseLevelsQuery, List<CourseLevelDto>>
{
    public async Task<List<CourseLevelDto>> Handle(GetCourseLevelsQuery request, CancellationToken ct)
    {
        var levels = await db.CourseLevels.AsNoTracking()
            .Where(lv => lv.CourseId == request.CourseId)
            .OrderBy(lv => lv.OrderIndex)
            .ToListAsync(ct);

        var moduleCounts = await db.CourseModules.AsNoTracking()
            .Where(m => m.CourseId == request.CourseId && m.LevelId != null)
            .GroupBy(m => m.LevelId!.Value)
            .Select(g => new { LevelId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.LevelId, x => x.Count, ct);

        return levels.Select(lv => new CourseLevelDto(
            lv.Id, lv.CourseId, lv.Name, lv.Description, lv.OrderIndex, lv.IsPublished,
            moduleCounts.GetValueOrDefault(lv.Id, 0),
            lv.CreatedAt
        )).ToList();
    }
}

// ── Get Level Detail ──────────────────────────────────────────────────────────

public record GetLevelDetailQuery(Guid LevelId) : IRequest<LevelDetailDto>;

public class GetLevelDetailQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetLevelDetailQuery, LevelDetailDto>
{
    public async Task<LevelDetailDto> Handle(GetLevelDetailQuery request, CancellationToken ct)
    {
        var level = await db.CourseLevels
            .FirstOrDefaultAsync(lv => lv.Id == request.LevelId, ct)
            ?? throw new NotFoundException("CourseLevel", request.LevelId);

        var modules = await db.CourseModules.AsNoTracking()
            .Include(m => m.Lessons)
            .Include(m => m.Sessions)
            .Where(m => m.LevelId == level.Id)
            .OrderBy(m => m.OrderIndex)
            .ToListAsync(ct);

        return new LevelDetailDto(
            level.Id, level.CourseId, level.Name, level.Description,
            level.OrderIndex, level.IsPublished, level.CreatedAt,
            modules.Select(m => new ModuleSummaryDto(
                m.Id, m.Title, m.Description, m.OrderIndex, m.Lessons.Count, m.Sessions.Count, m.LevelId
            )).ToList()
        );
    }
}

// ── Learning Level queries ─────────────────────────────────────────────────

public record LearningLevelDto(Guid Id, string Name, string? Description, int OrderIndex, bool IsActive, DateTime CreatedAt);

public record GetLearningLevelsQuery(bool IncludeInactive = false) : IRequest<List<LearningLevelDto>>;

public class GetLearningLevelsQueryHandler(IApplicationDbContext db)
    : IRequestHandler<GetLearningLevelsQuery, List<LearningLevelDto>>
{
    public async Task<List<LearningLevelDto>> Handle(GetLearningLevelsQuery request, CancellationToken ct)
    {
        var query = db.LearningLevels.AsNoTracking();
        if (!request.IncludeInactive)
            query = query.Where(l => l.IsActive);
        return await query
            .OrderBy(l => l.OrderIndex)
            .Select(l => new LearningLevelDto(l.Id, l.Name, l.Description, l.OrderIndex, l.IsActive, l.CreatedAt))
            .ToListAsync(ct);
    }
}
