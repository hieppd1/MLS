using Microsoft.EntityFrameworkCore;
using MLS.Domain.Entities;
using MLS.Infrastructure.Tenancy;

namespace MLS.Infrastructure.Persistence;

public static class DatabaseInitializer
{
    public static async Task EnsurePublicSchemaAsync(ApplicationDbContext db)
    {
#pragma warning disable EF1002
        await db.Database.ExecuteSqlRawAsync(@"
            CREATE TABLE IF NOT EXISTS public.""Tenants"" (
                ""Id"" uuid NOT NULL,
                ""Slug"" varchar(100) NOT NULL,
                ""Name"" varchar(200) NOT NULL,
                ""Domain"" varchar(255) NULL,
                ""Status"" varchar(20) NOT NULL DEFAULT 'Trial',
                ""ContactEmail"" varchar(255) NULL,
                ""CreatedAt"" timestamptz NOT NULL DEFAULT now(),
                ""UpdatedAt"" timestamptz NULL,
                CONSTRAINT ""PK_Tenants"" PRIMARY KEY (""Id""),
                CONSTRAINT ""UQ_Tenants_Slug"" UNIQUE (""Slug"")
            );");
#pragma warning restore EF1002
    }

    /// <summary>
    /// Seeds a "demo" tenant on first startup so developers can register/login immediately.
    /// No-op if any tenant already exists.
    /// </summary>
    public static async Task SeedDemoTenantAsync(
        ApplicationDbContext db,
        TenantProvisioner provisioner,
        CancellationToken ct = default)
    {
        var exists = await db.Tenants.AnyAsync(ct);
        if (exists)
        {
            // Run schema upgrades for all existing tenants
            var tenants = await db.Tenants.AsNoTracking().ToListAsync(ct);
            foreach (var t in tenants)
                await provisioner.UpgradeSchemaAsync(t.SchemaName, ct);
            return;
        }

        var tenant = Tenant.Create("demo", "Demo Tenant", "admin@demo.local");
        db.Tenants.Add(tenant);
        await db.SaveChangesAsync(ct);

        await provisioner.ProvisionAsync(tenant.SchemaName, ct);
    }
}
