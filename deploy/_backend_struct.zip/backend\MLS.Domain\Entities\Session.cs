using MLS.Domain.Common;

namespace MLS.Domain.Entities;

public enum SessionPublishStatus { Draft, Published }

public class Session : BaseEntity
{
    public Guid ModuleId { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string? Description { get; private set; }
    public int OrderIndex { get; private set; }
    public bool IsFreeTrial { get; private set; }
    public SessionPublishStatus PublishStatus { get; private set; } = SessionPublishStatus.Draft;

    // Video (nullable — can be added after creation)
    public Guid? VideoAssetId { get; private set; }
    public int DurationSeconds { get; private set; }
    public string? ThumbnailUrl { get; private set; }

    // Navigation
    public CourseModule Module { get; private set; } = null!;
    public SessionVideoAsset? VideoAsset { get; private set; }
    public ICollection<Segment> Segments { get; private set; } = [];
    public ICollection<SessionProgress> Progresses { get; private set; } = [];

    private Session() { }

    public static Session Create(Guid moduleId, string title, string? description, int orderIndex, bool isFreeTrial = false)
        => new()
        {
            Id = Guid.NewGuid(),
            ModuleId = moduleId,
            Title = title.Trim(),
            Description = description?.Trim(),
            OrderIndex = orderIndex,
            IsFreeTrial = isFreeTrial,
            CreatedAt = DateTime.UtcNow,
        };

    public void Update(string title, string? description, bool isFreeTrial, string? thumbnailUrl)
    {
        Title = title.Trim();
        Description = description?.Trim();
        IsFreeTrial = isFreeTrial;
        ThumbnailUrl = thumbnailUrl;
        SetUpdatedAt();
    }

    public void SetOrder(int orderIndex) { OrderIndex = orderIndex; SetUpdatedAt(); }

    public void SetVideo(Guid videoAssetId, int durationSeconds, string? thumbnailUrl)
    {
        VideoAssetId = videoAssetId;
        DurationSeconds = durationSeconds;
        if (thumbnailUrl != null) ThumbnailUrl = thumbnailUrl;
        SetUpdatedAt();
    }

    public void Publish() { PublishStatus = SessionPublishStatus.Published; SetUpdatedAt(); }
    public void Unpublish() { PublishStatus = SessionPublishStatus.Draft; SetUpdatedAt(); }
}
