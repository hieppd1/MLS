using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MLS.Application.CMS.Courses.Queries;
using MLS.Application.Learning.Commands;
using MLS.Application.Learning.Queries;
using MLS.Domain.Interfaces;

namespace MLS.API.Controllers;

/// <summary>
/// Public course catalog + lesson viewing (user-facing).
/// Auth optional for catalog; required for lesson access.
/// </summary>
[ApiController]
[Route("api/v1/courses")]
public class CoursesController(IMediator mediator, ITenantContext tenantContext) : ControllerBase
{
    private Guid? CurrentUserId
    {
        get
        {
            var val = User.FindFirst("sub")?.Value
                   ?? User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return val != null ? Guid.Parse(val) : null;
        }
    }

    // ── Catalog ───────────────────────────────────────────────────────────────

    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> GetCourses(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 12,
        [FromQuery] int? level = null,
        [FromQuery] string? search = null,
        CancellationToken ct = default)
    {
        var result = await mediator.Send(
            new GetPublicCoursesQuery(page, pageSize, level, search, CurrentUserId), ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    [AllowAnonymous]
    public async Task<IActionResult> GetCourse(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPublicCourseDetailQuery(id, CurrentUserId), ct);
        if (result == null) return NotFound();
        return Ok(result);
    }

    // ── Learning levels (public, for filter tabs) ─────────────────────────────

    [HttpGet("learning-levels")]
    [AllowAnonymous]
    public async Task<IActionResult> GetLearningLevels(CancellationToken ct)
        => Ok(await mediator.Send(new GetLearningLevelsQuery(IncludeInactive: false), ct));

    // ── Enrollment (free) ─────────────────────────────────────────────────────

    [HttpPost("{id:guid}/enroll")]
    [Authorize]
    public async Task<IActionResult> Enroll(Guid id, CancellationToken ct)
    {
        await mediator.Send(new EnrollCourseCommand(id, CurrentUserId!.Value, "Free"), ct);
        return Ok(new { message = "Enrolled successfully." });
    }

    // ── Lesson access ─────────────────────────────────────────────────────────

    [HttpGet("lessons/{lessonId:guid}")]
    [AllowAnonymous]
    public async Task<IActionResult> GetLesson(Guid lessonId, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPublicLessonQuery(lessonId, CurrentUserId), ct);
        if (result == null) return NotFound();
        // Return 200 even for locked lessons — videoHlsPath is already null when locked
        return Ok(result);
    }

    [HttpPost("lessons/{lessonId:guid}/start")]
    [Authorize]
    public async Task<IActionResult> StartLesson(Guid lessonId, CancellationToken ct)
    {
        await mediator.Send(new StartLessonCommand(lessonId, CurrentUserId!.Value), ct);
        return Ok();
    }

    [HttpPost("lessons/{lessonId:guid}/complete")]
    [Authorize]
    public async Task<IActionResult> CompleteLesson(
        Guid lessonId,
        [FromBody] CompleteLessonRequest? body,
        CancellationToken ct)
    {
        await mediator.Send(new CompleteLessonCommand(lessonId, CurrentUserId!.Value, body?.Score), ct);
        return Ok();
    }

    [HttpPost("lessons/{lessonId:guid}/video-position")]
    [Authorize]
    public async Task<IActionResult> SaveVideoPosition(Guid lessonId, [FromBody] VideoPositionRequest req, CancellationToken ct)
    {
        await mediator.Send(new SaveVideoPositionCommand(lessonId, CurrentUserId!.Value, req.PositionSeconds, req.DurationSeconds), ct);
        return Ok();
    }

    // ── User Streak ───────────────────────────────────────────────────────────

    [HttpGet("/api/v1/users/streak")]
    [Authorize]
    public async Task<IActionResult> GetLearningStreak(CancellationToken ct)
    {
        var result = await mediator.Send(new GetLearningStreakQuery(CurrentUserId!.Value), ct);
        return Ok(result);
    }
}

public record CompleteLessonRequest(int? Score);
public record VideoPositionRequest(int PositionSeconds, int DurationSeconds);
