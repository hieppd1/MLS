using MediatR;
using Microsoft.EntityFrameworkCore;
using MLS.Application.Common.Interfaces;
using MLS.Domain.Entities;

namespace MLS.Application.Learning.Commands;

// ── Start Lesson (upsert progress to InProgress) ──────────────────────────────

public record StartLessonCommand(Guid LessonId, Guid UserId) : IRequest<Unit>;

public class StartLessonHandler(IApplicationDbContext db)
    : IRequestHandler<StartLessonCommand, Unit>
{
    public async Task<Unit> Handle(StartLessonCommand cmd, CancellationToken ct)
    {
        var existing = await db.LessonProgresses
            .FirstOrDefaultAsync(p => p.UserId == cmd.UserId && p.LessonId == cmd.LessonId, ct);

        if (existing == null)
        {
            db.LessonProgresses.Add(LessonProgress.Create(cmd.UserId, cmd.LessonId));
            await db.SaveChangesAsync(ct);
        }

        return Unit.Value;
    }
}

// ── Complete Lesson ───────────────────────────────────────────────────────────

public record CompleteLessonCommand(Guid LessonId, Guid UserId, int? Score = null) : IRequest<Unit>;

public class CompleteLessonHandler(IApplicationDbContext db)
    : IRequestHandler<CompleteLessonCommand, Unit>
{
    public async Task<Unit> Handle(CompleteLessonCommand cmd, CancellationToken ct)
    {
        var progress = await db.LessonProgresses
            .FirstOrDefaultAsync(p => p.UserId == cmd.UserId && p.LessonId == cmd.LessonId, ct);

        if (progress == null)
        {
            progress = LessonProgress.Create(cmd.UserId, cmd.LessonId);
            db.LessonProgresses.Add(progress);
        }

        progress.Complete(cmd.Score);
        await db.SaveChangesAsync(ct);
        return Unit.Value;
    }
}

// ── Save Video Position (upsert) ──────────────────────────────────────────────

public record SaveVideoPositionCommand(Guid LessonId, Guid UserId, int PositionSeconds, int DurationSeconds) : IRequest<Unit>;

public class SaveVideoPositionHandler(IApplicationDbContext db)
    : IRequestHandler<SaveVideoPositionCommand, Unit>
{
    public async Task<Unit> Handle(SaveVideoPositionCommand cmd, CancellationToken ct)
    {
        var tracking = await db.VideoTrackings
            .FirstOrDefaultAsync(t => t.UserId == cmd.UserId && t.LessonId == cmd.LessonId, ct);

        if (tracking == null)
        {
            db.VideoTrackings.Add(VideoTracking.Create(cmd.UserId, cmd.LessonId, cmd.PositionSeconds, cmd.DurationSeconds));
        }
        else
        {
            tracking.Update(cmd.PositionSeconds, cmd.DurationSeconds);
        }

        await db.SaveChangesAsync(ct);
        return Unit.Value;
    }
}

// ── Enroll in Course (free / admin) ──────────────────────────────────────────

public record EnrollCourseCommand(Guid CourseId, Guid UserId, string Source = "Free") : IRequest<Unit>;

public class EnrollCourseHandler(IApplicationDbContext db)
    : IRequestHandler<EnrollCourseCommand, Unit>
{
    public async Task<Unit> Handle(EnrollCourseCommand cmd, CancellationToken ct)
    {
        var exists = await db.CourseEnrollments
            .AnyAsync(e => e.UserId == cmd.UserId && e.CourseId == cmd.CourseId, ct);

        if (!exists)
        {
            var source = cmd.Source switch
            {
                "Admin" => EnrollmentSource.Admin,
                "Payment" => EnrollmentSource.Payment,
                _ => EnrollmentSource.Free,
            };
            db.CourseEnrollments.Add(
                CourseEnrollment.Create(cmd.UserId, cmd.CourseId, source));
            await db.SaveChangesAsync(ct);
        }

        return Unit.Value;
    }
}
